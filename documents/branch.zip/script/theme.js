const theme = require('element-theme')

module.exports = { init, build }

const argv = process.argv[2]
if (argv === 'init') return init()
if (argv === 'build') return build()

function init(path) {
  theme.init(path || './src/assets/element-variables.css')
}

function build(opt, cb) {
  let config = Object.assign({
    config: './src/assets/element-variables.css',
    out: './node_modules/element-theme-default/doudou-ui/',
    minimize: true,
    browsers: ['last 2 versions']
  }, opt || {})
  theme.run(config, cb)
}
