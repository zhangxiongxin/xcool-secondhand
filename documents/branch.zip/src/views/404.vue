<template lang="pug">
  div.not-found-container
    img(src="~assets/imgs/homepage/pi_login_doudou@3x.png", draggable="false")
    h1 Sorry...页面没有找到！
    button.back_btn(@click="goBack") 返回
</template>
<script>
  export default {
    name: 'notFound',
    methods: {
      goBack() {
        this.$router.back()
      }
    }
  }
</script>
<style scoped>
  .not-found-container {
    padding-top: 100px;
    text-align: center;
    font-size: 18px;
    & img {
      width: 200px;
    }
    & h1 {
      font-weight: 600;
      margin: 10px 0;
    }
  }

  .back_btn {
    border-radius: 6px;
    background: #4F9AFB;
    color: #fff;
    font-size: 18px;
    height: 39px;
    text-align: center;
    border: none;
    width: 200px;
    margin-top: 10px;
  }
</style>
