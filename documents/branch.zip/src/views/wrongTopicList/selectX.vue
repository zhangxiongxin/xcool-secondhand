<template lang="pug">
  div.select-x(:class="color",:style="{width: width + 'rem'}")
    .seclt-text {{text}}
    .select(@mouseleave="showOption = false")
      label(:class="color",@click="showOption = true") {{label}}
        .select-icon(:class="'theme-' + color + '-color'")
          p ➔
          p ➔
      ul.ul(v-if="showOption")
        li(v-for="item, index in options", :key="index",@click="selectHandle(item.value)",:class="{selected: item.select, color: true}") {{item.label}}
</template>
<script>
  import reportServices from '@/services/report'
  export default {
    name: 'selctX',
    data() {
      return {
        value: '',
        label: '',
        options: [],
        showOption: false
      }
    },
    props: ['color', 'text', 'width', 'period'],
    watch: {
      period: function(a, b) {
        if (a) this.getData()
      }
    },
    methods: {
      selectHandle(value) {
        this.showOption = false
        this.value = value
        this.getLabel()
      },
      // 获取数据
      getData() {
        reportServices.getKnowledgeTwo({learnPeriod: this.period}).then(res => {
          this.options = res.data.map(item => {
            return {
              label: item.knowledgePointName,
              value: item.knowledgePointId
            }
          })
          if (this.options.length) this.value = sessionStorage.getItem('knowledgeIds') || this.options[0].value
          else this.value = ''
          sessionStorage.removeItem('knowledgeIds')
          this.getLabel()
        })
      },
      getLabel() {
        let label = this.options.filter(item => {
          if (item.value === this.value) item.select = true
          else item.select = false
          return item.value === this.value
        })
        if (label.length) this.label = label[0].label || ''
        else this.label = ''
        this.$emit('select', this.value)
      }
    },
    created() {
      if (this.text === '选择学段') {
        this.options = [{
          label: '小学',
          value: 1
        }, {
          label: '初中',
          value: 2
        }]
        this.value = Number(sessionStorage.getItem('period')) || 2
        sessionStorage.removeItem('period')
        this.getLabel()
      } else {
        this.getData()
      }
    }
  }
</script>
<style scoped>
  .select-x{
    position: relative;
    margin:0 0.57rem;
    top: -1rem;
    & .seclt-text {
      font-size: 0.86rem;
      line-height: 1.29rem;
      color: #666666;
    }
    & .select {
      position: absolute;
      width: 100%;
      & label {
        display: block;
        padding: 3px 10px;
        border-radius: 4px;
        height: 2.6rem;
        line-height: 2rem;
        cursor: pointer;
        &.blue {
          color: #635DF0;
          background-color: #E7E6FD;
          &:hover {
            border: 0.1rem solid #635DF0;
          }
        }
        &.red {
          color: #F56560;
          background-color: #FFEBEA;
          &:hover {
            border: 0.1rem solid #F56560;
          }
        }
      }
      & .ul {
        margin-top: 0.5rem;
        box-shadow: 0 2px 8px 0 #717171;
        border-radius: 4px;
        width: 100%;
        background: #ffffff;
        max-height: 20rem;
        overflow: auto;
        padding: 0.5rem 0;
        color: #999999;
        & li {
          height: 2.4rem;
          padding-left: 0.5rem;
          line-height: 2.4rem;
          cursor: pointer;
        }
      }
    }
  }
  .red .ul {
    & li {
      &:hover {
        background: #FFEBEA;
      }
      &.selected {
        background: #FFEBEA;
      }
    }
  }
  .blue .ul {
    & li {
      &:hover {
        background: #E7E6FD;
      }
      &.selected {
        background: #E7E6FD;
      }
    }
  }
  .select-icon {
    position: absolute;
    right: 0.57rem;
    top: 0.6rem;
    width: 1.29rem;
    height: 1.29rem;
    text-align: center;
    line-height: 0.5rem;
    border-radius: 100%;
    cursor: pointer;
    & p {
      text-align: center;
      font-size: 0.9rem;
      line-height: 0.5rem;
      transform: scale(0.8);
      &:last-of-type {
        transform: rotate(180deg) scale(0.8);
      }
    }
  }
  .theme-blue-color {
    color: #635DF0;
    background-color: #E7E6FD;
    border: 0.1rem solid #635DF0;
  }
  .theme-red-color {
    color: #F56560;
    background-color: #FFEBEA;
    border: 0.1rem solid #F56560;
  }
</style>
