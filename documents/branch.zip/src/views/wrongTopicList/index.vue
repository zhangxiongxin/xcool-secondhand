<template lang="pug">
  router-view.body-container
</template>
<script>
  export default {
    name: 'wrongTopicList'
  }
</script>
<style scoped>
</style>
