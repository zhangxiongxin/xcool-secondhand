<template lang="pug">
  div.body-container
    .box.display-flex
      .btn(@click="copyUrl")
        img(src="~assets/imgs/ic_share.png",style="width:1.26rem;vertical-align:middle")
        span(style="padding-left:0.5rem;line-height:0") {{btnText}}
    .box
      section.list(v-for="item, index in wrongDetail", :key="index")
        latex(:text="item.stemg", :imgs="item.stemGraph", :latexImgs="item.stemLatexGraph")
          slot {{index + 1}} 、
        br
        latex(v-if="item.subStemg",:text="item.subStemg", :imgs="item.subStemGraph", :latexImgs="item.subLatexGraph", :class="'sub-stem-'+item.questionType")
</template>
<script>
  import reportServices from '@/services/report'
  import { fileServer } from 'config/app'
  import date from '@/filters/date'
  const btnText = {
    wx: '复制分享链接',
    client: '下载PDF'
  }
  export default {
    name: 'wrongDetail',
    data() {
      return {
        recordId: this.$route.query.recordId,
        knowledgeName: this.$route.query.knowledgeName,
        wrongDetail: [],
        pdfUrl: '',
        btnText: btnText[this.$route.query.source]
      }
    },
    methods: {
      getData() {
        reportServices.getWrongDetail({recordId: this.recordId}).then(res => {
          this.wrongDetail = res.data.details
          this.pdfUrl = res.data.pdfUrl
        })
      },
      copyUrl() {
        reportServices.recordCount({recordId: this.recordId}).then(res => {
          if (this.$route.query.source === 'wx') {
            window.wx.miniProgram.navigateTo({url: `/pages/upload/billboard/main?url=${encodeURIComponent(this.pdfUrl + '?filename=' + this.knowledgeName + '-' + date(null, 'yyyyMMdd') + '.pdf')}`})
          } else {
            // let a = document.createElement('a')
            // a.href = fileServer + this.pdfUrl
            // a.download = this.knowledgeName + '-' + date(null, 'yyyyMMdd')
            // a.click()
            window.open(fileServer + this.pdfUrl + '?filename=' + this.knowledgeName + '-' + date(null, 'yyyyMMdd') + '.pdf', '_self')
          }
        })
      }
    },
    mounted() {
      this.getData()
      // 客户端使用postMessage交互
      if (this.$route.query.source === 'client') {
        window.parent.postMessage(this.knowledgeName, '*')
      }
      document.querySelector('title').innerText = this.knowledgeName
    }
  }
</script>
<style scoped>
  .box {
    padding: 1.43rem;
    & .btn {
      font-size: 12px;
      color: #5953DC;
      background: #F8F0FF;
      border-radius: 97px;
      cursor: pointer;
      padding: 0.64rem 1.71rem;
    }
  }
  .display-flex {
    display: flex;
    justify-content: flex-end;
  }
  .list {
    margin-top: 0.7rem;
    color: #2e1f3d;
    line-height: 1.8;
  }
</style>
