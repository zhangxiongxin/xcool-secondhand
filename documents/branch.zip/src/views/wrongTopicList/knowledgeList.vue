<template lang="pug">
  .body-container
    .title
      p.title-text 易错题排行榜
      p.sub-title-text 千万级题次的大数据分析，基于知识点的高频错题精选，让你捡回不该丢的分
    .filtrate
      select-x(color="blue", text="选择学段", width="8.57", @select="selectPeriod")
      select-x(color="red", text="选择二级知识点", width="12.61", @select="selectKnowledge", :period="period")
    .knowledge-list(v-if="getWrongLists.length")
      .text
        span 三级知识点-易错题
        span 上次更新时间：{{updateTime|date('yyyy.MM.dd HH:mm:ss')}}
      ul.list
        li(v-for="item, index in getWrongLists",:key="index",@click="toDetail(item.recordId, item.knowledgeName)") {{item.knowledgeName}}
    //- .knowledge-list 暂无数据
    .info-text 个性化定制高效学习，由清华大学(苏研院)大数据处理中心&准星云学提供技术支持


</template>
<script>
  import selectX from './selectX'
  import reportServices from '@/services/report'
  export default {
    name: 'knowledgeList',
    data() {
      return {
        period: Number(sessionStorage.getItem('period')) || 2,   // 学段，默认为初中
        updateTime: null,
        getWrongLists: [],
        source: this.$route.query.source,
        knowledgeIds: ''
      }
    },
    components: {selectX},
    methods: {
      toDetail(id, knowledgeName) {
        sessionStorage.setItem('period', this.period)
        sessionStorage.setItem('knowledgeIds', this.knowledgeIds)
        this.$router.push(`/wrongTopicList/wrongDetail?recordId=${id}&source=${this.source}&knowledgeName=${knowledgeName}`)
      },
      // 选择学段
      selectPeriod(value) {
        this.period = value
        this.updateTime = null
        this.getWrongLists = []
      },
      // 选择知识点
      selectKnowledge(value) {
        if (value) {
          this.knowledgeIds = value
          reportServices.getWrongLists({knowledgeIds: value}).then(res => {
            if (res.data.length) {
              this.updateTime = res.data[0].createTime
              this.getWrongLists = res.data
            } else {
              this.updateTime = null
              this.getWrongLists = []
            }
          })
        }
      }
    },
    mounted() {
      // 客户端使用postMessage交互
      if (this.source === 'client') {
        window.parent.postMessage('易错题排行榜', '*')
      }
      document.querySelector('title').innerText = '易错题排行榜'
    }
  }
</script>
<style scoped>
.info-text {
  color: #5953DC;
  font-size: 0.8rem;
  position: fixed;
  bottom: 0rem;
  text-align: center;
  width: 100%;
  padding: 10px;
  background: #ffffff;
}
.title {
  height: 7.14rem;
  width: 100%;
  background: url(~assets/imgs/topicTitle.png) no-repeat;
  background-size: 100% 100%;
  text-align: center;
  letter-spacing: 0.01rem;
  position: fixed;
  top: 0;
  & .title-text {
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "\5FAE\8F6F\96C5\9ED1", Arial, sans-serif;
    font-size: 2.57rem;
    font-weight: bolder;
    line-height: 3.86rem;
    color: #5953DC;
    text-shadow: -0.15rem 0rem #ffffff, 0rem -0.15rem #ffffff, 0.15rem 0rem #ffffff, 0rem 0.15rem #ffffff;
  }
  & .sub-title-text {
    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "\5FAE\8F6F\96C5\9ED1", Arial, sans-serif;
    line-height: 1.43rem;
    font-size: 1rem;
    color: #ffffff;
  }
}
.filtrate {
  height: 5.43rem;
  width: 100%;
  box-shadow: 0rem 0.43rem #F3F3F5;
  margin-bottom: 0.43rem;
  position: fixed;
  top: 7.14rem;
  background: #ffffff;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.knowledge-list {
  width: 100%;
  padding: 13.71rem 0.71rem 1.71rem;
  & .text {
    font-size: 0.86rem;
    clear: both;
    height: 1.29rem;
    line-height: 1.29rem;;
    & span:first-of-type {
      float: left;
    }
    & span:last-of-type {
      float: right;
      color: #64BFFA;
    }
  }
  & .list {
    padding-bottom: 1rem;
    & li {
      height: 5.14rem;
      border-radius: 0.29rem;
      font-size: 1.43rem;
      line-height: 2.07rem;
      color: #ffffff;
      margin: 0.3rem 0;
      padding: 0.71rem;
      display: flex;
      align-items: center;
      cursor: pointer;
      &:nth-child(2n) {
        background: url(~assets/imgs/bg_blue.png) no-repeat;
        background-size: 100% 100%;
      }
      &:nth-child(2n + 1) {
        background: url(~assets/imgs/bg_yellow.png) no-repeat;
        background-size: 100% 100%;
      }
    }
  }
}
@media screen and (min-width: 786px) {
  .title {
    background: url(~assets/imgs/big_topic_title.png) no-repeat;
    background-size: 100% 100%;
  }
  .knowledge-list {
    padding: 13.71rem 28px 1.71rem;
    & .list {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      & li {
        width:49%;
        &:nth-child(4n - 3) {
        background: url(~assets/imgs/bg_yellow.png) no-repeat;
        background-size: 100% 100%;
        }
        &:nth-child(4n - 2) {
        background: url(~assets/imgs/bg_yellow.png) no-repeat;
        background-size: 100% 100%;
        }
        &:nth-child(4n - 1) {
          background: url(~assets/imgs/bg_blue.png) no-repeat;
          background-size: 100% 100%;
        }
        &:nth-child(4n) {
          background: url(~assets/imgs/bg_blue.png) no-repeat;
          background-size: 100% 100%;
        }
      }
    } 
  }
}
</style>
