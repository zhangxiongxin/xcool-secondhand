<template lang='pug'>
  div.tables
    table(style='width:100%;background:#ffffff')
      thead
        tr
          th(style="width:31%") 四级知识点
          th(style="width:31%") 正确率
          th(style="width:31%") 所属三级知识点
      tbody
        tr(v-for="item in knowledges", :key="item.knowledgePointId")
          td 
            .point-name 
              p {{item.knowledgePointName}}
              p.new-learn(v-if="item.newLearn") NEW
          td 
            .rate(style="width: 40px") {{Math.round(item.accuracy*100)}}%
              .compare(v-if="!item.newLearn && item.accuracy - item.lastAccuracy > 0")
                img(src="~assets/imgs/ico_rise.png", draggable="false")
                .text-green {{Math.round((item.accuracy - item.lastAccuracy) * 100)}}%
              .compare(v-else-if="!item.newLearn && item.accuracy - item.lastAccuracy < 0")
                img(src="~assets/imgs/ico_decline.png", draggable="false")
                .text-red {{Math.round((item.lastAccuracy - item.accuracy) * 100)}}%
              .compare.flat(v-else-if="!item.newLearn && item.accuracy - item.lastAccuracy === 0")
                img(src="~assets/imgs/ico_flat.png", draggable="false")
          td {{item.parentName}}
    
</template>
<script>
  export default {
    name: 'knowledgeTable',
    props: ['knowledges'],
    components: {},
    data() {
      return {}
    },
    created() {},
    methods: {}
  }
</script>
<style scoped>
  table {
    border-collapse: collapse;
    & th {
      font-weight: 400;
      height: 40px;
    }
    & td {
      height: 40px;
      min-width: 100px;
      text-align: center;
      & p {
        min-height: 40px;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
  }
  
  .point-name {
    display: flex;
    flex-wrap: nowrap;
    justify-content: center;
    &>p:first-child {
      white-space: nowrap;
    }
  }

  .rate {
    display: inline-block;
    position: relative;
  }
  
  .new-learn {
    transform: scale(0.83);
    margin-left: 4px;
    white-space: nowrap;
    font-size: 12px;
    line-height: 25px;
    color: #FF5353;
  }
  
  .compare {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: -55px;
    display: flex;
    align-items: center;
  }
  
  .flat {
    right: -26px;
  }
  
  .text-green {
    color: #90D236;
    margin-left: 4px;
  }
  
  .text-red {
    color: #E53F3F;
    margin-left: 4px;
  }
</style>
