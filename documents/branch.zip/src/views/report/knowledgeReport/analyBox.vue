<template lang='pug'>
  div.tables.analy-box
    table(style="width:100%;background:#ffffff")
      thead
        tr
          th(v-for="item in tableFlieds") {{item}}
      tbody
        tr(v-for="(oneItem, index) in analyData")
          td {{oneItem.knowledgePointName}}
            span(v-if="oneItem.newLearn",style="display:inline-block;font-size:12px;color: #FF5353;transform:scale(0.83);padding-left:10px") NEW
          td.td-width
            div.text-left(style="display:flex;align-items:center;")
              span {{Math.round(oneItem.accuracy*100)}}%
              span.compare(v-if="!oneItem.newLearn && oneItem.accuracy - oneItem.lastAccuracy > 0")
                img(src="~assets/imgs/ico_rise.png", draggable="false")
                span.text-green {{Math.round((oneItem.accuracy - oneItem.lastAccuracy) * 100)}}%
              span.compare(v-else-if="!oneItem.newLearn && oneItem.accuracy - oneItem.lastAccuracy < 0")
                img(src="~assets/imgs/ico_decline.png", draggable="false")
                .text-red {{Math.round((oneItem.lastAccuracy - oneItem.accuracy) * 100)}}%
              span.compare(v-else-if="!oneItem.newLearn && oneItem.accuracy - oneItem.lastAccuracy === 0")
                  img(src="~assets/imgs/ico_flat.png", draggable="false")
          td 
            p.second(v-for="(twoItem,num) in oneItem.child",:class="{hasline:num !== (oneItem.child.length - 1)}",:data-num="oneItem.child[num].child.length") {{twoItem.knowledgePointName}}
              span(v-if="twoItem.newLearn",style="display:inline-block;font-size:12px;color: #FF5353;transform:scale(0.83);padding-left:10px") NEW
          td.td-width 
            p.second.text-left(v-for="(twoItem,num) in oneItem.child",:class="{hasline:num !== (oneItem.child.length - 1)}",:data-num="oneItem.child[num].child.length")
              span {{Math.round(twoItem.accuracy*100)}}%
              span.compare(v-if="!twoItem.newLearn && twoItem.accuracy - twoItem.lastAccuracy > 0")
                img(src="~assets/imgs/ico_rise.png", draggable="false")
                span.text-green {{Math.round((twoItem.accuracy - twoItem.lastAccuracy) * 100)}}%
              span.compare(v-else-if="!twoItem.newLearn && twoItem.accuracy - twoItem.lastAccuracy < 0")
                img(src="~assets/imgs/ico_decline.png", draggable="false")
                span.text-red {{Math.round((twoItem.lastAccuracy - twoItem.accuracy) * 100)}}%
              span.compare(v-else-if="!twoItem.newLearn && twoItem.accuracy - twoItem.lastAccuracy === 0")
                  img(src="~assets/imgs/ico_flat.png", draggable="false")
          td 
            div(v-for="(twoItem,num) in oneItem.child",:class="{hasline:num !== (oneItem.child.length - 1)}")
              p(v-for="(threeItem,num1) in oneItem.child[num].child",:class="{hasline:num1 !== (oneItem.child[num].child.length - 1)}") {{threeItem.knowledgePointName}}
                span(v-if="threeItem.newLearn",style="display:inline-block;font-size:12px;color: #FF5353;transform:scale(0.83);padding-left:10px") NEW
          td.td-width 
            div(v-for="(twoItem,num) in oneItem.child",:class="{hasline:num !== (oneItem.child.length - 1)}")
              p.text-left(v-for="(threeItem,num1) in oneItem.child[num].child",:class="{hasline:num1 !== (oneItem.child[num].child.length - 1)}") 
                span {{Math.round(threeItem.accuracy*100)}}%
                span.compare(v-if="!threeItem.newLearn && threeItem.accuracy - threeItem.lastAccuracy > 0")
                  img(src="~assets/imgs/ico_rise.png", draggable="false")
                  span.text-green {{Math.round((threeItem.accuracy - threeItem.lastAccuracy) * 100)}}%
                span.compare(v-else-if="!threeItem.newLearn && threeItem.accuracy - threeItem.lastAccuracy < 0")
                  img(src="~assets/imgs/ico_decline.png", draggable="false")
                  span.text-red {{Math.round((threeItem.lastAccuracy - threeItem.accuracy) * 100)}}%
                span.compare(v-else-if="!threeItem.newLearn && threeItem.accuracy - threeItem.lastAccuracy === 0")
                  img(src="~assets/imgs/ico_flat.png", draggable="false")
</template>
<script>
  export default {
    name: 'analyBox',
    props: ['originData'],
    components: {},
    data() {
      return {
        analyData: [],
        tableFlieds: ['一级知识点', '正确率', '二级知识点', '正确率', '三级知识点', '正确率']
      }
    },
    watch: {
      originData(v) {
        if (v) this.init()
      }
    },
    mounted() {
      this.init()
    },
    updated() {
      this.styleHandle()
    },
    methods: {
      replaceAll(arr) {
        if (!arr) return []
        var cache = {}
        var result = []
        arr.forEach(item => {
          if (!cache[item.knowledgePointId]) {
            result.push(item)
            cache[item.knowledgePointId] = item
          }
        })
        return result
      },
      init() {
        let tempArry = []
        if (!this.originData) return
        var cache = {}
        var firstLvl = this.replaceAll(this.originData.firstLevelKnMastery)
        var secondLvl = this.replaceAll(this.originData.secondLevelKnMastery)
        var thirdLvl = this.replaceAll(this.originData.thirdLevelKnMastery)
        firstLvl.forEach(item => {
          item.child = []
          cache[item.knowledgePointId] = item
          tempArry.push(item)
        })
        secondLvl.forEach(item => {
          item.child = []
          cache[item.knowledgePointId] = item
          var p = cache[item.parentId]
          if (p) {
            p.child.push(item)
          } else {
          }
        })
        thirdLvl.forEach(item => {
          var p = cache[item.parentId]
          if (p) {
            p.child.push(item)
          } else {
          }
        })
        this.analyData = tempArry
      },
      styleHandle() {
        let doms = document.querySelectorAll('.second')
        for (let i = 0; i < doms.length; i++) {
          let num = doms[i].dataset.num
          doms[i].style.height = 40 * num + 1 + 'px'
        }
      }
    }
  }
</script>
<style scoped>
  .analy-box {
    width: 100%;
    padding-bottom: 12px;
    overflow-x: auto;
  }
  table {
    border-collapse: collapse;
    & th {
      font-weight: 400;
      height: 40px;
    }
    & td {
      height: 40px;
      min-width: 100px;
      text-align: center;
      & p {
        min-height: 40px;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
  }
  
  .hasline {
    border-bottom: 1px solid #6FBE66;
    white-space: nowrap;
  }
  
  .compare {
    margin-left: 5px;
    display: flex;
    align-items: center;
  }
  
  .text-green {
    color: #90D236;
    margin-left: 4px;
  }
  
  .text-red {
    color: #E53F3F;
    margin-left: 4px;
  }
  
  .text-left {
    justify-content: flex-start;
    padding-left: 17px;
  }
  
  .td-width {
    width: 120px;
  }

  td * {
    white-space: nowrap;
  }
</style>
