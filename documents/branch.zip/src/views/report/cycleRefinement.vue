<template lang="pug">
  section(v-loading="loading",style="font-size:16px")
    .gradient(style="padding-left:3%;padding-right:2.7%")
      .reportTitle
        span.mr-10(style="font-weight: bold;") {{reportData.studentName}}
        span.mr-10(style="font-weight: bold;") {{reportData.reportName}}
      div(style="display:flex;flex-wrap:wrap",v-if="reportData.questionDistribute")
        .item.level-good
          span 总共 {{reportData.totalQuestions}} 题 
          p
            span  答对
            span.big  {{reportData.rightCount}}
            span  题
        .item.level-fine
          span 正确率（精确到题目小问）
          p
            span.big {{reportData.accuracy | rateFilter}}
          .cheer1(v-if="reportData.accuracy < 0.8") 加油
      hr.hr
      .reportDetail
        dd-table(:structuredData="structuredData")
      footer
</template>
<script>
  import store from '@/store'
  import { weekWrongsReport } from '@/store/types'

  export default {
    name: 'personalReport',
    data() {
      return {}
    },
    computed: {
      structuredData() {
        return {
          profile: [{ title: '正确率', percent: (Math.round(this.reportData.accuracy * 100) || 0) + '%' }],
          tables: [{
            itemTitle: '题目对错一览',
            tableData: this.reportData.questionList,
            tableFields: [{
              prop: 'questionType',
              label: '题型'
            }, {
              prop: 'numInPaper',
              label: '题号'
            }, {
              prop: 'correct',
              label: '批阅结果'
            }, {
              prop: 'knowledgePoint',
              label: '该题涉及的四级知识点'
            }]
          }, {
            itemTitle: '知识点',
            tableData: this.reportData.knowledgeList,
            tableFields: [{
              prop: 'knowledgePointName',
              label: '四级知识点'
            }, {
              prop: 'accuracy',
              label: '正确率'
            }, {
              prop: 'totalCount',
              label: '出现次数'
            }, {
              prop: 'rightCount',
              label: '正确次数'
            }, {
              prop: 'questionNumText',
              label: '含该知识点的题目'
            }]
          }]
        }
      },
      reportData() {
        return store.state.report.reportData
      },
      params() {
        return this.$route.params
      },
      loading() {
        return store.state.report.loading
      }
    },
    created() {
      store.dispatch(weekWrongsReport, this.params)
    }
  }
</script>
<style scoped>
  .reportTitle {
    padding: 30px 0px 10px;
    font-size: 20px;
    text-align: center;
  }
  
  .pass {
    width: 216px;
    height: 110px;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: #FFF1A4;
    margin-right: 30px;
    color: #C39B41;
  }
  .mr-10 {
    margin-right: 10px;
  }
  
  .big {
    font-size: 36px;
  }
  .item {
    width: 216px;
    height: 110px;
    border-radius: 12px;
    font-size: 16px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    margin-bottom: 7px;
  }
  .level-good {
    background:  #FFF1A4;
    color:  #C39B41;
    margin-right: 20px;
  }
  .level-fine {
    background: #D9E2FF;
    color:  #5B81F5;
    position: relative;
  }
  .big {
    font-size: 36px;
    line-height: 51px;
  }
  .cheer1 {
    padding-left:22px;
    background: url(~assets/imgs/cheer2.png) no-repeat 0 2px;
    background-size: auto 20px;
    color: #FF9937;
    position: absolute;
    bottom: 6px;
    right: 10px;
    height: 24px;
    line-height: 28px;
  }
</style>
