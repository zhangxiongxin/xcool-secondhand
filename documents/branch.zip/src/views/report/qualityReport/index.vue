<template lang="pug">
  .report-contain(v-loading="loading", element-loading-text="拼命加载中", ref="scrollbox")
    .center(style="font-size: 18px") {{reportData.reportName}}
    .center(style="color:#999") 最后提交时间：{{reportData.selfEvaluation.modifyTime | date}}
    .total-socre 
      div(style="margin-top:20px;color:#A779E8") 总评分
      p(style="color:#A779E8;font-size:38px;line-height:50px") {{round(reportData.totalScore)}} 分
    .detail-score
      .score-item 
        div 作业与试卷完成情况
        .score-num {{round(reportData.taskComplete)}} 分
      .score-item 
        div 错题解决情况
        .score-num {{round(reportData.problemSolution)}} 分
      .score-item 
        div 学习能力
        .score-num {{round(reportData.learningAbility)}} 分
      .score-item 
        div 学习兴趣
        .score-num {{round(reportData.interest)}} 分
      .score-item 
        div 学习态度
        .score-num {{round(reportData.attitude)}} 分
      .score-item 
        div 学习习惯
        .score-num {{round(reportData.habit)}} 分
      .score-item.no-border 
        div 学习方法
        .score-num {{round(reportData.method)}} 分
      .score-item.no-border 
        div 学习环境
        .score-num {{round(reportData.enviornment)}} 分
    .essen-info
      .sub-item （一）基本信息
        .l-triangle
      .flex-between
        div 1、姓名
        .purple-color(v-if="datas.name.answer") {{datas.name.answer}}
        .purple-color(v-else) {{reportData.studentName}}
      .flex-between
        div 2、性别
        .purple-color {{datas.sex.answer}}
      .flex-between
        div 3、学校
        .purple-color {{datas.school.answer}}
      .flex-between
        div 4、年级
        .purple-color {{datas.grade.answer}}
      .flex-between
        div 5、年级排名（例：100/500）
        .purple-color {{datas.classRank.answer}} / {{datas.classTotal.answer}}
      .flex-between
        div 6、班级排名（例：20/50）
        .purple-color {{datas.gradeRank.answer}} / {{datas.gradeTotal.answer}}
      .flex-between
        div 7、最近一次考试成绩（月考以上级别）
        .purple-color {{datas.testScore.answer}}
      .flex-between
        div 8、家长联系方式
        .purple-color {{datas.tel.answer}}
    .essen-info
      .sub-item （二）学生自我评价
        .l-triangle 
      .flex-between
        div A1、对数学的兴趣
        .purple-color {{datas.A1.answer}}（{{datas.A1.score}} 分）
      .flex-between
        div A2、是否适应老师教学风格
        .purple-color {{datas.A2.answer}}（{{datas.A2.score}} 分）
      .flex-between
        div A3、课前预习的主动性
        .purple-color {{datas.A3.answer}}（{{datas.A3.score}} 分）
      .flex-between
        div A4、课堂笔记的主动性
        .purple-color {{datas.A4.answer}}（{{datas.A4.score}} 分）
      .flex-between
        div A5、课堂练习的自觉性
        .purple-color {{datas.A5.answer}}（{{datas.A5.score}} 分）
      .flex-between
        div A6、课堂回答问题的主动性
        .purple-color {{datas.A6.answer}}（{{datas.A6.score}} 分）
      .flex-between
        div A7、课堂听课习惯
        .purple-color {{datas.A7.answer}}（{{datas.A7.score}} 分）
      .flex-between
        div A8、课后复习习惯
        .purple-color {{datas.A8.answer}}（{{datas.A8.score}} 分）
      .flex-between
        div A9、每天家庭作业完成速度
        .purple-color {{datas.A9.answer}}（{{datas.A9.score}} 分）
      .flex-between
        div A10、家庭作业正确率
        .purple-color {{datas.A10.answer}}（{{datas.A10.score}} 分）
      .flex-between
        div A11、将错题收集到错题本的频率：
        .purple-color {{datas.A11.answer}}（{{datas.A11.score}} 分）
      .flex-between
        div A12、大型考试（月考以上）发挥情况
        .purple-color {{datas.A12.answer}}（{{datas.A12.score}} 分）
      .flex-between
        div B1、学习上遇到问题大部分时候如何应对
        .purple-color {{datas.B1.answer}}（{{datas.B1.score}} 分）
      .flex-between
        div B2、兴趣爱好（多选）
        .purple-color {{datas.B2.answer}}
    .essen-info
      .sub-item （三）家长评价
        .l-triangle 
      .flex-between
        div C1、性格
        .purple-color {{datas.C1.answer}}
      .flex-between
        div C2、孩子的兴趣爱好（多选）
        .purple-color {{datas.C2.answer}}
      .flex-between
        div C3、学习主动性
        .purple-color {{datas.C3.answer}}（{{datas.C3.score}} 分）
      .flex-between
        div C4、在家里是否叛逆
        .purple-color {{datas.C4.answer}}
      .flex-between
        div C5、家庭教育的观念
        .purple-color {{datas.C5.answer}}
      .flex-between
        div C6、孩子有心事一般给谁讲？
        .purple-color {{datas.C6.answer}}
      .flex-between
        div C7、平时是否有时间管理孩子学习
        .purple-color {{datas.C7.answer}}
      .flex-between
        div C8、家庭环境对孩子的学习
        .purple-color {{datas.C8.answer}}（{{datas.C8.score}} 分）
</template>
<script>
  import reportService from '@/services/report'
  export default {
    name: 'qualityReport',
    data() {
      return {
        loading: false,
        datas: {},
        reportData: { selfEvaluation: { modifyTime: '' } }
      }
    },
    watch: {
      'reportData': {
        handler: function(n, o) {
          this.rebuildData()
        },
        deep: true
      }
    },
    created() {
      // this.$refs.scrollbox.style.overflow = 'hidden'
      reportService
        .qualityReport({ studentId: this.$route.params.studentId }, res => {
          this.loading = false
          // this.$refs.scrollbox.style.overflow = 'visible'
            // 保存原始数据
          this.reportData = res.data
            // 格式化数据
          this.rebuildData()
        })
    },
    methods: {
      round(num) {
        return Math.round(num)
      },
      rebuildData() {
        if (this.reportData.selfEvaluation.data.length) {
          this.reportData.selfEvaluation.data.forEach(item => {
            this.datas[item.questionId] = {
              answer: item.answer,
              score: item.score
            }
          })
        }
      }
    }
  }
</script>
<style scoped>
  .report-contain {
    padding: 15px;
  }
  
  .center {
    text-align: center;
  }
  
  .total-socre {
    overflow: hidden;
    width: 216px;
    height: 110px;
    text-align: center;
    background: #EEE1FF;
    border-radius: 12px;
    margin: 20px 0;
  }
  
  .detail-score {
    /*width: 500px;*/
    background: #EEE1FF;
    border-radius: 12px;
    padding: 8px 20px;
    display: flex;
    flex-wrap: wrap;
  }
  
  .score-item {
    height: 36px;
    width: 50%;
    display: flex;
    align-items: center;
    padding: 0 20px;
    justify-content: space-between;
    border-bottom: 1px solid #DFCCFA;
  }
  
  .no-border {
    border-bottom: none;
  }
  
  .score-num {
    font-size: 18px;
    color: #A779E8;
  }
  
  .flex-between {
    padding: 0 30px;
    height: 43px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px dashed #D6D6D6;
  }
  
  .sub-item {
    height: 24px;
    line-height: 24px;
    color: #ffffff;
    padding-left: 10px;
    padding-right: 36px;
    background-color: #A779E8;
    position: relative;
    margin-top: 30px;
    display: inline-block;
  }
  
  .l-triangle {
    width: 0;
    height: 0;
    border-top: 12px solid transparent;
    border-right: 12px solid #ffffff;
    border-bottom: 12px solid transparent;
    position: absolute;
    top: 0px;
    right: -1px;
  }
  
  .purple-color {
    color: #A779E8;
  }
</style>
