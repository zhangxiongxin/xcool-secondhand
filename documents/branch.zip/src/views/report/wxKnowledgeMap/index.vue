<template lang="pug">
  div
    wx-knowledge
</template>
<script>
  import wxKnowledge from './wxKnowledge'
  export default {
    name: 'index',
    components: {wxKnowledge}
  }
</script>
<style scoped>
</style>
