<template lang="pug">
  div(style="background: #F3F3F5")
    .info
      p 【{{nickName}}】 你的专属知识图谱 
      p.update-time 更新时间：{{originData.createTime}}
    .score
      span 评分{{originData.totalScore || 0}}分（总分100分）
      //- span.button 设置知识点范围
    .echart
      section(ref='mychart')
    section.tip(ref="knowledgeTip", v-if="showknowledgeTip",@touchend="hideknowledge")
      .inner-box
        div
          p.knowledge-name 【{{knowledgeTip.name}}】
          p.accuracy.display-flex &nbsp;&nbsp;正确率：{{knowledgeTip.value}}%&nbsp;&nbsp;
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy>knowledgeTip.lastAccuracy",src="~assets/imgs/fa-arrow-up.png", width=21, height=24)
            span.green-color(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy>knowledgeTip.lastAccuracy") &nbsp;&nbsp;+{{Math.round((knowledgeTip.accuracy - knowledgeTip.lastAccuracy) * 100)}}%
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy<knowledgeTip.lastAccuracy",src="~assets/imgs/ico_decline.png", width=21, height=24)
            span.red-color(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy<knowledgeTip.lastAccuracy") &nbsp;&nbsp;-{{Math.round((knowledgeTip.lastAccuracy - knowledgeTip.accuracy) * 100)}}%
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy==knowledgeTip.lastAccuracy",src="~assets/imgs/ico_flat.png", width=24, height=24)
            span(v-if="knowledgeTip.newLearn",style="display:inline-block;font-size:12px;color: #FF5353;transform:scale(0.83)") NEW
        .accuracy-100(v-if="knowledgeTip.accuracy == 1")
          img(src="~assets/imgs/ic_good.png")
        .mention(v-if="knowledgeTip.level == 3 && knowledgeTip.accuracy != 1")
          .mention-point
            p.point-text &nbsp;提分锦囊
          .part 
            span 去
            span.color-green(@touchend="goToGoods(3)") 名师精讲
            span 中观看“{{knowledgeTip.name}}”的知识点视频。
          .part
            span 去错题本中查看与以下知识点相关的错题:
          .part
            span(v-if="KnowledgeFour") {{KnowledgeFour}}
            span(v-if="!KnowledgeFour") 暂无
          div.display-flex
            .button(@touchend="goToGoods(1)") 名师精讲
            .button(@touchend="goToGoods(2)") 错题本
        section.cancel-btn(@touchend="hideknowledge")
</template>
<script>
  import echarts from 'echarts'
  import knowledgeMap from '@/utils/knowledgeMap'
  import reportService from '@/services/report'
  // import wx from 'weixin-js-sdk'
  let timer, intermediateTimer
  export default {
    name: 'index',
    components: {},
    data() {
      return {
        originData: {},
        option: {
          animationDurationUpdate: 1500,
          animationEasingUpdate: 'quinticInOut',
          series: []
        },
        showknowledgeTip: false,
        KnowledgeFour: '', // 四级知识点
        intermediateState: false,
        nickName: this.$route.query.nickName,
        KnowledgeFourId: '' // 三级知识点对应的四级知识点正确率倒数3位的id
      }
    },
    created() {
      this.loadingDetailData()
    },
    methods: {
      // 跳转到商品页面  2 阶段复习宝 1 名师精讲
      goToGoods(type) {
        // let url
        // if (type === 1) url = `/pages/homework/video/main?knowledgeIds=${this.KnowledgeFourId}`
        // else if (type === 2) url = `/pages/homework/browse/download/main?knowledgeIds=${this.KnowledgeFourId}`
        // window.wx.miniProgram.navigateTo({url: url})
        console.log(this.intermediateState)
        if (this.intermediateState) {
          let url
          if (type === 1) url = `/pages/homework/video/main?knowledgeIds=${this.KnowledgeFourId}`
          else if (type === 2) url = `/pages/homework/browse/main?knowledgeIds=${this.KnowledgeFourId}`
          window.wx.miniProgram.navigateTo({url: url})
        }
      },
      loadingDetailData() {
        let params = {
          studentId: this.$route.params.id,
          examId: this.$route.query.examId,
          lastExamId: this.$route.query.lastExamId
        }
        console.log(this.$route.query)
        reportService
          .knowAnalyDetail(params, res => {
            this.originData = res.data
            // 一级知识点
            this.firstLevel = [].concat(this.originData.firstLevelKnMastery)
            // 二级知识点
            this.secondLevel = [].concat(this.originData.secondLevelKnMastery)
            // 三级知识点
            this.thirdLevel = [].concat(this.originData.thirdLevelKnMastery)
            this.$nextTick(() => {
              this.init()
            })
          })
      },
      getKnowledges(params) {
        let result = []
        // 获取每个一级知识点对应的二， 三级知识点
        this.firstLevel.forEach((item, index) => {
          // 一级知识点
          item.level = 1
          let second = []
          let third = []
          let first = []
          let itemAccuracy = Math.round(item.accuracy * 100)
          if (params.knowledgeValue !== 1) {
            first = [item]
          } else if (params.knowledgeValue === 1 && itemAccuracy >= params.startAccuracy && itemAccuracy <= params.endAccuracy) {
            first = [item]
          }
          if (params.knowledgeValue > 1) {
            second = this.secondLevel.filter((subItem) => {
              let accuracy = Math.round(subItem.accuracy * 100)
              if (params.knowledgeValue === 2) {
                return subItem.parentId === item.knowledgePointId && accuracy >= params.startAccuracy && accuracy <= params.endAccuracy
              } else {
                return subItem.parentId === item.knowledgePointId
              }
            })
          }
          second.forEach((subItem) => {
            // 二级知识点
            subItem.level = 2
            if (params.knowledgeValue > 2) {
              third = third.concat(this.thirdLevel.filter((subItem1) => {
                let accuracy = Math.round(subItem1.accuracy * 100)
                return subItem1.parentId === subItem.knowledgePointId && accuracy >= params.startAccuracy && accuracy <= params.endAccuracy
              }))
            }
          })
          result[index] = [].concat(first, second, third)
        })
        return result
      },
      setContainer() {
        this.$refs.mychart.style.height = 300 * this.firstLevel.length + 'px'
      },
      // 知识点详情盒子
      hideknowledge(ev) {
        if (ev.target.nodeName !== 'SECTION') return
        if (timer) clearTimeout(timer)
        // 延迟 200 秒  解决echart的点击事件相应问题
        timer = setTimeout(() => {
          this.showknowledgeTip = false
        }, 200)
      },
      init(params = {}) {
        this.setContainer()
        let result = this.getKnowledges({
          knowledgeValue: params.knowledgeValue || 3,
          startAccuracy: params.startAccuracy || 0,
          endAccuracy: params.endAccuracy || 100
        })
        // 配置项
        result.forEach((item, index) => {
          this.option.series[index] = knowledgeMap.setSeries(item, index)
          this.option.series[index].data = knowledgeMap.setNode(item)
          this.option.series[index].links = this.option.series[index].data.map((subItem) => {
            return {
              source: subItem.parentId,
              target: subItem.id
            }
          })
        })
        this.setEchart()
      },
      // 生成图表
      setEchart() {
        let dom = this.$refs.mychart
        let chartInstance = echarts.getInstanceByDom(dom)

        // 判断是否存在实例，防止多次实例化
        if (!chartInstance) {
          this.myChart = echarts.init(dom)
          // 显示详情
          this.myChart.on('click', (data) => {
            if (data.dataType === 'node' && !this.showknowledgeTip) {
              this.showknowledgeTip = true
              this.knowledgeTip = data.data
              this.getKnowledgeFour()
              this.intermediateState = false
              // 解决点击知识点时，立刻跳转的问题
              if (intermediateTimer) clearTimeout(intermediateTimer)
              intermediateTimer = setTimeout(() => {
                this.intermediateState = true
              }, 200)
            }
          })
        }

        this.myChart.showLoading()
        this.myChart.setOption(this.option)
        this.myChart.hideLoading()
      },
      // 获取四级知识点
      getKnowledgeFour() {
        let params = {
          studentId: this.$route.params.id,
          parentId: this.knowledgeTip.id
        }
        reportService.getKnowledgeFour(params).then((res) => {
          let arr = res.data.map((item, index) => {
            return item.knowledgePointName
          })
          // 四级知识点正确率倒数三位的id
          let knowledgeIds = res.data.sort((a, b) => {
            return a.accuracy - b.accuracy
          }).filter((item, index) => {
            return index < 3
          }).map((item, index) => {
            return item.knowledgePointId
          })
          this.KnowledgeFourId = knowledgeIds.join(',')
          let result = arr.map((item) => {
            return '【' + item + '】'
          }).filter((item, index) => {
            return index < 10
          })
          if (res.data.length > 10) {
            this.KnowledgeFour = result.join('、') + '等'
          } else {
            this.KnowledgeFour = result.join('、')
          }
        })
      }
    }
  }
</script>
<style scoped>
  .button {
    padding: 10px 15px;
    background: #F56560;
    border-radius: 4px;
    color: #ffffff;
    margin: 23px;
  }
  .point-text {
    font-size: 12px;
    color: #999999;
    padding: 10px 0;
  }
  .part {
    font-size: 12px;
    color: #666666;
    line-height: 20px;
  }
  .info {
    padding: 14px 0px 8px;
    text-align: center;
    background: #ffffff;
    &>p:first-of-type {
      font-size: 16px;
      color: #333333;
      font-weight: 700;
      line-height: 20px;
    }
    & .update-time {
      font-size: 12px;
      color: #999999;
      line-height: 26px;
    }
  }
  .score {
    margin-top: 10px;
    background: #ffffff;
    &>span:first-of-type {
      display:inline-block;
      width: 100%;
      height: 36px;
      line-height: 36px;
      border-bottom:solid 1px #dddddd;
      font-size: 14px;
      padding-left: 15px;
      color: #999999;
    }
    &>.button {
      display: inline-block;
      width: 134px;
      height: 36px;
      background: #F56560;
      color: #ffffff;
      text-align: center;
      line-height: 37px;
    }
  }
  .echart {
    background: #ffffff;
  }
  .tip {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    background: rgba(0,0,0,0.30);
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: center;
    & .inner-box {
      width: 350px;
      padding: 20px 20px;
      background: #FFFFFF;
      border-radius: 4px;
      position: relative;
      & .display-flex {
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }
    & .cancel-btn {
        width: 27px;
        height: 27px;
        position: absolute;
        right: 4px;
        top: 4px;
        border-radius: 100%;
        background: url(~assets/imgs/ico_closed1.png) no-repeat 0 0;
        background-size: 27px 27px;
    }
    & .knowledge-name {
      line-height: 40px;
      font-size: 16px;
      color: #333333;
      font-weight: 700;
      text-align: center;
    }
    & .accuracy {
      line-height: 20px;
      font-size: 16px;
      color: #333333;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      & .green-color {
        color: #24CB72;
      }
      & .red-color {
        color: #E53F3F;
      }
    }
  }
</style>
