<template lang='pug'>
  div
    section.detail
      .report-title {{name}}&nbsp;知识图谱报告
      div(style="text-align:center")
        p.score 评分
          span.green-color {{originData.totalScore || 0}}分
          span &nbsp;（总分100分）
        p.create-time 更新时间：{{originData.createTime}}
    section.condition-btn(@click="showConditionBox($event, true)")
      img(src="~assets/imgs/ic_filtrate.png")
      span 筛选
    section.condition-box(v-show="showConditionBoxState", @click="showConditionBox($event, false)")
      .inner-box
        condition.condition(@selectCondition="selectCondition")
    .echart
      section(ref='mychart')
    section.tip(ref="knowledgeTip", v-if="showknowledgeTip",@touchend="hideknowledge")
      .inner-box
        div.display-flex
          p.knowledge-name {{knowledgeTip.name}}
          p.accuracy.display-flex &nbsp;&nbsp;正确率：{{knowledgeTip.value}}%&nbsp;&nbsp;
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy>knowledgeTip.lastAccuracy",src="~assets/imgs/fa-arrow-up.png", width=21, height=24)
            span.green-color(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy>knowledgeTip.lastAccuracy") &nbsp;&nbsp;+{{Math.round((knowledgeTip.accuracy - knowledgeTip.lastAccuracy) * 100)}}%
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy<knowledgeTip.lastAccuracy",src="~assets/imgs/ico_decline.png", width=21, height=24)
            span.red-color(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy<knowledgeTip.lastAccuracy") &nbsp;&nbsp;-{{Math.round((knowledgeTip.lastAccuracy - knowledgeTip.accuracy) * 100)}}%
            img(v-if="!knowledgeTip.newLearn && knowledgeTip.accuracy==knowledgeTip.lastAccuracy",src="~assets/imgs/ico_flat.png", width=24, height=24)
            span(v-if="knowledgeTip.newLearn",style="display:inline-block;font-size:12px;color: #FF5353;transform:scale(0.83)") NEW
        .accuracy-100(v-if="knowledgeTip.accuracy == 1")
          img(src="~assets/imgs/ic_good.png")
        .mention(v-if="knowledgeTip.level == 3 && knowledgeTip.accuracy != 1")
          .mention-point
            p.point-text &nbsp;提分锦囊
          .part 
            span 去
            span.color-green(@touchend="goToGoods(3)") 名师精讲
            span 中观看“{{knowledgeTip.name}}”的知识点视频。
          .part
            span 去错题本-
            span.color-blue(@touchend="goToGoods(1)") 错题周题练
            span 和
            span.color-blue(@touchend="goToGoods(2)") 阶段复习宝
            span 中
            span.font-weight 优先
            span 分享并下载与以下知识点相关的错题。
          .part
            span(v-if="KnowledgeFour") {{KnowledgeFour}}
            span(v-if="!KnowledgeFour") 暂无
        section.cancel-btn(@touchend="hideknowledge")

</template>
<script>
  import knowledgeMap from '@/utils/knowledgeMap'
  // 图例距离容器顶部的距离
  // const toTop = 500
  // 每行的图例个数
  // const rowNum = 2
  let timer, intermediateTimer
  import echarts from 'echarts'
  import reportService from '@/services/report'
  import '@/libs/TGJSBridge/index.js'
  export default {
    name: 'knowledgeMap',
    data() {
      return {
        name: this.$route.query.name,
        originData: {},
        knowledgeTip: {},
        showknowledgeTip: false,
        showConditionBoxState: false,
        KnowledgeFour: '', // 四级知识点
        option: {
          animationDurationUpdate: 1500,
          animationEasingUpdate: 'quinticInOut',
          series: []
        },
        intermediateState: false,
        KnowledgeFourId: '' // 三级知识点对应的四级知识点正确率倒数3位的id
      }
    },
    mounted() {
      this.loadingDetailData()
    },
    methods: {
      // 跳转到商品页面 1 错题周题练 2 阶段复习宝 3 三好名师精讲
      goToGoods(type) {
        if (this.intermediateState) {
          this.phoneCallback({type: type, knowledgeId: this.KnowledgeFourId})
        }
      },
      // 手机端回调函数
      phoneCallback(data) {
        if (window.androidSDK && window.androidSDK.knowledgeMapWebGotoWrongBook) {
          window.androidSDK.knowledgeMapWebGotoWrongBook(data.type, data.knowledgeId)
        } else if (window.jsBridge) {
          window.jsBridge.postNotification('knowledgeMapWebGotoWrongBook', {
            data: data
          })
        }
      },
      // 知识点详情盒子
      hideknowledge(ev) {
        if (ev.target.nodeName !== 'SECTION') return
        if (timer) clearTimeout(timer)
        // 延迟 200 秒  解决echart的点击事件相应问题
        timer = setTimeout(() => {
          this.showknowledgeTip = false
        }, 200)
      },
      // 显示筛选条件盒子
      showConditionBox(ev, state) {
        if (ev.target.nodeName !== 'SECTION' && !state) return
        if (!this.showConditionBoxState) this.showConditionBoxState = true
        else this.showConditionBoxState = false
      },
      loadingDetailData() {
        let params = {
          studentId: this.$route.params.id,
          examId: this.$route.query.examId,
          lastExamId: this.$route.query.lastExamId
        }
        reportService
          .knowAnalyDetail(params, res => {
            this.loading = false
            this.originData = res.data
            // 一级知识点
            this.firstLevel = [].concat(this.originData.firstLevelKnMastery)
            // 二级知识点
            this.secondLevel = [].concat(this.originData.secondLevelKnMastery)
            // 三级知识点
            this.thirdLevel = [].concat(this.originData.thirdLevelKnMastery)
            this.$nextTick(() => {
              this.init()
            })
          })
      },
      selectCondition(params) {
        this.init(params)
      },
      setContainer() {
        // 设置容器的高度  每个一级知识点对应的高度为500， 每行放4个
        // let height = Math.ceil(this.originData.firstLevelKnMastery.length / rowNum) * toTop
        if (this.$refs.mychart) this.$refs.mychart.style.height = document.documentElement.clientHeight + 'px'
      },
      getKnowledges(params) {
        let result = []
        // 获取每个一级知识点对应的二， 三级知识点
        this.firstLevel.forEach((item, index) => {
          // 一级知识点
          item.level = 1
          let second = []
          let third = []
          let first = []
          let itemAccuracy = Math.round(item.accuracy * 100)
          if (params.knowledgeValue !== 1) {
            first = [item]
          } else if (params.knowledgeValue === 1 && itemAccuracy >= params.startAccuracy && itemAccuracy <= params.endAccuracy) {
            first = [item]
          }
          if (params.knowledgeValue > 1) {
            second = this.secondLevel.filter((subItem) => {
              let accuracy = Math.round(subItem.accuracy * 100)
              if (params.knowledgeValue === 2) {
                return subItem.parentId === item.knowledgePointId && accuracy >= params.startAccuracy && accuracy <= params.endAccuracy
              } else {
                return subItem.parentId === item.knowledgePointId
              }
            })
          }
          second.forEach((subItem) => {
            // 二级知识点
            subItem.level = 2
            if (params.knowledgeValue > 2) {
              third = third.concat(this.thirdLevel.filter((subItem1) => {
                let accuracy = Math.round(subItem1.accuracy * 100)
                return subItem1.parentId === subItem.knowledgePointId && accuracy >= params.startAccuracy && accuracy <= params.endAccuracy
              }))
            }
          })
          result[index] = [].concat(first, second, third)
        })
        return result
      },
      init(params = {}) {
        this.$nextTick(() => {
          this.setContainer()
          let result = this.getKnowledges({
            knowledgeValue: params.knowledgeValue || 3,
            startAccuracy: params.startAccuracy || 0,
            endAccuracy: params.endAccuracy || 100
          })
          let resultData = []
          result.forEach((item) => {
            resultData = resultData.concat(item)
          })
          /**
           * 知识点的数量大于30个 知识点直间的斥力为原始大小
           * 知识点的数量大于10个 知识点直间的斥力为原始大小的2倍
           * 知识点的数量小于10 知识点直间的斥力为原始大小的3倍
           */
          let knowledgeLevel = 0
          if (resultData.length >= 30) knowledgeLevel = 3
          else if (resultData.length >= 10) knowledgeLevel = 2
          else knowledgeLevel = 1
          // 配置项
          this.option.series[0] = knowledgeMap.setSeries(resultData, knowledgeLevel, 1)
          this.option.series[0].data = knowledgeMap.setNode(resultData)
          this.option.series[0].links = this.option.series[0].data.map((subItem) => {
            return {
              source: subItem.parentId,
              target: subItem.id
            }
          })
          this.setEchart()
        })
      },
      // 生成图表
      setEchart() {
        let dom = this.$refs.mychart
        let chartInstance = echarts.getInstanceByDom(dom)

        // 判断是否存在实例，防止多次实例化
        if (!chartInstance) {
          this.myChart = echarts.init(dom)
          // 显示详情
          this.myChart.on('click', (data) => {
            if (data.dataType === 'node' && !this.showknowledgeTip) {
              this.showknowledgeTip = true
              this.knowledgeTip = data.data
              this.getKnowledgeFour()
              this.intermediateState = false
              // 解决点击知识点时，立刻跳转的问题
              if (intermediateTimer) clearTimeout(intermediateTimer)
              intermediateTimer = setTimeout(() => {
                this.intermediateState = true
              }, 1000)
            }
          })
        }

        this.myChart.showLoading()
        this.myChart.setOption(this.option)
        this.myChart.hideLoading()
      },
      // 获取四级知识点
      getKnowledgeFour() {
        let params = {
          studentId: this.$route.params.id,
          parentId: this.knowledgeTip.id
        }
        reportService.getKnowledgeFour(params).then((res) => {
          let arr = res.data.map((item, index) => {
            return item.knowledgePointName
          })
          // 四级知识点正确率倒数三位的id
          let knowledgeIds = res.data.sort((a, b) => {
            return a.accuracy - b.accuracy
          }).filter((item, index) => {
            return index < 3
          }).map((item, index) => {
            return item.knowledgePointId
          })
          this.KnowledgeFourId = knowledgeIds.join(',')
          let result = arr.map((item) => {
            return '【' + item + '】'
          }).filter((item, index) => {
            return index < 10
          })
          if (res.data.length > 10) {
            this.KnowledgeFour = result.join('、') + '等'
          } else {
            this.KnowledgeFour = result.join('、')
          }
        })
      }
    }
  }
</script>
<style scoped>
  .accuracy-100 {
    text-align: center;
  }
  .detail {
    position: fixed;
    top: 0px;
    left: 0px;
    z-index: -1;
    width: 100%;
  }
  .mention {
    & .mention-point {
      display: flex;
      padding-top: 13px;
      & .point-text {
        font-size: 14px;
        color: #AC9C51;
        padding-left: 16px;
        background:url(~assets/imgs/ic_bag.png) no-repeat 0 0;
      }
    }
    & .part {
      font-size: 12px;
      padding: 4px 0;
      line-height: 20px;
      & .color-blue {
        width: 98px;
        height: 26px;
        line-height: 14px;
        text-align: center;
        font-size: 14px;
        color: #FFFFFF;
        background: #EB5F2C;
        border-radius: 10px;
        display: inline-block;
        padding: 5px 10px;
        margin: 0px 5px;
        border: 1px solid #B75722;
        box-shadow: 0 2px 0 0 #CABB62, inset 2px 2px 0 0 rgba(255,255,255,0.50);
      }
      & .color-green {
        width: 98px;
        height: 26px;
        line-height: 14px;
        text-align: center;
        font-size: 14px;
        display: inline-block;
        padding: 5px 10px;
        color: #FFFFFF;
        margin: 0px 5px;
        background: #65BB24;
        border: 1px solid #5AA311;
        box-shadow: 0 2px 0 0 #CABB62, inset 2px 2px 0 0 rgba(255,255,255,0.50);
        border-radius: 10px;
      }
      & .font-weight {
        color: #000000;
        font-weight: 700
      }
    }
  }
  .condition-btn {
    width: 94px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #48B8FF;
    border-radius: 29px;
    font-size: 16px;
    color: #FFFFFF;
    position: fixed;
    left: 17px;
    top: 10px;
    z-index: 11
  }
  .condition-box {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    background: rgba(0,0,0,0.30);
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: center;
    & .inner-box {
      width: 515px;
      padding: 60px 40px;
      background: #FFFFFF;
      border-radius: 7px;
    }
  }
  .tip {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    background: rgba(0,0,0,0.30);
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: center;
    & .inner-box {
      width: 445px;
      padding: 20px 20px;
      background: #FFF8D4;
      border: solid 3px #DECF84;
      border-radius: 10.4px;
      position: relative;
      & .display-flex {
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }
    & .cancel-btn {
        width: 27px;
        height: 27px;
        position: absolute;
        right: -8px;
        top: -8px;
        border-radius: 100%;
        background: url(~assets/imgs/ic_frame_cancel.png) no-repeat 0 0;
    }
    & .knowledge-name {
      line-height: 40px;
      font-size: 18px;
      color: #AC9C51;
      font-weight: 500;
      text-align: center;
    }
    & .accuracy {
      line-height: 40px;
      font-size: 16px;
      color: #333333;
      display: flex;
      align-items: center;
      justify-content: center;
      & .green-color {
        color: #24CB72;
      }
      & .red-color {
        color: #E53F3F;
      }
    }
  }
  .echart {
    width: 100%;
    position: relative;
  }
  .score {
    font-size: 12px;
    color: #333333;
    font-weight: 500;
    text-align: center;
    display: inline-block;
    & .green-color {
      color: #109018;
      font-size: 14px;
    } 
  }
  .report-title {
    font-size: 18px;
    color: #333333;
    font-weight: 500;
    text-align: center;
    padding-top: 10px;
  }
  .create-time {
    color: #999;
    text-align: center;
    font-size: 12px;
    padding: 5px 0;
    display: inline-block;
  }
</style>
