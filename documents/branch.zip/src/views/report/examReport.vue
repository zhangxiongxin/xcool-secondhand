<template lang="pug">
  section(v-loading = "loading",style="font-size:16px")
    .gradient(style="padding-left:3%;padding-right:2.7%")
      .reportTitle
        span.mr-10(style="font-weight:bold;") {{reportData.studentName}}  
        span(style="font-weight: bold;") {{reportData.reportName}}
      div(style="display:flex",v-if="reportData.scoreDistribute")
        report-item(type="score", dd-class="level-good", :data="reportData")
        report-item(type="rank", :data="reportData")
      hr.hr
      .reportDetail
        personal-extra-table(:studentId="params.studentId", reportType="exam")
        dd-table(:structuredData="structuredData", reportType="exam")
      footer
</template>
<script>
  import store from '@/store'
  import { examReport } from '@/store/types'

  export default {
    name: 'personalReport',
    data() {
      return {
      }
    },
    computed: {
      structuredData() {
        return {
          tables: [{
            itemTitle: '题目得分一览',
            tableData: this.reportData.scoreDistribute,
            tableFields: [{
              prop: 'questionType',
              label: '题型'
            }, {
              prop: 'numInPaper',
              label: '题号'
            }, {
              prop: 'questionScore',
              label: '满分'
            }, {
              prop: 'studentScore',
              label: '得分'
            }, {
              prop: 'scoreRate',
              label: '得分率'
            }, {
              prop: 'knowledgePoint',
              label: '该题涉及的四级知识点'
            }]
          }, {
            itemTitle: '知识点',
            tableData: this.reportData.knowledgeDistribute,
            tableFields: [{
              prop: 'knowledgePointName',
              label: '四级知识点'
            }, {
              prop: 'accuracy',
              label: '正确率'
            }, {
              prop: 'totalCount',
              label: '出现次数'
            }, {
              prop: 'rightCount',
              label: '正确次数'
            }, {
              prop: 'questionNumText',
              label: '含该知识点的题目'
            }]
          }]
        }
      },
      reportData() {
        return store.state.report.reportData
      },
      params() {
        return this.$route.params
      },
      loading() {
        return store.state.report.loading
      }
    },
    created() {
      store.dispatch(examReport, this.params).then(() => {
      })
    }
  }
</script>
<style scoped>
  .reportTitle{
    padding:30px 0px;
    font-size: 20px;
    text-align: center;
  }
  .pass,.average {
    width: 216px;
    height: 110px;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: #FFF1A4;
    margin-right: 30px;
    color: #C39B41;
  }
  .average{
    color: #5B81F5;
    background: #D9E2FF;
  }
  .big {
    font-size: 36px;
  }
</style>
