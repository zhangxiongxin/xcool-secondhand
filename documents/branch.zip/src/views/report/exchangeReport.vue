<template lang="pug">
  section(style="background:#FFFFFC",v-loading="loading")
    .recharge
      .text 仅可查询含当月在内的近24个月的兑换记录
      table
        thead
          tr
            td 兑换时间
            td(v-if="vip") 卡号
            td 兑换码
            td 金额（元）
            td(v-if="!vip") 入账学豆数
            td(v-if="!vip") 充值学豆数
            td(v-if="vip") 卡对应的套餐名
            td(v-if="vip") 有效期
            td(v-if="!vip") 赠送学豆数
            td(v-if="!vip") 验证状态
        tbody
          tr
          tr(v-if="exchangeRecord.length",v-for="item in exchangeRecord")
            td {{item.exchangeTime | date('yyyy-MM-dd HH:mm:ss')}}
            td(v-if="vip") {{item.exchangeCardId}}
            td {{item.exchangeCode}}
            td {{vip ? item.chargeMoney : item.money}}
            td(v-if="!vip") {{item.incomeDdAmt}}
            td(v-if="!vip") {{item.rechargeDdAmt}}
            td(v-if="vip") {{item.productSuiteName}}
            td(v-if="vip") {{item.startTime | date('yyyy-MM-dd')}}-{{item.stopTime | date('yyyy-MM-dd')}}
            td(v-if="!vip") {{item.giftDdAmt}}
            td(v-if="!vip") {{item.verifyStatus}}
          tr(v-if="!exchangeRecord.length")
            td(colspan="7") 暂无数据
      .load-more(:class="{visible: loadMore}")
        i.el-icon-loading
        span  加载更多
</template>
<script>
  import scroll from '@/utils/scroll'
  import embeddedPageService from '@/services/embeddedPage'
  const pageSize = 30
  export default {
    name: 'exchangeReport',
    data() {
      return {
        loadMore: false,
        studentId: this.$route.params.studentId,
        vip: this.$route.query.type,
        pageNum: 1,
        loading: false,
        exchangeRecord: []
      }
    },
    methods: {
      getData() {
        // vip兑换记录
        if (this.vip) {
          embeddedPageService.vipExchangeRecord({studentId: this.studentId, pageNum: this.pageNum, pageSize: pageSize}).then(res => {
            this.loadMore = false
            this.loading = false
            this.exchangeRecord = [].concat(this.exchangeRecord, res.data)
          })
        } else {
          embeddedPageService.exchangeRecord({studentId: this.studentId, pageNum: this.pageNum, pageSize: pageSize}).then(res => {
            this.loadMore = false
            this.loading = false
            this.exchangeRecord = [].concat(this.exchangeRecord, res.data.items)
          })
        }
      }
    },
    created() {
      scroll(() => {
        let pageNum = Math.floor(this.exchangeRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) this.loadMore = false
        else this.loadMore = true
      }, () => {
        let pageNum = Math.floor(this.exchangeRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) return
        this.pageNum = pageNum
        this.getData()
      })
      this.loading = true
      this.getData()
    }
  }
</script>
<style scoped>
.visible {
  visibility: visible!important;
}
.load-more {
  visibility: hidden;
  text-align: center;
  padding-top: 10px;
}
.recharge {
  font-size:12px;
  background: #FFFFFC;
  padding:16px 35px;
  color: #666666;
  & table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 12px;
    & tr:nth-child(2n) {
      background: #FFFFff;
    }
    & tr:nth-child(2n + 1) {
      background: #FFFFEC;
    }
    & td {
      border: 1px solid #8F8F8D;
      text-align: center;
      height: 36px;
    }
  }
}
</style>
