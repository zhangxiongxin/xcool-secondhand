<template lang="pug">
  router-view.body-container
</template>
<script>
  export default {
    name: 'report'
  }
</script>
<style scoped>
</style>
