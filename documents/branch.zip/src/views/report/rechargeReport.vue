<template lang="pug">
  section(style="background:#FFFFFC",v-loading="loading")
    .recharge
      .text 仅可查询含当月在内的近24个月的充值记录
      table
        thead
          tr
            td 资金流水号
            td 创建时间
            td 充值金额(元)
            td 充值方式
            td 入账学豆数
            td 充值学豆数
            td 赠送学豆数
            td 充值状态
        tbody
          tr
          tr(v-if="rechargeRecord.length",v-for="item in rechargeRecord")
            td {{item.rechargeNum}}
            td {{item.createTime | date('yyyy-MM-dd HH:mm:ss')}}
            td {{item.rechargeMoney}}
            td {{item.rechargeType | rechargeType}}
            td {{item.totalDdAmt}}
            td {{item.rechargeDdAmt}}
            td {{item.returnDdAmt}}
            td {{item.rechargeStatus | rechargeStatus}}
          tr(v-if="!rechargeRecord.length")
            td(colspan="8") 暂无数据
      .load-more(:class="{visible: loadMore}")
        i.el-icon-loading
        span  加载更多
</template>
<script>
  import scroll from '@/utils/scroll'
  import embeddedPageService from '@/services/embeddedPage'
  const pageSize = 30
  export default {
    name: 'rechargeReport',
    data() {
      return {
        studentId: this.$route.params.studentId,
        loadMore: false,
        rechargeRecord: [],
        pageNum: 1,
        loading: false
      }
    },
    methods: {
      getData() {
        embeddedPageService.rechargeRecord({studentId: this.studentId, pageNum: this.pageNum, pageSize: pageSize}).then(res => {
          this.loadMore = false
          this.loading = false
          this.rechargeRecord = [].concat(this.rechargeRecord, res.data.items)
        })
      }
    },
    created() {
      scroll(() => {
        let pageNum = Math.floor(this.rechargeRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) this.loadMore = false
        else this.loadMore = true
      }, () => {
        let pageNum = Math.floor(this.rechargeRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) return
        this.pageNum = pageNum
        this.getData()
      })
      this.loading = true
      this.getData()
    }
  }
</script>
<style scoped>
.no-data{
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.visible {
  visibility: visible!important;
}
.load-more {
  visibility: hidden;
  text-align: center;
  padding-top: 10px;
}
.recharge {
  font-size:12px;
  background: #FFFFFC;
  padding:16px 35px;
  color: #666666;
  & table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 12px;
    & tr:nth-child(2n) {
      background: #FFFFff;
    }
    & tr:nth-child(2n + 1) {
      background: #FFFFEC;
    }
    & td {
      border: 1px solid #8F8F8D;
      text-align: center;
      height: 36px;
    }
  }
}
</style>
