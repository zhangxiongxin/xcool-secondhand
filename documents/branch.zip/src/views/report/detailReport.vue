<template lang="pug">
  section(style="background:#FFFFFC", v-loading="loading")
    .detail(v-if="studentDetail.studentName")
      .name
        .student {{studentDetail.studentName}}
        .class(v-for="item in studentDetail.schoolList") {{item.name + " " + item.className}}
      .balance
        span.text 可用学豆：
        span.number {{studentDetail.totalDdAmt}}学豆（充值学豆{{studentDetail.rechargeDdAmt}}个+赠送学豆{{studentDetail.returnDdAmt + studentDetail.rewardDdAmt}}个）
      .tip 仅可查询含当月在内的近24个月的学豆使用详情
      div(v-if="detailRecord.length")
        goods-item.goods-item(v-for="item, index in detailRecord", :key="index", :items="item",:class="{'background-color': index%2==0}")
          template(slot="productList")
            goods-item.goods-item(v-for="subItem, subIndex in item.productList", :key="subIndex",:items="subItem")
        .load-more(:class="{visible: loadMore}")
          i.el-icon-loading
          span  加载更多
</template>
<script>
  import scroll from '@/utils/scroll'
  import embeddedPageService from '@/services/embeddedPage'
  const pageSize = 10
  export default {
    name: 'detailReport',
    data() {
      return {
        studentId: this.$route.params.studentId,
        loadMore: false,
        detailRecord: [],
        pageNum: 1,
        loading: false,
        studentDetail: {}
      }
    },
    methods: {
      getStudentDetail() {
        embeddedPageService.consumeStudentDetail({studentId: this.studentId}).then(res => {
          this.handle(res.data)
          this.getData()
        }).catch((err) => {
          console.log(err)
          this.loading = false
        })
      },
      handle(data) {
        data.schoolList.forEach((item) => {
          let name = item.classList.map((subItem) => {
            return subItem.name
          })
          item.className = name.join('/')
        })
        this.studentDetail = data
      },
      getData() {
        embeddedPageService.consumeGoodsList({studentId: this.studentId, pageNum: this.pageNum, pageSize: pageSize}).then(res => {
          this.loadMore = false
          this.loading = false
          this.detailRecord = [].concat(this.detailRecord, res.data.items)
        }).catch((err) => {
          console.log(err)
          this.loadMore = false
          this.loading = false
        })
      }
    },
    created() {
      scroll(() => {
        let pageNum = Math.floor(this.detailRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) this.loadMore = false
        else this.loadMore = true
      }, () => {
        let pageNum = Math.floor(this.detailRecord.length / pageSize) + 1
        if (this.pageNum === pageNum) return
        this.pageNum = pageNum
        this.getData()
      })
      this.loading = true
      this.getStudentDetail()
    }
  }
</script>
<style scoped>
.background-color {
  background-color: rgba(222,255,252,0.35);
}
.visible {
  visibility: visible!important;
}
.load-more {
  visibility: hidden;
  text-align: center;
  padding-top: 10px;
}
.detail {
  font-size:14px;
  padding: 10px 0px;
  background: #FFFFFC;
  color: #666666;
  & .goods-item {
    padding:18px 24px;
  }
  & .name {
    text-align: center;
    line-height: 24px;
    font-weight: 600;
  }
  & .balance {
    line-height: 24px;
    font-weight: 600;
    padding: 10px 24px 5px;
    & .number {
      color:#EC726D;
    }
  }
  & .tip {
    font-size: 12px;
    padding: 0px 24px;
  }
}
</style>
