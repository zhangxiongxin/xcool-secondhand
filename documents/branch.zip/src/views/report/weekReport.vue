<template lang="pug">
  section(style="font-size:16px",v-loading = "loading")
    .flex-sb.text-align(style="padding-left:3%")
      span.mr-10(style="font-size:18px;font-weight:bold;color:#333333") {{reportData.studentName}}   
      span.mr-10(style="font-size:18px;font-weight:bold;color:#333333") {{reportData.reportName}}
    p.text-align(v-if="reportData.scoreDistribute",style="color: #999999;font-size:16px;padding-left:3%;padding-bottom:10px") 当前已有 {{reportData.done}} 位同学的考试批阅完成进入本次统计
    div(style="display:flex;padding-left:3%;flex-wrap:wrap",v-if="reportData.scoreDistribute")
      report-item(type="weeklyScore", dd-class="level-good", :data="reportData")
      report-item(type="weeklyRank", :data="reportData")
      report-item(type="submit", :data="reportData",text="考试")
    hr.hr
    .reportDetail
      personal-extra-table(:studentId="params.studentId")      
      dd-table(:structuredData="structuredData")
</template>
<script>
  import store from '@/store'
  import { clearData, weekReport } from '@/store/types'
  export default {
    name: 'weekReport',
    data() {
      return {
      }
    },
    computed: {
      structuredData() {
        return {
          tables: [{
            itemTitle: '题目得分一览',
            tableData: this.reportData.scoreDistribute,
            tableFields: [{
              prop: 'questionType',
              label: '题型'
            }, {
              prop: 'numInPaper',
              label: '题号'
            }, {
              prop: 'questionScore',
              label: '满分'
            }, {
              prop: 'studentScore',
              label: '得分'
            }, {
              prop: 'scoreRate',
              label: '得分率'
            }, {
              prop: 'knowledgePoint',
              label: '该题涉及的四级知识点'
            }]
          }, {
            itemTitle: '知识点',
            tableData: this.reportData.knowledgeDistribute,
            tableFields: [{
              prop: 'knowledgePointName',
              label: '四级知识点'
            }, {
              prop: 'accuracy',
              label: '正确率'
            }, {
              prop: 'totalCount',
              label: '出现次数'
            }, {
              prop: 'rightCount',
              label: '正确次数'
            }, {
              prop: 'questionNumText',
              label: '含该知识点的题目'
            }]
          }]
        }
      },
      reportData() {
        return store.state.report.reportData
      },
      params() {
        return this.$route.params
      },
      loading() {
        return store.state.report.loading
      }
    },
    methods: {
    },
    destroyed() {
      store.commit(clearData)
    },
    created() {
      store.dispatch(weekReport, this.params).then(() => {})
    }
  }
</script>
<style scoped>
  .reportDetail {
    padding-top: 15px;
    padding-left: 3%;
    padding-right: 2.7%;
    height: 100%;
  }
  
  .pass {
    margin-left: 3%;
    width: 216px;
    height: 110px;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: #FFF1A4;
    margin-right: 30px;
    color: #C39B41;
  }
  
  .big {
    font-size: 36px;
  }
  
  .flex-sb {
    padding-top: 15px;
    padding-bottom: 10px;
  }
  .text-align {
    text-align:center;
  }
  
  .mr-10 {
    margin-right: 10px;
  }
  
  .gary-text {
    color: #bbb;
  }
</style>
