<template lang="pug">
  section(v-loading="loading",style="font-size:16px")
    .gradient(style="padding-left:3%;padding-right:2.7%")
      .reportTitle
        //- 教辅
        img(v-if="source==='1'" src="~assets/imgs/教辅.png" draggable="false" style='margin-right:9px' )
        //- 假期作业
        img(v-if="source==='2'" src="~assets/imgs/ico-vacation.png" draggable="false" style='margin-right:9px' )
        span.mr-10(style="font-weight: bold;") {{reportData.studentName}}
        span.mr-10(style="font-weight: bold;") {{reportData.reportName}}
      p(v-if="reportData.questionDistribute",style="color: #999999;font-size:16px;padding-bottom:10px;text-align:center") 当前已有 {{reportData.done}} 位同学的作业批阅完成进入本次统计
      div(style="display:flex;flex-wrap:wrap",v-if="reportData.questionDistribute")
        report-item(type="question", :data="reportData")
        report-item(type="accuray", :data="reportData")
        report-item(type="submit", :data="reportData")
      hr.hr
      .reportDetail
        personal-extra-table(:studentId="params.studentId",:source="source")
        dd-table(v-if="source==='0'", :structuredData="structuredData")
        dd-table(v-if="source==='1' || source==='2'", :structuredData="structuredData", source="1")
      footer
</template>
<script>
  import store from '@/store'
  import { homeworkReport } from '@/store/types'

  export default {
    name: 'personalReport',
    data() {
      return {}
    },
    computed: {
      structuredData() {
        return {
          profile: [{ title: '正确率', percent: (Math.round(this.reportData.accuracy * 100) || 0) + '%' }],
          tables: [{
            itemTitle: '题目对错一览',
            tableData: this.reportData.questionList,
            tableFields: [{
              prop: 'questionType',
              label: '题型'
            }, {
              prop: 'numInPaper',
              label: '题号'
            }, {
              prop: 'correct',
              label: '批阅结果'
            }, {
              prop: 'knowledgePoint',
              label: '该题涉及的四级知识点'
            }]
          }, {
            itemTitle: '知识点',
            tableData: this.reportData.knowledgeList,
            tableFields: [{
              prop: 'knowledgePointName',
              label: '四级知识点'
            }, {
              prop: 'accuracy',
              label: '正确率'
            }, {
              prop: 'totalCount',
              label: '出现次数'
            }, {
              prop: 'rightCount',
              label: '正确次数'
            }, {
              prop: 'questionNumText',
              label: '含该知识点的题目'
            }]
          }]
        }
      },
      reportData() {
        return store.state.report.reportData
      },
      params() {
        return this.$route.params
      },
      loading() {
        return store.state.report.loading
      },
      source() {
        return store.state.report.reportData.source + ''
      }
    },
    created() {
      store.dispatch(homeworkReport, this.params)
    }
  }
</script>
<style scoped>
  .reportTitle {
    padding: 30px 0px 10px;
    font-size: 20px;
    text-align: center;
  }
  .text-align{
    text-align: center;
  }
  .pass {
    width: 216px;
    height: 110px;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: #FFF1A4;
    margin-right: 30px;
    color: #C39B41;
  }
  .mr-10 {
    margin-right: 10px;
  }
  
  .big {
    font-size: 36px;
  }
</style>
