<template lang='pug'>
  div(style='padding: 30px 30px 10px 30px;', v-loading="loading", element-loading-text="拼命加载中")
    .title.center {{reportData.studentName}} 最近一周错题订正报告
    .time.center {{formatTime(reportData.startTime, 'startTime')}} 至 {{formatTime(reportData.endTime, 'endTime')}}
    .rate_contain
      .right_rate
        .rate_box.yellow.center
          p 错题订正正确率
          p.rate_num 
            span(v-if="(!reportData.hasReviseReport && (reportData.totalCount === 0)) || (reportData.hasReviseReport && (reportData.reviseRightRate === -1))") --
            span(v-else-if="!reportData.hasReviseReport && (reportData.totalCount !== 0)") 0%
            span(v-else-if="reportData.hasReviseReport && (reportData.reviseRightRate !== -1)") {{reportData.reviseRightRate | rateFilter}}
        div(v-if="reportData.classInfos && reportData.classInfos.length")
          template(v-if="!reportData.hasReviseReport && (reportData.totalCount === 0)")
            .compare
              .compare_item 你没有错题
              .good.one_class
                img(src='~assets/imgs/cheer1.png' draggable='false')
                span 真棒
          template(v-else-if="(!reportData.hasReviseReport && (reportData.totalCount !== 0)) || (reportData.hasReviseReport && (reportData.reviseRightRate !== -1))")
            .compare
              .compare_item(v-for="cla in reportData.classInfos", :key="cla.classId") 
                span {{ compareRate(reportData.reviseRightRate, cla.reviseRightRate) }}{{ reportData.classInfos.length > 1 ? cla.className : ''}}班级错题订正正确率
                .class_rate(v-if="cla.reviseRightRate === -1") (--)
                .class_rate(v-if="cla.reviseRightRate !== -1") ({{cla.reviseRightRate | rateFilter}})
              .good(v-if='reviseRightRateTip !== "not"', :class="{'one_class': reportData.classInfos && reportData.classInfos.length === 1, 'two_class': reportData.classInfos && reportData.classInfos.length > 1}")
                img(src='~assets/imgs/cheer1.png' draggable='false' v-if='reviseRightRateTip === "higher"')
                img(src='~assets/imgs/cheer2.png' draggable='false' v-if='reviseRightRateTip === "lower"')
                span {{reviseRightRateTip === "higher" ? '真棒' : '加油'}} 
      .correct_rate
        .rate_box.blue.center
          p 错题订正率
          p.rate_num 
            span(v-if="!reportData.hasReviseReport && (reportData.totalCount === 0)") --
            span(v-else-if="!reportData.hasReviseReport && (reportData.totalCount !== 0)") 0%
            span(v-else-if="reportData.hasReviseReport") {{reportData.reviseRate | rateFilter}}
        div(v-if="reportData.classInfos && reportData.classInfos.length")
          template(v-if="!reportData.hasReviseReport && (reportData.totalCount === 0)")
            .compare.blue_border
              .compare_item 你没有错题
              .good.one_class
                img(src='~assets/imgs/cheer1.png' draggable='false')
                span 真棒
          template(v-else)
            .compare.blue_border
              .compare_item(v-for="cla in reportData.classInfos", :key="cla.classId") 
                span {{ compareRate(reportData.reviseRate, cla.reviseRate) }}{{ reportData.classInfos.length > 1 ? cla.className : ''}}班级错题订正率
                .class_rate(v-if="cla.reviseRightRate === -1") (--)              
                .class_rate(v-if="cla.reviseRightRate !== -1") ({{cla.reviseRate | rateFilter}})
              .good(v-if='reviseRateTip !== "not"', :class="{'one_class': reportData.classInfos && reportData.classInfos.length === 1, 'two_class': reportData.classInfos && reportData.classInfos.length > 1}")
                img(src='~assets/imgs/cheer1.png' draggable='false' v-if='reviseRateTip === "higher"')
                img(src='~assets/imgs/cheer2.png' draggable='false' v-if='reviseRateTip === "lower"')
                span {{reviseRateTip === "higher" ? '真棒' : '加油'}} 
    .ques_count
      table   
        tr
          td 首次错题数
          td 已订正的错题数
          td 未订正的错题数
          td 错题订正正确次数
          td 错题订正错误次数
        tr
          td {{reportData.totalCount}}
          td {{reportData.reviseCount}}
          td {{reportData.notReviseCount}}
          td {{reportData.reviseRightCount}}
          td {{reportData.reviseNotRightCount}}
    .on_list(v-if="isInList")
      .on_list_title
        .good_icon
        span 上榜啦！真棒
      template(v-for="item in topTen")
        .on_list_table(v-if="inClassList(item)")
          .left
            div
              img(src='~assets/imgs/top.png' draggable='false')
            div(style="margin-left: 8px; text-align:center")
              p 错题订正正确率前十名
              p(v-if="topTen.length > 1", style="margin-top: 5px") ({{item.className}})
          .right
            p(v-for="(clas, index) in item.reviseRightRateHighers", :key='index', :class="{'name_in_list': reportData.studentId === clas.studentId}") {{clas.studentName}}({{clas.reviseRightRate | rateFilter}}) 
</template>
<script>
  import reportService from '@/services/report'
  import dateFilter from '@/filters/date'

  export default {
    name: 'errorCorrectReport',
    data() {
      return {
        loading: true,
        studentId: this.$route.params.studentId,
        classId: this.$route.params.classId,
        reportData: {},
        topTen: []
      }
    },
    methods: {
      formatTime(time, sign) {
        if (time) return dateFilter(time, 'yyyy-MM-dd')
        if (!time && sign === 'endTime') {
          let startDate = new Date()
          startDate.setDate(startDate.getDate() - 1)
          let startTime = startDate.getFullYear() + '-' + (startDate.getMonth() + 1) + '-' + startDate.getDate()
          return startTime
        } else if (!time && sign === 'startTime') {
          let endtDate = new Date()
          endtDate.setDate(endtDate.getDate() - 7)
          let endTime = endtDate.getFullYear() + '-' + (endtDate.getMonth() + 1) + '-' + endtDate.getDate()
          return endTime
        }
      },
      compareRate(personNum, classNum) {
        if (classNum === -1) return ''
        else if (personNum === classNum) return '等于'
        else if (personNum > classNum) return '高于'
        else return '低于'
      },
      loadRportData() {
        document.body.parentNode.style.overflow = 'hidden'
        this.reportData = []
        reportService
          .errorCorrectReport({ studentId: this.studentId })
          .then(res => {
            this.reportData = res.data

            let classIdList = res.data.classInfos.map((item) => {
              return item.classId
            })
            this.loadTopTen(classIdList.join(','))
          })
          .catch(() => {
            this.loading = false
            document.body.parentNode.style.overflow = 'auto'
          })
      },
      loadTopTen(classIds) {
        this.topTen = []
        reportService
          .getTopTen({ classIds: classIds })
          .then(res => {
            this.topTen = res.data.classInfos
            this.loading = false
            document.body.parentNode.style.overflow = 'auto'
          })
          .catch(() => {
            this.loading = false
            document.body.parentNode.style.overflow = 'auto'
          })
      },
      inClassList(obj) {
        var that = this
        return obj.reviseRightRateHighers.some((stu) => {
          return that.reportData.studentId === stu.studentId
        })
      }
    },
    computed: {
      isInList() {
        var that = this
        if (!that.topTen.length) return false

        return that.topTen.some(function(item) {
          return item.reviseRightRateHighers.some((stu) => {
            return that.reportData.studentId === stu.studentId
          })
        })
      },
      reviseRightRateTip() {
        if (this.reportData.classInfos && !this.reportData.classInfos.length) return ''
        let allHigher = this.reportData.classInfos.every((el) => {
          return el.reviseRightRate < this.reportData.reviseRightRate
        })
        let allLower = this.reportData.classInfos.every((el) => {
          return el.reviseRightRate >= this.reportData.reviseRightRate
        })
        let notHasRate = this.reportData.classInfos.some((el) => {
          return el.reviseRightRate === -1
        })
        if (allHigher && !allLower && !notHasRate) return 'higher'
        else if (!allHigher && allLower && !notHasRate) return 'lower'
        else return 'not'
      },
      reviseRateTip() {
        if (this.reportData.classInfos && !this.reportData.classInfos.length) return ''
        let allHigher = this.reportData.classInfos.every((el) => {
          return el.reviseRate < this.reportData.reviseRate
        })
        let allLower = this.reportData.classInfos.every((el) => {
          return el.reviseRate >= this.reportData.reviseRate
        })
        let notHasRate = this.reportData.classInfos.some((el) => {
          return el.reviseRightRate === -1
        })
        if (allHigher && !allLower && !notHasRate) return 'higher'
        else if (!allHigher && allLower && !notHasRate) return 'lower'
        else return 'not'
      }
    },
    mounted() {
      this.loadRportData()
    }
  }
</script>
<style scoped>
  .title {
    font-size: 20px;
    color: #333333;
  }
  
  .center {
    text-align: center;
  }
  
  .time {
    margin-top: 15px;
    font-size: 16px;
    color: #999999;
  }
  
  .rate_contain {
    margin-top: 34px;
    display: flex;
  }
  
  .rate_box {
    padding-top: 18px;
    font-size: 16px;
    width: 216px;
    height: 110px;
    border-radius: 12px;
  }
  
  .yellow {
    background: #FFF1A4;
    color: #C39B41;
  }
  
  .blue {
    background: #D9E2FF;
    color: #5B81F5;
  }
  
  .rate_num {
    font-size: 36px;
    margin-top: 15px;
  }
  
  .correct_rate {
    margin-left: 20px;
  }
  
  .compare {
    line-height: 22px;
    width: 216px;
    min-height: 52px;
    border-radius: 12px;
    padding: 4px 10px 0px 10px;
    font-size: 16px;
    margin-top: 5px;
    color: #666666;
    background: #FFFCED;
    border: 1px solid #F5E693;
    position: relative;
    & .compare_item {
      margin-bottom: 5px;
    }
    & .class_rate {
      display: inline-block;
      margin-left: 5px;
    }
    & .good {
      font-size: 16px;
      color: #FF9933;
      & img {
        max-width: 20px;
        max-height: 17px;
        vertical-align: middle;
        margin-right: 4px;
      }
      & span {
        width: 20px;
        vertical-align: middle;
      }
    }
    & .one_class {
      position: absolute;
      right: 10px;
      bottom: 2px;
    }
    & .two_class {
      text-align: right;
    }
  }
  
  .blue_border {
    background: #F6F8FF;
    border: 1px solid #B7C8FF;
  }
  
  .on_list {
    padding-bottom: 10px;
    border-top: 1px solid #D5EED7;
    padding-top: 20px;
    & .on_list_title {
      display: flex;
      align-items: center;
      & .good_icon {
        margin-right: 10px;
        width: 36px;
        height: 36px;
        display: inline-block;
        border-radius: 50%;
        background: url(~assets/imgs/shape.png) no-repeat 0 0;
        background-size: 36px 36px;
      }
      & > span {
        font-size: 20px;
        color: #333333;
      }
    }
    & .on_list_table {
      margin-top: 16px;
      min-height: 78px;
      border: 1px solid #6BC685;
      background: #F8FFF9;
      display: flex;
      & .left {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40%;
        border-right: 1px solid #6BC685;
        & > img {
          margin-right: 8px;
        }
      }
      & .right {
        width: 60%;
        padding: 5px 10px 5px 25px;
        display: flex;
        flex-wrap: wrap;
        & p {
          height: 30px;
          line-height: 30px;
          color: #666;
          margin-right: 15px;
        }
      }
    }
  }
  
  .name_in_list {
    color: #FF9937 !important;
  }
  
  .ques_count {
    padding: 30px 0px;
    & table {
      width: 100%;
      /*table-layout:fixed;*/
      & tr {
        height: 40px;
        font-size: 16px;
        color: #666666;
      }
      & tr:first-child {
        background: #E0F8E9;
        color: #222222;
      }
      & td {
        text-align: center;
        border: 1px solid #6BC685;
      }
    }
  }
</style>
<style>
  @media screen and (max-width: 600px) {
    .rate_box,
    .compare {
      width: 180px !important;
    }
  }
</style>
