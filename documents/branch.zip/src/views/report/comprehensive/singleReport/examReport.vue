<template lang="pug">
  //- 考试报告(C)
  div(style="padding-top:35px;")
    p(style="display:flex;align-items:center;")
    .class-profile(style="display:flex;align-items:center;")
      .pass
        span {{structuredData.profile[0].title}}
        span.big {{structuredData.profile[0].percent}}
    dd-table(:structuredData="structuredData")
</template>
<script>
  export default {
    name: 'examReport',
    props: ['examData'],
    data() {
      return {
        reportData: null,
        knowledgeData: null
      }
    },
    computed: {
      structuredData() {
        return {
          profile: [{ title: '分数', percent: this.examData ? this.examData.score : 0 }],
          tables: [{
            itemTitle: '题目得分一览',
            tableData: this.reportData,
            tableFields: [{
              prop: 'questionType',
              label: '题型'
            }, {
              prop: 'numInPaper',
              label: '题号'
            }, {
              prop: 'questionScore',
              label: '分数'
            }, {
              prop: 'studentScore',
              label: '得分'
            }, {
              prop: 'scoreRate',
              label: '得分率'
            }]
          }, {
            itemTitle: '知识点',
            tableData: this.knowledgeData,
            tableFields: [{
              prop: 'knowledgePointName',
              label: '知识点名称'
            }, {
              prop: 'totalCount',
              label: '出现人次'
            }, {
              prop: 'rightCount',
              label: '正确人次'
            }, {
              prop: 'accuracy',
              label: '正确率'
            }]
          }]
        }
      }
    },
    methods: {
      // [考试报告数据处理] 个人成绩单数据重构
      personalData(data, type) {
        let examId
        if (type === 1) {
          examId = data.examId
          data = data.questions
        } else data = data.scoreDistribute
        if (data) {
          const res = []
          data.forEach(v => {
            res.push({
              questionType: (function() {
                if (v.questionType === 'choice') {
                  return '单选题'
                }
                if (v.questionType === 'fill_in' || v.questionType === 'fillIn' || v.questionType === 'fillin') {
                  return '填空题'
                }
                if (v.questionType === 'solution') {
                  return '解答题'
                }
              })(),
              numInPaper: v.numInPaper,
              studentScore: (function() {
                if (v.modifyScore) {
                  if (v.modifyScore === -1) return v.studentScore
                  else return v.modifyScore
                } else {
                  if (v.modifyScore === 0) return v.modifyScore
                  else return v.studentScore
                }
              })(),
              questionScore: v.questionScore || v.score,
              questionId: v.questionId,
              examId: (function() {
                if (examId) return examId
                else return ''
              })(),
              scoreRate: (function() {
                return Math.round(v.studentScore / v.questionScore * 100) + '%'
              })()
            })
          })
          return res
        } else return data
      },
      // [考试报告数据处理] 知识点分布数据重构
      classKnowledge(data, type) {
        const res = []
        data.forEach(v => {
          res.push({
            knowledgePointName: v.knowledgePointName,
            totalCount: v.totalCount,
            rightCount: v.rightCount,
            accuracy: (function() {
              if (type === 1) return v.accuracy
              else if (type === 2) return v.rightCount / v.totalCount
            })()
          })
        })
        return res
      }
    },
    created() {
      // 数据重构
      this.reportData = this.personalData(this.examData)
      this.knowledgeData = this.classKnowledge(this.examData.knowledgeDistribute, 2)
    }
  }
</script>
<style scoped>
  .pass,
  .average {
    width: 216px;
    height: 110px;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  
  .pass {
    background: #EEE1FF;
    margin-right: 30px;
    color: #A779E8;
  }
  
  .average {
    color: #5B81F5;
    background: #D9E2FF;
  }
  
  .big {
    font-size: 36px;
  }
</style>
