<template lang='pug'>
  div
    //- 素质分析报告(A + B)          
    .quality-report-ab(v-if="qualityAnalyData && knowAnalyData")
      el-row.score(type="flex")
        el-col.total-score(:span="8", style="background-color: #D8FFAE;")
          p 总评分
          p {{totalScore | round}}分
          p 总分100分
        el-col.item-col(:span="8")
          ul.score-list.first-column
            li 作业与试卷完成情况
              //- span {{qualityAnalyData.taskComplete | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.taskCompleteStar", :max="qualityAnalyData.taskCompleteStar")
            li 学习能力
              //- span {{qualityAnalyData.learningAbility | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.learningAbilityStar", :max="qualityAnalyData.learningAbilityStar")
            li 学习态度
              //- span {{qualityAnalyData.attitude | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.attitudeStar", :max="qualityAnalyData.attitudeStar")
            li 学习方法
              //- span {{qualityAnalyData.method | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.methodStar", :max="qualityAnalyData.methodStar")
            li.no-border 知识点掌握情况
              //- span {{knowAnalyData.totalScore | round}}分
              el-rate.score-rate(disabled, v-model="knowAnalyData.totalScoreStar", :max="knowAnalyData.totalScoreStar")
        el-col.item-col(:span="8")
          ul.score-list.second-column
            li 错题解决情况
              //- span {{qualityAnalyData.problemSolution | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.problemSolutionStar", :max="qualityAnalyData.problemSolutionStar")
            li 学习兴趣
              //- span {{qualityAnalyData.interest | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.interestStar", :max="qualityAnalyData.interestStar")
            li 学习习惯
              //- span {{qualityAnalyData.habit | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.habitStar", :max="qualityAnalyData.habitStar")
            li 学习环境
              //- span {{qualityAnalyData.enviornment | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.enviornmentStar", :max="qualityAnalyData.enviornmentStar")

    //- 素质分析报告(A)
    .quality-report-a(v-if="qualityAnalyData && !knowAnalyData")
      .score.no-background
        .total-score(:span="8")
          p 总评分
          p {{qualityAnalyData.totalScore | round}}分
          p 总分100分
      el-row.score(type="flex")
        el-col(:span="12")
          ul.score-list.first-column
            li 作业与试卷完成情况
              //- span {{qualityAnalyData.taskComplete | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.taskCompleteStar", :max="qualityAnalyData.taskCompleteStar")
            li 学习能力
              //- span {{qualityAnalyData.learningAbility | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.learningAbilityStar", :max="qualityAnalyData.learningAbilityStar")
            li 学习态度
              //- span {{qualityAnalyData.attitude | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.attitudeStar", :max="qualityAnalyData.attitudeStar")
            li.no-border 学习方法
              //- span {{qualityAnalyData.method | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.methodStar", :max="qualityAnalyData.methodStar")
        el-col(:span="1")
          ul.score-list
            li
            li
            li
            li.no-border
        el-col(:span="11")
          ul.score-list.second-column
            li 错题解决情况
              //- span {{qualityAnalyData.problemSolution | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.problemSolutionStar", :max="qualityAnalyData.problemSolutionStar")
            li 学习兴趣
              //- span {{qualityAnalyData.interest | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.interestStar", :max="qualityAnalyData.interestStar")
            li 学习习惯
              //- span {{qualityAnalyData.habit | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.habitStar", :max="qualityAnalyData.habitStar")
            li.no-border 学习环境
              //- span {{qualityAnalyData.enviornment | round}}分
              el-rate.score-rate(disabled, v-model="qualityAnalyData.enviornmentStar", :max="qualityAnalyData.enviornmentStar")

</template>
<script>
  export default {
    name: 'qualityAnalyReport',
    props: ['qualityAnalyData', 'knowAnalyData', 'isAB', 'comprehensiveData'],
    computed: {
      // A+B 权重总分
      totalScore() {
        return this.comprehensiveData.totalScore || this.qualityAnalyData.taskComplete * 0.15 + this.qualityAnalyData.learningAbility * 0.1 + this.qualityAnalyData.problemSolution * 0.15 + this.qualityAnalyData.interest * 0.075 + this.qualityAnalyData.attitude * 0.075 + this.qualityAnalyData.habit * 0.15 + this.qualityAnalyData.method * 0.075 + this.qualityAnalyData.enviornment * 0.075 + this.knowAnalyData.totalScore * 0.15
      }
    },
    filters: {
      round(score) {
        return Math.round(score)
      }
    }
  }
</script>
<style scoped>
  .no-border {
    border: none !important;
  }
  
  .score {
    width: 100%;
    /*background-color: #EEE1FF;*/
    border-radius: 12px;
    text-align: center;
    overflow: hidden;
    &>.total-score {
      display: flex;
      flex-direction: column;
      justify-content: center;
      color: #53BA33;
      &>p:first-child {
        font-size: 18px;
        font-weight: 400;
      }
      &>p:nth-child(2) {
        font-size: 50px;
      }
    }
  }

  .score.el-row {
    border: 1px solid #7ABD64;
  }
  
  .score-list {
    text-align: left;
    &>li {
      border-bottom: 1px solid #7ABD64;
      text-indent: 30px;
      color: #333;
      height: 40px;
      line-height: 38px;
      &>span {
        float: right;
        margin-right: 46px;
        color: #A779E8;
        font-size: 18px;
      }
    }
  }

  .score-list.first-column {
    padding-left: 20px;
  }

  .score-list.second-column {
    padding-right: 20px;
    &>li {
      text-indent: 20px;
    }
  }

  .quality-report-ab {
    & .score-list.second-column>li {
      padding-right: 10px;
    }
  }

  .score.no-background {
    background-color: transparent;
    &>.total-score {
      width: 216px;
      height: 110px;
      background-color: #D8FFAE;
      border-radius: 12px;
      margin-bottom: 20px;
      padding-top: 6px;
      &>p:first-child {
        font-size: 14px;
      }
      &>p:nth-child(2) {
        font-size: 28px;
      }
    }
  }
  
  @media screen and (max-width: 760px) {
    .score>.total-score {
      &>p:first-child {
        font-size: 16px;
        font-weight: 400;
      }
      &>p:nth-child(2) {
        font-size: 32px;
      }
    }
    .score-list>li {
      text-indent: 0;
      font-size: 12px;
    }
    .quality-report-a {
      .score-list>li {
        text-indent: 10px;
        font-size: 12px;
      }
    }
    .score-list>li>span {
      margin-right: 23px;
    }

    .quality-report-ab {
      & .total-score {
        width: 20%;
      }
      & .item-col {
        width: 40%;
      }
      & .score-list>li {
        white-space: nowrap;
      }
      & .score-list>li>span {
        margin-right: 23px;
        white-space: nowrap;
      }
    }

    .quality-report-a .score-rate {
      transform: scale(.6);
    }

    .quality-report-ab .score-rate {
      transform: scale(.6);
      width: 88px !important;
    }
  }

  @media screen and (max-width: 570px) {
    .score-list>li {
      font-size: 12px;
    }
     .quality-report-a .score-rate {
      transform: scale(.5);
    }
    .quality-report-ab .score-rate {
      transform: scale(.5);
      width: 70px !important;
    }
  }

  /*分数星级*/
  .score-rate {
    display: inline-block;
    text-indent: 0;
    width: 126px;
    float: right;
    margin-top: 8px;
  }
</style>
