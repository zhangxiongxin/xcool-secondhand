<template lang='pug'>
  div
    .total-score(v-if="!isAB")
      .total-name 总评分
      .total-num(style='font-size:36px;line-height:40px') {{Math.round(knowAnalyData.totalScore)}}分
    .top10
      .sub-item(v-if="knowAnalyData.worstTop10[0]") 正确率最高知识点TOP10
        .l-triangle
      knowledge-table.margin-top(:knowledges="knowAnalyData.bestTop10")
    .last10(v-if="knowAnalyData.worstTop10[0]")
      .sub-item 正确率最低知识点TOP10
        .l-triangle
      knowledge-table.margin-top(:knowledges="knowAnalyData.worstTop10")
    .knowAnaly-box
      .sub-item 智能知识分析
        .l-triangle
      analy-box.margin-top(:originData="knowAnalyData")
</template>
<script>
  // import store from '@/store'
  // import performService from '@/services/performance'

  import knowledgeTable from '@/views/report/knowledgeReport/knowledgeTable'
  import analyBox from '@/views/report/knowledgeReport/analyBox'
  export default {
    name: 'knowAnalyReport',
    props: ['isAB', 'knowAnalyData'],
    components: { knowledgeTable, analyBox },
    data() {
      return {
        // 不足20条时，不显示top10 worse10标志，数据全部放在top10中
        reportData: { worstTop10: [], totalScore: 0 }
      }
    },
    computed: {
      // studentInfo() {
      //   return store.state.comprehensive.studentInfo
      // },
      // knowAnalyData() {
      //   return store.state.comprehensive.knowAnalyData
      // }
    },
    created() {
      // let detailQuery = {
      //   studentId: this.studentInfo.studentId,
      //   // studentId: 'STU77298F4138A64929A5642AAD13DD82FF',
      //   examId: this.knowAnalyData.examId,
      //   lastExamId: this.knowAnalyData.lastExamId
      // }
      // performService.knowAnalyDetail(detailQuery).then(res => {
      //   this.reportData = res.data
      // })
    }
  }
</script>
<style scoped>
  .center {
    text-align: center;
  }
  
  .report-title {
    font-size: 18px;
  }
  
  .create-time {
    color: #999;
  }

  .report-time {
    font-size: 14px;
    color: #999999;
  }

  .total-score {
    margin-top: 34px;
    width: 216px;
    height: 110px;
    background: #D8FFAE;
    border-radius: 12px;
    text-align: center;
    padding-top: 20px;
    color: #53BA33;
  }
  
  .sub-item {
    height: 24px;
    line-height: 24px;
    color: #ffffff;
    padding-left: 10px;
    padding-right: 36px;
    background-color: #60BF68;
    position: relative;
    margin-top: 40px;
    display: inline-block;
  }
  
  .margin-top {
    margin-top: 22px;
  }

  .l-triangle {
    width: 0;
    height: 0;
    border-top: 12px solid transparent;
    border-right: 12px solid #ffffff;
    border-bottom: 12px solid transparent;
    position: absolute;
    top: 0px;
    right: 0px;
  }
  
  table {
    border-collapse: collapse;
    & th {
      background: #EEE1FF;
      color: #A779E8;
      font-weight: 400;
      border-right: solid 1px #ffffff;
      height: 40px;
      line-height: 19px;
      &:last-child {
        border-right: 1px solid #EEE1FF;
      }
    }
    & td {
      padding: 0 12px;
      color: #666;
      height: 40px;
      min-width: 100px;
      border: 1px solid #EEE1FF;
      text-align: center;
      Word-break: break-all;
    }
  }
  
  .point-name,
  .rate {
    display: inline-block;
    position: relative;
  }
  
  .new-learn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: -54px;
    font-size: 12px;
    color: #FFF;
    width: 44px;
    height: 16px;
    line-height: 16px;
    background: #FF5353;
    border-radius: 100px;
  }
  
  .compare {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: -60px;
    display: flex;
    align-items: center;
  }
  
  .flat {
    right: -26px;
  }
  
  .text-green {
    color: #90D236;
  }
  
  .text-red {
    color: #E53F3F;
  }
  
  .knowAnaly {
    background-size: 130px 24px;
  }
</style>
