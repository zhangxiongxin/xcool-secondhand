<template lang="pug">
  //- 查看综合能力报告
  .read-wrapper(v-loading="!comprehensiveData")
    .center-box(v-if="comprehensiveData")
      div.title
        p {{comprehensiveData.reportName}}
        //- p {{studentInfo.className}}
        p {{comprehensiveData.createTimeDate | timeFilter}}
      div.content
        //- 老师评语
        section.teacher-comments(v-if="comprehensiveData.comments || comprehensiveData.customComments")
          p 老师评语
          ul
            li(v-if="comprehensiveData.comments", v-for="item in comprehensiveData.comments") {{item}}
            br(v-if="comprehensiveData.comments && comprehensiveData.comments.length && comprehensiveData.customComments")
            li(v-if="comprehensiveData.customComments") {{comprehensiveData.customComments[0]}}
        //- 报告详情表格 
        section.detail-table
          //- 素质分析报告
          quality-analy-report(v-if="comprehensiveData.qualityDetail", :qualityAnalyData="comprehensiveData.qualityDetail", :knowAnalyData="comprehensiveData.knowledgeDetail", :comprehensiveData="comprehensiveData")
          //- 知识分析报告
          know-analy-report(v-if="comprehensiveData.knowledgeDetail", :knowAnalyData="comprehensiveData.knowledgeDetail", :isAB="comprehensiveData.qualityDetail && comprehensiveData.knowledgeDetail ? true : false")
          //- 考试报告
          exam-report(v-if="comprehensiveData.examDetail", :examData="comprehensiveData.examDetail")
</template>
<script>
  import reportService from '@/services/report'
  import dateFilter from '@/filters/date'

  import qualityAnalyReport from './singleReport/qualityAnalyReport'
  import knowAnalyReport from './singleReport/knowAnalyReport'
  import examReport from './singleReport/examReport'

  export default {
    name: 'read',
    components: { qualityAnalyReport, knowAnalyReport, examReport },
    data() {
      return {
        comprehensiveData: null,
        qualityAnalyData: null,
        knowAnalyData: null,
        examData: null
      }
    },
    methods: {},
    created() {
      // 请求综合报告详情
      reportService.comprehensiveDetail({ reportId: this.$route.params.reportId }, res => {
        this.comprehensiveData = res.data
      })
    },
    filters: {
      timeFilter(createTime) {
        return dateFilter(createTime)
      }
    }
  }
</script>
<style scoped>
  .read-wrapper {
    width: 100%;
    height: auto;
    min-height: 100%;
    overflow-y: visible;
  }

  .heard-btns {
    position: relative;
    display: flex;
    justify-content: flex-end;
    padding: 15px 30px;
    & .btn-img {
      position: relative;
      top: 4px;
      margin-right: 22px;
      width: 22px;
      height: 22px;
      cursor: pointer;
    }
    &>.send-btn {
      padding: 0;
      width: 106px;
      height: 30px;
    }
    &>.send-failed {
      position: absolute;
      top: 50px;
      right: 18px;
      color: #FF5353;
      z-index: 6;
    }
  }
  
  .center-box {
/*    height: calc(100% - 70px);
    overflow: visible;*/
    &>.title {
      margin-top: 10px;
      text-align: center;
      &>p:first-child {
        font-weight: 500;
        font-size: 18px;
        color: #333;
      }
      &>p:nth-last-child(-n+2) {
        font-size: 14px;
        color: #999;
      }
    }
    &>.content {
      padding: 34px 15px 10px;
    }
    /*老师评语*/
    & .teacher-comments {
      &>p {
        position: relative;
        width: 100px;
        height: 24px;
        line-height: 24px;
        background-color: #60BF68;
        font-size: 16px;
        color: #FFFFFF;
        text-indent: 10px;
        /*兼容safari横屏时字体变大*/
        -webkit-text-size-adjust: 100%;
      }
      &>p::after {
        position: absolute;
        top: 0;
        right: 0;
        content: '';
        display: block;
        border-style: solid;
        border-width: 12px;
        border-color: transparent #fff transparent transparent;
      }
      &>ul {
        margin: 20px 0;
        border: 1px solid #6FBE66;
        border-radius: 12px;
        padding: 20px;
      }
    }
  }
  
/*  @media screen and (max-width: 760px) {
    .teacher-comments li {
      font-size: 14px;
    }
  }*/
</style>
<style>
  ul {
    list-style: none !important;
  }
</style>
