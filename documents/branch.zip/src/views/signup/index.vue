<template lang="pug">
  router-view.body-container
</template>
<script>
  export default {
    name: 'signup'
  }
</script>
<style scoped>
.body-container{
  background: #fff;
}
</style>
