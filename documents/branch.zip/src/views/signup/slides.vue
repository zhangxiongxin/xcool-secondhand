<template lang="pug">
  div.slides
    .container
      .content(@touchstart='touchStart', @touchmove='touchMove', @touchend='touchEnd', draggable='false')
        .box(:style="{'margin-left': -1 * this.current * 100 + '%'}" @click='play')
          img(src='~assets/imgs/slides/pic1.png', draggable='false')
          img(src='~assets/imgs/slides/pic2.png', draggable='false')
          img(src='~assets/imgs/slides/pic3.png', draggable='false')
    .marks
      span(v-for='mark in marks', :class='{checked: mark.index===current}' @click='jumpTo(mark.index)')
</template>

<script>

  export default {
    name: 'slides',
    data() {
      return {
        marks: [],
        size: 3,
        current: 0
      }
    },
    components: {},
    mounted() {
      this.start()
      this.getMarks()
    },
    methods: {
      clear() {
        clearInterval(this.timer)
      },
      start() {
        this.clear()
        this.timer = setInterval(this.play, 3000)
      },
      jumpTo(i) {
        this.start()
        this.current = i
      },
      getMarks() {
        for (var i = 0; i < this.size; i++) {
          this.marks.push({index: i})
        }
      },
      play() {
        this.current = (this.current + 1) % 3
      },
      touchStart(evt) {
        var p = evt.touches[0]
        this.action = true
        this.startPosition = {x: p.pageX, y: p.pageY}
        this.clear()
      },
      touchMove(evt) {
        var p = evt.touches[0]
        this.action = true
        this.movePosition = {x: p.pageX, y: p.pageY}
      },
      touchEnd(evt) {
        if (this.movePosition.x - this.startPosition.x > 30) {
          this.current = Math.max(this.current - 1, 0)
        } else if (this.movePosition.x - this.startPosition.x < -30) {
          this.current = Math.min(this.current + 1, this.size - 1)
        }
        this.start()
      }
    }
  }
</script>

<style scoped>
.slides{
  position: relative;
  margin: 0 5px;
}
.marks{
  text-align: center;
  width: 100%;
  left: 0;
  position: absolute;
  bottom: 5px;
}
.marks > *{
  display: inline-block;
  width: 10px;
  height: 10px;
  background: #B2C9F5;
  border-radius: 10px;
  margin: 0 5px;
  border:1px solid #fff;
}
.marks .checked{
  background: #2FB3FC;
}
.slides .container{
  padding-top: 88.4%;
  position: relative;
}
.content{
  height: 100%;
  position: absolute;
  /*background-color: #2FB3FC;*/
  top:0;
  left:0;
  bottom:0;
  right:0;
  drag: false;
  overflow: hidden;
}
.content img{
  height: 100%;
  width: 100%;
}
.box{
  white-space: nowrap;
  height: 100%;
  width: 100%;
  margin-left:-33.33333%;
  transition: margin .5s;
}
.box > * {
  display: inline-block;
  width: 100%;
}
</style>
