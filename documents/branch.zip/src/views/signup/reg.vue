<template lang="pug">
  div.reg
    .center-container
      h2.title 豆豆数学
      p.intro 专注作业诊断、错题自动整理的人工智能作业机器人。拍照1秒上传，约10分钟查看诊断结果，准确率高达99.5%。
      slides
      x-button.singup(text="开启提分之旅" type="primary" @click.native="toSubmit")
      p.intro
        span 已有
        span(style='color:#F67359') {{usedCount}}
        span 人次使用豆豆数学，赶紧加入，获得价值30元的300学豆吧！
</template>

<script>
  import slides from './slides'
  import signupService from '@/services/signup'
  export default {
    name: 'reg',
    data() {
      return {
        cid: this.$route.query.c || '',
        usedCount: '',
        uid: this.$route.query.u || ''
      }
    },
    components: {slides},
    mounted() {
      this.refresh()
    },
    methods: {
      toSubmit() {
        if (this.uid) {
          this.$router.push(`/reg/submit?c=${this.cid}&u=${this.uid}`)
        } else {
          this.$router.push(`/reg/submit?c=${this.cid}`)
        }
      },
      refresh() {
        signupService.getUsedCount({}).then(resp => {
          this.usedCount = resp.data.useCount
        })
      }
    }
  }
</script>

<style scoped>
.title{
  font-size: 1.4em;
  text-align: center;
  font-weight: bold;
  color:#2DBAFD;
  padding-top:15px;
}
.singup{
  margin-top: 10px;
  background:#2FB3FC;
}
.reg {
  color:#6D6D6D;
  padding:0 20px;
  background: transparent;
  height:auto;
  margin: 0 auto;
}
.center-container{
  max-width: 640px;
  margin: 0 auto;
}
.intro{
  padding:10px 0;
  text-align: center;
  line-height: 1.4;
  font-size: 1.15em;
}
</style>
