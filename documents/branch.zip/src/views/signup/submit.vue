<template lang="pug">
  div.submit
    .center-container
      .logo(style='margin-top:10px')
        img(src='~assets/imgs/doudou.png')
      .title 欢迎加入豆豆大家庭！
      .line(:class="hasError('phone')")
        x-input.input(placeholder="请输入你的手机号码"  v-model="phone" @on-change="status = 0")
      .line(:class="hasError('msgcode')")
        .msgcode
          x-input.input(placeholder="请输入验证码" v-model="msgcode" @on-change="status = 0")
        x-button.msgbtn(:text="time+'秒'" type="primary" v-if='time > 0' )
        x-button.msgbtn(text="重新获取验证码" type="primary" v-if='time == -1' @click.native="getMsgcode")
        x-button.msgbtn(text="获取验证码" type="primary" v-if='time == 0' @click.native="getMsgcode")
      .line(:class="hasError('password')")
        x-input.input(type="password" placeholder=" 设置你的密码（6-16位数字、字母组合）" v-model="password" @on-change="status = 0" v-if='passowrdType=="password"' :show-clear='false')
        x-input.input(type="text" placeholder=" 设置你的密码（6-16位数字、字母组合）" v-model="password" @on-change="status = 0" v-if='passowrdType=="text"' :show-clear='false')
        span.eye(:class="{open:passowrdType=='text'}" @click='togglePasswordType')
          icon.icon(name='eye', :height='30', :width='30')
      .line.error-info(v-if='hasError()')
        div(v-for="item in checked")
          div(v-for="error in item") {{error}}.
      .line(style='margin-top:20px')
        x-button.singup(text="完成注册" type="primary" @click.native="signup")
      .toast(v-if='msg' @click='clearMsg')
        .content 
          .header {{msgHeader}}
          p {{msg}}


</template>

<script>
  import md5 from 'md5'
  import validate from 'validate.js'
  import signupSource from '@/services/signup'

  const LIMIT_TIME = 300000

  const msgcodeConstraints = {
    phone: {
      format: {
        pattern: '[0-9]{11}',
        flags: 'i',
        message: '^手机号码有误'
      }
    }
  }
  const singupConstraints = {
    phone: {
      format: {
        pattern: '[0-9]{11}',
        flags: 'i',
        message: '^手机号码有误'
      }
    },
    msgcode: {
      presence: {message: '^验证码不能为空', allowEmpty: false}
    },
    password: {
      length: {
        minimum: 6,
        maximum: 16,
        tooLong: '^密码不能大于16个字符',
        tooShort: '^密码不能小于6个字符'
      },
      presence: {message: '^密码不能为空', allowEmpty: false}
    }
  }
  import icon from '@/components/icon'
  export default {
    name: 'submit',
    data() {
      return {
        passowrdType: 'password',
        cid: this.$route.query.c,
        uid: this.$route.query.u,
        time: 0,
        phone: '',
        password: '',
        msgHeader: '',
        checked: {},
        msg: '',
        msgcode: ''
      }
    },
    components: {icon},
    destroyed() {
      clearInterval(this.timer)
    },
    methods: {
      togglePasswordType() {
        this.passowrdType = this.passowrdType === 'password' ? 'text' : 'password'
      },
      startTimer() {
        var that = this
        that.startTime = new Date().getTime()
        that.timer = setInterval(() => {
          // 剩余时间，精确到毫秒
          var spend = new Date().getTime() - that.startTime
          that.time = Math.floor(Math.max(LIMIT_TIME - spend, 0) / 1000)
          if (that.time === 0) {
            that.time = -1
            clearInterval(that.timer)
          }
        }, 100)
      },
      getMsgcode() {
        this.clearMsg()
        var p = {phone: this.phone, type: 'register'}
        // api
        this.checked = validate(p, msgcodeConstraints) || {}
        if (this.hasError()) return
        signupSource.getMsgcode(p).then(resp => {
          if (resp.code === 10000) {
            // this.msgcode = resp.data.verificationcode
            this.startTimer()
          }
        }).catch(resp => {
          if (resp.code === 21110) {
            if (resp.inform === 'the phone exist') {
              this.setExistMsg()
              this.jumpToDownlod()
            } else {
              this.showMsg('验证码已发送，请不要重复发送！')
            }
          }
        })
      },
      clearMsg() {
        this.checked = {}
        this.msg = ''
        this.msgHeader = ''
      },
      setFinishMsg() {
        this.msg = '你已经获得价值30元的300学豆哦！立即下载豆豆数学进行诊断吧！'
        this.msgHeader = '注册成功'
      },
      setExistMsg() {
        this.msg = '该手机号已注册过了，请下载豆豆数学开始使用吧！'
        this.msgHeader = ''
      },
      showMsg(msg) {
        this.msg = msg
        setTimeout(() => {
          this.msg = ''
          this.msgHeader = ''
        }, 3000)
      },
      jumpToDownlod() {
        setTimeout(() => {
          window.location.href = 'http://www.doudoushuxue.com/download.html'
        }, 3000)
      },
      hasError(key) {
        if (key && this.checked[key]) return 'error'
        else return Object.keys(this.checked).length > 0
      },
      signup() {
        this.clearMsg()
        var p = {
          phone: this.phone,
          password: this.password,
          msgcode: this.msgcode
        }
        this.checked = validate(p, singupConstraints) || {}
        if (this.hasError()) return
        p = {
          nickName: this.phone,
          cellPhoneNumber: this.phone,
          sex: 'male',
          password: this.password ? md5(this.password) : '',
          verifyCode: this.msgcode,
          recAccountId: this.uid,
          channelId: this.cid,
          source: 5
        }
        signupSource.signup(p).then(resp => {
          if (resp.code === 10000) {
            this.setFinishMsg()
            this.jumpToDownlod()
          }
        }).catch(resp => {
          if (resp.code === 21111) {
            this.showMsg('验证码错误，请重新填写')
          } else if (resp.code === 21110) {
            this.setExistMsg()
            this.jumpToDownlod()
          } else {
            this.showMsg('注册失败，请重试')
          }
        })
      }
    }
  }
</script>

<style scoped>
.eye{
  position: absolute;
  right:10px;
  top:50%;
  width: auto !important;
  transform: translateY(-50%);
}
.eye .icon{
  fill: #aaa;
}
.eye.open .icon{
  fill: #00994D;
}
.toast {
  position: fixed;
  left:0;
  top:0;
  right:0;
  bottom:0;
}
.toast .header {
  font-size: 1.4em;
  margin-bottom: 10px;
}
.toast .content{
  text-align: center;
  line-height: 1.5;
  position: absolute;
  background: rgba(0,0,0,0.9);
  padding: 30px 30px;
  width: 80%;
  color:#fff;
  border-radius: 8px;
  font-size: 1.2em;
  left:50%;
  top:40%;
  transform: translateX(-50%) translateY(-50%);
}
.error-info {
  color:#FA4F4E;
  line-height: 1.2; 
  background: rgba(255,255,255, 0.6);
  border-radius: 5px;
  padding: 10px;
}

.submit {
  padding:20px;
  background: transparent;
  height:auto;
}
.center-container{
  max-width: 640px;
  margin: 0 auto;
}
.logo{
  text-align: center;
}
.input{
  background: #fff;
}
.line{
  margin-top: 10px;
  position: relative;
  font-size: 1.1em;
}
.line>* {
  vertical-align: middle;
  width: 100%;
}
.line.error .input{
  color:#FA4F4E;
}
.title{
  font-size: 1.4em;
  text-align: center;
  margin: 30px 0;
  color:#fff;
}
.singup {
  background: #1A87FB;
}
.msgcode{
  width: calc(100% - 170px);
  display: inline-block;
}
.msgbtn{
  margin-left: 10px;
  background: #fff;
  color:#666;
  font-size: 1em;
  line-height:40px;
  width: 160px;
  display: inline-block;
}
</style>
