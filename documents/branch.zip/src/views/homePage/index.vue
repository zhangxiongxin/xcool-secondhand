<template lang="pug">
  div.body-container.homepage
    div.btn.arrangement(@click="to('./homework/arrangement')", flex="main:center")
      div.inside-container(flex="cross:center")
        img.homework(src='~assets/imgs/homepage/stack@2x.png')
        span.homework_word 布置作业／考试
    div.btn.assignment(@click="to('./homework/assignment')", flex="main:center cross:center")
      div.inside-container(flex="cross:center")
        img.list(src='~assets/imgs/homepage/Shape@2x.png')
        span.homework_word 作业／考试列表
    button.logout(@click="logout") 退出登录
</template>
<script>
import userService from '@/services/user'
export default {
  name: 'user',
  data() {
    return {
    }
  },
  methods: {
    to(url) {
      this.$router.push(url)
    },
    logout() {
      let that = this
      this.$vux.confirm.show({
        title: '确定要退出吗？',
        onCancel () {
        },
        onConfirm() {
          userService
            .logout()
            .then(res => {
              localStorage.removeItem('name')
              localStorage.removeItem('password')
              that.$router.push('./login')
            })
            .catch(res => {
              that.$router.push('./login')
            })
        }
      })
      // userService
      //   .logout()
      //   .then(res => {
      //     localStorage.removeItem('name')
      //     localStorage.removeItem('password')
      //     this.$router.push('./login')
      //   })
      //   .catch(res => {
      //     this.$router.push('./login')
      //   })
    }
  }
}
</script>
<style scoped>
  .homepage {
    overflow: hidden;
  }
  .body-container {
    background: #E8F3FF;
  }
  .btn {
    background: #39F;
    width: 84%;
    height: 100px;
    margin: 0 auto;
    border: 2px solid #FFFFFF;
    box-shadow: 0 4px 10px 0 rgba(23,77,132,0.50);
    border-radius: 15px;
    font-size: 32px;
    line-height: 45px;
    font-weight: 600;
    color:#fff;
  }
  .inside-container {

  }
  .arrangement {
    text-shadow: 0 2px 6px #1C6BB9;
    margin-top: 80px;
    margin-bottom: 24px;
    text-align: left;
    padding: 0;
  }
  .homework {
    width: 48px;
    height: 51px;
    margin-right: 5%;
  }
  .homework_word {
    width: 195px;
    font-size: 26px;
  }
  .assignment {
    text-shadow: 0 2px 6px rgba(16,58,100,0.50);
    margin-bottom: 50px;
    text-align: left;
    padding: 0;
  }
  .list {
    width: 42px;
    height: 50px;
    margin-right: 5%;
  }
  .logout {
    width: 126px;
    color: #39F;
    font-size: 24px;
    line-height: 33px;
    background-color: inherit;
    border: none;
    margin-left: calc(50% - 63px);
    background-image: url('~assets/imgs/homepage/logout@2x.png');
    background-repeat: no-repeat;
    background-size: 23px 26px;
    background-position: left center;
    text-align: left;
    text-indent: 23%;
    padding: 0;
  }
</style>
