<template lang='pug'>
  div.container(v-loading="loading")
    div.head
      p.title {{ endTime }} 错题本 
      .sub_title ( {{ beginTime }} - {{ endTime }} {{wrongQuestionTypeShow}}错题 )
        button.print(@click='print') 打印
    div.all_error
      div.single_error(v-for='(item,index) in allData.items', :key='index', :class="{one_col: item.questionType === 'choice'||'fill_in', more_col: item.questionType === 'solution'}")
        .qs-stem
          latex(:text='item.stemg', :latexImgs='item.stemLatexGraph', :imgs='item.stemGraph', :index="indexStr(index)")
        .qs-sub-stem
          latex(:text='item.subStemg', :latexImgs='item.subStemLatexGraph', :imgs='item.subStemGraph')
</template>
<script>
  import EmbeddedPageService from '@/services/embeddedPage'
  import latex from './latex'
  import date from '@/filters/date'

  export default {
    name: 'errorquestion',
    components: { latex },
    data() {
      return {
        loading: true,
        queryParams: {
          wrongQuestionClasstype: this.$route.query.wrongQuestionClasstype,
          studentId: this.$route.query.studentId,
          isShowCorrect: this.$route.query.isShowCorrect,
          key: this.$route.query.key,
          pageSize: this.$route.query.pageSize,
          pageNum: this.$route.query.pageNum,
          startDate: parseInt(this.$route.query.startDate),
          endDate: parseInt(this.$route.query.endDate),
          sort: this.$route.query.sort
        },
        allData: {}
      }
    },
    computed: {
      beginTime() {
        if (this.queryParams.startDate === 0) {
          return '2017.01.01'
        } else {
          let startDate = date(this.queryParams.startDate, 'yyyy-MM-dd')
          return startDate.split('-').join('.')
        }
      },
      endTime() {
        let endDate = date(this.queryParams.endDate, 'yyyy-MM-dd')
        return endDate.split('-').join('.')
      },
      wrongQuestionTypeShow() {
        if (this.queryParams.wrongQuestionClasstype === 'ddExerhome') {
          return '作业'
        } else if (this.queryParams.wrongQuestionClasstype === 'ddExam') {
          return '考试'
        } else if (this.queryParams.wrongQuestionClasstype === 'ddWeekExam') {
          return '考试'
        } else {
          return '全部'
        }
      }
    },
    created() {
      this.request()
    },
    methods: {
      request() {
        EmbeddedPageService
          .errorQuestion(this.queryParams, res => {
            this.loading = false
            this.allData = res.data
          }, res => {})
      },
      indexStr(index) {
        let num = index + 1
        return num + '.'
      },
      print() {
        if (this.IsPC() === true) {
          window.print()
        } else {
          alert('对不起，只能在PC端打印哟')
        }
      },
      IsPC() {
        let userAgentInfo = navigator.userAgent
        let Agents = ['Android', 'iPhone',
          'SymbianOS', 'Windows Phone',
          'iPad', 'iPod'
        ]
        let flag = true
        for (let v = 0; v < Agents.length; v++) {
          if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false
            break
          }
        }
        return flag
      }
    }
  }
</script>
<style scoped>
  .head {
    width: 96%;
    margin-left: 2%;
    border-bottom: 1px dashed black;
    padding-top: 20px;
    padding-bottom: 12px;
    margin-bottom: 28px;
  }
  
  .title {
    font-size: 24px;
    color: #333333;
    letter-spacing: 0;
    text-align: center;
  }
  
  .sub_title {
    height:auto;
    position: relative;
    line-height: 48px;
    font-size: 24px;
    color: #333333;
    letter-spacing: 0;
    text-align: center;
  }
  
  .print {
    font-size: 20px;
    color: #FFFFFF;
    letter-spacing: 0;
    background: #48B8FF;
    border-radius: 24px;
    width: 108px;
    height: 48px;
    position: absolute;
    right: 2%;
    border: 0px;
  }
  
  .single_error {
    font-size: 14px;
    color: #333333;
    letter-spacing: 0;
    width: 96%;
    margin-left: 4%;
  }
  
  .one_col {
    padding-bottom: 22px;
  }
  
  .more_col {
    padding-bottom: 162px;
  }
</style>
<style type="text/css">
  @media print {
    .print {
      display: none !important;
    }
    .latex-warp {
      display: inline !important;
    }
  }
</style>
