<template lang="pug">
  //- 首页
  .container(v-show='showLogin')
    img.logo(src="~assets/imgs/homepage/pi_login_doudou@3x.png")
    div
      x-input.input-text(placeholder="请输入账号" v-model="userName" @on-change="status = 0")
        img(slot="label" style="display:block;padding-right:11px" src="~assets/imgs/homepage/icon_user@3x.png" width="31" height="20")
      x-input.input-text(placeholder="请输入密码" type="password" v-model="password" @on-change="status = 0" @keyup.13.native="doLogin")
        img(slot="label" style="display:block;padding-right:11px" src="~assets/imgs/homepage/icon_pwd@3x.png" width="31" height="20")
      x-button.login_btn(text="登录" type="primary" @click.native="doLogin")
    span#login_alert(v-if="status > 0") {{ words }}
</template>
<script>
import userService from '@/services/user'
import md5 from 'md5'
const alertMessage = ['', '账号或密码必须填写', '账号或密码错误', '未知错误']

export default {
  name: 'homepage',
  data() {
    return {
        // 用户名
      userName: '',
      password: '',
      showLogin: false,
      status: 0
    }
  },
  computed: {
    words() {
      return alertMessage[this.status || 0]
    }
  },
  methods: {
    doLogin() {
      var loginName = this.userName
      var loginPwd = md5(this.password)
      this.login(loginName, loginPwd)
    },
    login(loginName, loginPwd) {
      userService
        .login({ loginName: loginName, password: loginPwd })
        .then(res => {
          localStorage.setItem('name', loginName)
          localStorage.setItem('password', loginPwd)
          userService.setUserData(res.data)
          this.$router.push('/homepage')
        })
        .catch(err => {
          if (err.code === 10120) {
            this.status = 0
            return
          }
          this.status = 0
          this.showLogin = true
          if (!err || !err.message) return (this.status = 3)
          if (this.userName === '' || this.password === '') {
            this.status = 1
          } else if (err.message.indexOf('LoginName or Password is wrong') >= 0 || err.message.indexOf('Data is error') >= 0) {
            this.status = 2
          } else this.status = 3
        })
    }
  },
  created() {
    userService.setUserData(null)
    if (localStorage.getItem('name')) {
      var userName = localStorage.getItem('name')
      var password = localStorage.getItem('password')
      this.login(userName, password)
    } else {
      this.showLogin = true
    }
  }
}
</script>
<style scoped>
  .container {
    width: 100%;
    margin: 0 auto;
    overflow: auto;
    background: #FFFEF9;
  }
  .container .logo {
    display: block;
    margin: 0 auto;
    width: 113px;
    height: 113px;
    margin-top: 40.2px;
    margin-bottom: 22.5px;
  }
  .input-text {
    width: 80%;
    margin: 0 auto;
    margin-bottom: 10px;
    font-size: 18px;
    height: 42px;
    line-height: 42px;
    border: none;
    background: #E9F2FF;
    color: #000;
    border-radius: 4px;
    box-sizing: border-box;
    border: 1px #fff solid;
  }
  .input-text.weui-cell {
    padding-left: 11px;
  }
  .input-text:hover {
    background: #fff;
    border: 1px #4F9AFB solid;
  }
  .weui-cell:before {
    border: none;
  }
  
  .login_btn {
    width: 80%;
    margin: 0 auto;
    background: #39F;
    margin-top: 10px;
    height: 48px;
  }
  @keyframes fade {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  #login_alert {
    /* opacity:0; */
    margin: 0 auto;
    display: inline-block;
    height: 49px;
    margin-top: 52px;
    line-height: 49px;
    color: #fff;
    background: #666563;
    font-size: 20px;
    text-align: center;
    position: relative;
    padding: 0 10%;
    left: 50%;
    transform: translate(-50%);
    width: 80%;
    animation: fade 2s;
  }
</style>
