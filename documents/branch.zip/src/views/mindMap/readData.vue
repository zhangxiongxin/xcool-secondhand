<template lang='pug'>
  div(ref='text') {{showContent}}
</template>
<script>
export default {
  name: 'readData',
  data() {
    return {
      showContent: '',
      replaceTxt: '',
      readDatas: {
        question: {
          questionId: '0CFBD02B70284A178C226F47051D964F',
          conditions: [{
            dom: '0#0',
            condition: 'AB=AC=AD',
            reason: ''
          }, {
            dom: '0#22',
            condition: 'AD∥BC',
            reason: '平行线的定义#平行线公理#平行线的性质#平行线的判定'
          }, {
            dom: '30#40',
            condition: '',
            reason: '等量代换#解方程'
          }],
          content: '(2015•宿迁)如图,已知AB=AC=AD,且AD∥BC,求证:∠C=2∠D.'
        }
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      let replaceTxt = this.setTooltipColor(this.readDatas.question.content, this.readDatas.question.conditions, this.readDatas.question.conditions.length)
      // replaceTxt.repalce(/#%#/g, '<br>')
      console.log(replaceTxt)
      this.$refs.text.innerHTML = replaceTxt
    },
    setTooltipColor(str, arr, len) {
      var str1 = str
      for (var i = len - 1; i >= 0; i--) {
        arr[i].start = arr[i].dom.split('#')[0]
        arr[i].stop = arr[i].dom.split('#')[1]
        var newaceEle = str.substring(arr[i].start, arr[i].stop)
        arr[i].reasons = arr[i].reason.replace(/#/g, '、')
        if (newaceEle) {
          // str1 = str1.substring(0, arr[i].start) + '<span class='toolTip' style='color:#0bbd0b' content='' + arr[i].reason + ''>' + newaceEle + '</span>' + str1.substring(arr[i].stop)
          str1 = str1.substring(0, arr[i].start) + `<span class='toolTip' style='color:#0bbd0b;position:relative' content='${arr[i].reasons}'>${newaceEle}'</span>'` + str1.substring(arr[i].stop)
        }
      }
      return str1
    }
  }
}
</script>
<style>
  .toolTip{
    font-weight: 700;
    &:hover {
      &::after {
        position: absolute;
        content: attr(content);
        border: 1px solid gray;
        top: 19px;
        padding: 5px;
        margin-left: -63px;
        z-index: 9999;
        min-width: 100px;
        line-height: 20px;
        background: #ffffff;
        border:solid 1px #89b189;
        cursor: pointer;
      }
    }
  }
</style>
<style scoped>
  *{
    cursor: pointer;
  }
  .homepage {
    overflow: hidden;
  }
  .body-container {
    background: #E8F3FF;
  }
  h1{
    height:60px;
    line-height:60px;
    color: red;
  }
</style>
