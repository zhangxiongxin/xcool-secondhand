<template lang='pug'>
  div
    div.total
      span(@click='init()', :class='{active: wholeGraph}') 整体展示
      span(@click='getSubWay', :class='{active: !wholeGraph}') 分步演示
    .echart
      section(ref='mychart')
</template>
<script>
import echarts from 'echarts'
import readData from './readData'
export default {
  name: 'mindMap',
  components: {readData},
  data() {
    return {
      showContent: '',
      replaceTxt: '',
      wholeGraph: true,
      subCount: 0,
      nodeTxt: '点击进行分步演示',
      // solveDatas: {
     // },
      solveDatas: {
        question: {
          questionId: '0CFBD02B70284A178C226F47051D964F',
          graphs: [{
            subId: 1,
            mindGraph: [
              [{
                start: '19#AD∥BC',
                end: '18#∠ADB=∠CBD',
                leval: '4'
              }, {
                start: '17#点B、C共线',
                end: '14#∠ABC',
                leval: '3'
              }, {
                start: '16#点B、A共线',
                end: '14#∠ABC',
                leval: '3'
              }, {
                start: '5#AB=AC',
                end: '7#AB=AD',
                leval: '5'
              }, {
                start: '13#AC=AD',
                end: '7#AB=AD',
                leval: '5'
              }, {
                start: '9#点A',
                end: '6#△ABD',
                leval: '5'
              }, {
                start: '10#点B',
                end: '6#△ABD',
                leval: '5'
              }, {
                start: '12#点D',
                end: '6#△ABD',
                leval: '5'
              }, {
                start: '9#点A',
                end: '4#△ABC',
                leval: '5'
              }, {
                start: '10#点B',
                end: '4#△ABC',
                leval: '5'
              }, {
                start: '11#点C',
                end: '4#△ABC',
                leval: '5'
              }, {
                start: '6#△ABD',
                end: '2#∠ADB=∠ABD',
                leval: '4'
              }, {
                start: '7#AB=AD',
                end: '2#∠ADB=∠ABD',
                leval: '4'
              }, {
                start: '4#△ABC',
                end: '1#∠ACB=∠ABC',
                leval: '4'
              }, {
                start: '5#AB=AC',
                end: '1#∠ACB=∠ABC',
                leval: '4'
              }, {
                start: '2#∠ADB=∠ABD',
                end: '15#∠ABD=∠CBD',
                leval: '3'
              }, {
                start: '18#∠ADB=∠CBD',
                end: '15#∠ABD=∠CBD',
                leval: '3'
              }, {
                start: '14#∠ABC',
                end: '8#BD为∠ABC的角平分线',
                leval: '2'
              }, {
                start: '15#∠ABD=∠CBD',
                end: '8#BD为∠ABC的角平分线',
                leval: '2'
              }, {
                start: '8#BD为∠ABC的角平分线',
                end: '3#∠ABD=(1/2)*(∠ABC)',
                leval: '1'
              }, {
                start: '1#∠ACB=∠ABC',
                end: '0#∠ACB=2*∠ADB',
                leval: '0'
              }, {
                start: '2#∠ADB=∠ABD',
                end: '0#∠ACB=2*∠ADB',
                leval: '0'
              }, {
                start: '3#∠ABD=(1/2)*(∠ABC)',
                end: '0#∠ACB=2*∠ADB',
                leval: '0'
              }]
            ]
          }]
        }
      },

      tempNodes: [],
      clientWidth: document.documentElement.clientWidth,
      option: {
        series: []
      },
      seriesData: {},
      seriesLinks: {}
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init(data) {
      this.setContainer()
      let totalNodes = this.buildData(this.solveDatas.question.graphs)
      this.wholeGraph = true
      this.buildWholeNodes(totalNodes)
      this.setEchart(totalNodes)
    },
    // 构造出全局关系图的节点数据列表
    buildWholeNodes(data) {
      data.forEach((item, index) => {
        item = this.setLevelRank(item)
        this.seriesLinks[item[0].questionId] = item
        this.seriesData[item[0].questionId] = item
        // item.forEach(subItem => {
        //   // console.log(subItem)
        // })
      })
      this.setSeries()
      this.setEchart(data)
    },
    // 构造出分步关系图的节点数据列表
    buildNodes(totalNodes, datas) {
      // 根节点
      if (!datas) {
        totalNodes.forEach((item, index) => {
          let questionId
          item = this.setLevelRank(item)
          item.forEach(subItem => {
            if (!questionId) questionId = subItem.questionId
            if (subItem.parentId === '-') subItem.active = true
            else subItem.active = false
          })
          this.seriesLinks[questionId] = item.filter((subItem) => {
            return subItem.parentId === '-'
          })
          this.seriesData[questionId] = [].concat(item)
        })
      } else {
        totalNodes.forEach((item) => {
          if (item[0].questionId === datas.questionId) {
            let result = item.filter((subItem) => {
              return subItem.level === datas.level - 1
            })
            let ids = Array.from(new Set(result.map((subItem) => {
              return subItem.id
            })))
            this.seriesLinks[datas.questionId] = this.seriesLinks[datas.questionId].concat(result)
            this.seriesData[datas.questionId].forEach((subItem) => {
              if (ids.indexOf(subItem.id) !== -1) subItem.active = true
            })
          }
        })
      }
      this.setSeries()
      this.setEchart(totalNodes)
    },
    // 设置series
    setSeries() {
      let resultData = []
      let index = 0
      for (let i in this.seriesData) {
        // 总的层数
        let totalLevel = this.seriesData[i].map((item) => item.level + 1).sort().pop()
        // 最大的rank数
        let maxRank = this.seriesData[i].map((item) => item.totalRank).sort().pop()
        this.seriesData[i].forEach((item, index) => {
          let xy = this.setXY(item, totalLevel)
          item.x = xy.x
          item.y = xy.y
          item.symbolSize = (item.active || this.wholeGraph) ? 50 : 0
          item.label = {
            normal: {
              textBorderColor: '#ffffff',
              textBorderWidth: 0,
              fontSize: 15,
              color: '#434343'
            }
          }
          // item.name = '点击进行分步演示' + totalLevel
        })
        let wholeGraph = this.wholeGraph
        let seriesData = this.setAttribute(index, totalLevel, maxRank, wholeGraph)
        // id 去重 赋值给series.data
        let first = []
        this.seriesData[i].forEach(item => {
          let state = true
          first.forEach(subItem => {
            if (item.id === subItem.id) {
              state = false
            }
          })
          if (state) first.push(item)
        })
        let levelSets = []
        // 一个leval设置一种颜色
        first.forEach((item) => {
          let curIndex = levelSets.findIndex(v => { return item.level === v.level })
          if (curIndex < 0) {
            item.itemStyle = {
              normal: {
                color: this.setColor()
              }
            }
            levelSets.push({color: item.itemStyle.normal.color, level: item.level, maxLevel: 1})
          } else {
            item.itemStyle = {
              normal: {
                color: levelSets[curIndex].color
              }
            }
            levelSets[curIndex].maxLevel++
          }
        })
        seriesData.data = first
        seriesData.links = this.seriesLinks[i].map((item) => {
          return {
            source: item.parentId,
            target: item.id
          }
        })
        seriesData.title = '点击进行分步演示' + index
        resultData[index] = seriesData
        index++
      }
      this.option.series = resultData
    },
    // 设置series属性
    setAttribute(index, totalLevel, maxRank, wholeGraph) {
      return {
        type: 'graph',
        layout: 'none',
        // roam: true,
        width: maxRank * 100,
        height: totalLevel * 100,
        left: (index * 350) + 125,
        top: 50,
        bottom: 50,
        label: {
          normal: {
            show: true
          }
        },
        edgeSymbol: ['cricle', 'arrow'],
        edgeSymbolSize: [4, 10],
        edgeLabel: {
          normal: {
            textStyle: {
              fontSize: 10
            }
          }
        },
        animationDuration: function (idx) {
          return idx * 0
        },
        lineStyle: {
          normal: {
            color: 'source',
            width: 0.5,
            opacity: 0.7
          }
        }
      }
    },
    // 设置坐标XY  x = baseX / item.totalRank * (item.rank - 0.5)
    // y = baseY / totalLevel * (totalLevel - item.level - 0.5)
    setXY(item, totalLevel) {
      let baseX = 300
      let baseY = 600
      return {
        x: baseX / item.totalRank * (item.rank - 0.5),
        y: baseY / totalLevel * (totalLevel - item.level - 0.5)
      }
    },
    setColor() {
      var str = Math.ceil(Math.random() * 16777215).toString(16)
      if (str.length < 6) {
        str = '0' + str
      }
      return '#' + str
    },
    getNodes(totalNodes, subCount, wholeGraph) {
      if (this.wholeGraph) {
        this.buildWholeNodes(totalNodes)
      } else {
        this.buildNodes(totalNodes, subCount)
      }
      if (this.myChart) {
        this.myChart.clear()
        this.myChart.setOption(this.option)
      }
    },
    buildData(data) {
      let subnodesArr = []
      let subArr = []
      data.map((v, index) => {
        v.mindGraph.map((vs, subIndex) => {
          let endNode = vs.map(item => {
            // 获取end节点
            let start = item.start.split('#')
            let end = item.end.split('#')
            return {
              id: end[0],
              parentId: start[0],
              parentName: start[1],
              name: end[1],
              level: Number(item.leval),
              questionId: `${v.subId}_${subIndex}`
            }
          })
          // 获取endNode中的Id
          let endNodeId = Array.from(new Set(endNode.map((item) => {
            return item.id
          })))
          // 获取start节点 id不能在endNodeId中
          let startNode = vs.map((item) => {
            let start = item.start.split('#')
            if (endNodeId.indexOf(start[0]) === -1) {
              return {
                id: start[0],
                parentId: '-',
                parentName: '-',
                name: start[1],
                level: item.leval,
                questionId: `${v.subId}_${subIndex}`
              }
            }
          }).filter((item) => item)
          let startNodeCopy = Array.concat(startNode)
          // 设置startNode中的level，按高的+1
          startNodeCopy.forEach((item) => {
            startNode.forEach((subItem) => {
              if (item.id === subItem.id) {
                item.level = (item.level > subItem.level ? item.level : subItem.level)
              }
            })
          })
          let result = []
          startNodeCopy.forEach((item) => {
            result.push(JSON.stringify(item))
          })
          let resultJSON = []
          Array.from(new Set(result)).forEach((item) => {
            let data = JSON.parse(item)
            data.level = Number(data.level) + 1
            resultJSON.push(data)
          })
          subArr = [].concat(endNode, resultJSON)
          subnodesArr.push(subArr)
        })
      })
      return subnodesArr
    },
    // 设置每层知识点的顺序
    setLevelRank(tempData) {
      let arr = []
      let level = Array.from(new Set(tempData.map((item) => {
        return item.level
      })))
      level.forEach((item) => {
        let arr1 = []
        tempData.forEach((subItem) => {
          if (item === subItem.level) arr1.push(subItem)
        })
        arr.push(arr1)
      })
      arr.forEach((item) => {
        // 总的次数
        let totalRank = Array.from(new Set(item.map((subItem) => subItem.id)))
        let obj = {}
        totalRank.forEach((item, index) => {
          obj[item] = index + 1
        })
        item.forEach((subItem) => {
          subItem.rank = obj[subItem.id]
          subItem.totalRank = totalRank.length
        })
      })
      let result = []
      arr.forEach((item) => {
        item.forEach((subItem) => {
          result.push(subItem)
        })
      })
      return result
    },
    setContainer() {
      this.$refs.mychart.style.height = '1080px'
      this.$refs.mychart.style.width = '100%'
    },
    // 分布演示解题步骤
    getSubWay() {
      this.wholeGraph = false
      let totalNodes = this.buildData(this.solveDatas.question.graphs)
      this.getNodes(totalNodes, this.subCount)
    },
    // 生成思维导图
    setEchart(totalNodes) {
      let dom = this.$refs.mychart
      let chartInstance = echarts.getInstanceByDom(dom)

      // 判断是否存在实例，防止多次实例化
      if (!chartInstance) {
        this.myChart = echarts.init(dom)
        // 显示详情
        this.myChart.on('click', (data) => {
          if (data.dataType === 'node') {
            this.getNodes(totalNodes, data.data)
          }
        })
      }
      this.myChart.setOption(this.option)
      this.myChart.showLoading()
      this.myChart.hideLoading()
    }

  }
}
</script>
<style>
  .toolTip{
    font-weight: 700;
    &:hover {
      &::after {
        position: absolute;
        content: attr(content);
        border: 1px solid gray;
        top: 19px;
        padding: 5px;
        margin-left: -63px;
        z-index: 9999;
        min-width: 100px;
        line-height: 20px;
        background: #ffffff;
        border:solid 1px #89b189;
      }
    }
  }
</style>
<style scoped>
  .total{
    width:200px;
    height:20px;
    line-height:20px;
    margin-left:50px;
    border-radius: 20px;
    background: #b1e4b0;
  }
  .active{
    background: #09bb07;
    border-radius: 20px;
  }
  span{
    display: inline-block;
    width:50%;
    height:20px;
    text-align: center;
  }
  .body-container {
    background: #E8F3FF;
  }
  h1{
    height:60px;
    line-height:60px;
    color: red;
  } 
</style>
