<template lang='pug'>
  div.body-container.homepage
    div(style='height:100px;width:100%')
      h1 思维导图
      read-data
    solve-data
</template>
<script>
import readData from './readData'
import solveData from './solveData'
export default {
  name: 'mindMap',
  components: {readData, solveData},
  data() {
    return {
    }
  },
  mounted() {
    // this.init()
  },
  methods: {

  }
}
</script>
<style scoped>
  .homepage {
    overflow: hidden;
  }
  .body-container {
    background: #E8F3FF;
  }
  h1{
    height:60px;
    line-height:60px;
    color: red;
  }
</style>
