<template lang="pug">
  router-view.body-container
</template>
<script>
  export default {
    name: 'survey'
  }
</script>
<style scoped>
</style>
