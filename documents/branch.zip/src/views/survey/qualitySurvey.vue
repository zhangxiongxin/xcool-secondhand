<template lang="pug">
  div.body-container
    .gradient
      .item(style="padding-top:1.25rem",v-for="item in dataStructure")
        .item-title {{item.itemTitle}}
          .blank
            img(src="~assets/imgs/hightlight_Line.png")
        ul(style="list-style:none",v-for="subItem in item.dataLabel")
          li(v-if="subItem.type === 'text'")
            p {{subItem.label}}
            p(:class="{'unchecked-border':subItem.name==='tel'&&telValidationState}")
              input.text(:name="subItem.name",:type="subItem.name==='tel'? 'tel':'text'",:maxlength="subItem.name==='tel'? '11':''",:placeholder="subItem.placeholder",:disabled="onlyRead",@blur="blurHandle($event,subItem.name)",@keyup="onlyNumber($event,subItem.number)",onpaste="return false")
          li(v-if="subItem.type === 'radio'")
            p {{subItem.label}}
            ul(:id="subItem.name")
              li.my-radio(@click="radioHandle",v-for="(option, index) in subItem.options")
                span.input
                p
                div(:data-noScore="subItem.noScore",:data-questionId="subItem.name",:data-score="index",:data-index="index") {{option}}
          li(v-if="subItem.type === 'checkbox'")
            p {{subItem.label}}
            ul(:id="subItem.name")
              li.my-radio(@click="checkboxHandle",v-for="(option, index) in subItem.options")
                span.checkboxInput
                p
                div(:data-questionId="subItem.name",:data-index="index") {{option}}
          li(v-if="subItem.type === 'rank'")
            p {{subItem.label}}
            div(style="height:50px;display:flex")
              input.text(:name="subItem.name[0]",type="text",style="width:calc((100% - 55px) / 2);",:placeholder="subItem.placeholder[0]",:disabled="onlyRead",@change="changeHandle($event,subItem.name[0])",@keyup="onlyNumber($event,subItem.number)",onpaste="return false")
              span.slash
                span
              input.text(v-if="subItem.name[1] !== 'totalScore'",:name="subItem.name[1]",type="text",style="width:calc((100% - 55px) / 2);",:placeholder="subItem.placeholder[1]",autocomplete="off",:disabled="onlyRead",@change="inputLimit($event,subItem.name[0])",@keyup="onlyNumber($event,subItem.number)",onpaste="return false")
              el-select(v-else,placeholder="总分",v-model="totalScore",name="totalScore",@change="selectHandle")
                el-option(value="100",label="100")
                el-option(value="120",label="120") 
                el-option(value="150",label="150") 
      div.btn(@click="submit",:class="{colorBtn: (saving || onlyRead) }") {{saving?btnText + '中':btnText}}
      footer

    
</template>
<script>
  import embeddedPageService from '@/services/embeddedPage'
  import { Message } from 'element-ui'
  require('@/libs/TGJSBridge/index.js')
  import store from '@/store'
  let initialData = ''
  let editData = ''
  window.hasUserEditData = function() {
    if (initialData === editData) return false
    else return true
  }
  export default {
    name: 'qualitySurvey',
    data() {
      return {
        btnText: '保存',
        scoreStatus: false,
        totalScore: '',
        datas: {},
        onlyRead: false,
        saving: false,
        telValidationState: false,
        telStyleState: false,
        inputType: ['name', 'school', 'gradeRank', 'gradeTotal', 'classRank', 'classTotal', 'testScore', 'totalScore', 'tel'],
        radioType: { sex: {questionId: 'sex', index: -2, answer: '', score: 0}, grade: {questionId: 'grade', index: -2, answer: '', score: 0}, A1: {}, A2: {}, A3: {}, A4: {}, A5: {}, A6: {}, A7: {}, A8: {}, A9: {}, A10: {}, A11: {}, A12: {}, B1: {}, B2: {}, B3: {}, C1: {}, C2: {}, C3: {}, C4: {}, C5: {}, C6: {}, C7: {}, C8: {}
        },
        uncheckedList: [],
        inputValue: {},
        qualities: [],
        dataStructure: [{
          itemTitle: '（一）基本信息',
          dataLabel: [{
            label: '1. 姓名',
            name: 'name',
            type: 'text',
            options: []
          }, {
            label: '2. 性别',
            name: 'sex',
            type: 'radio',
            options: ['男', '女'],
            noScore: true
          }, {
            label: '3. 学校',
            name: 'school',
            type: 'text',
            options: []
          }, {
            label: '4. 年级',
            name: 'grade',
            type: 'radio',
            options: ['七年级', '八年级', '九年级'],
            noScore: true
          }, {
            label: '5. 年级排名',
            name: ['gradeRank', 'gradeTotal'],
            type: 'rank',
            placeholder: ['我的排名', '年级总人数'],
            options: [],
            number: true
          }, {
            label: '6. 班级排名',
            name: ['classRank', 'classTotal'],
            type: 'rank',
            placeholder: ['我的排名', '班级总人数'],
            options: [],
            number: true
          }, {
            label: '7. 最近一次考试成绩',
            name: ['testScore', 'totalScore'],
            type: 'rank',
            placeholder: ['分数', '总分'],
            options: [],
            number: true
          }, {
            label: '8.  家长手机号码',
            name: 'tel',
            type: 'text',
            options: [],
            number: true
          }]
        }, {
          itemTitle: '（二）学生自我评价（必填）',
          dataLabel: [{
            label: 'A1. 对数学的兴趣',
            name: 'A1',
            type: 'radio',
            options: ['很不感兴趣', '不感兴趣', '一般', '比较感兴趣', '很感兴趣']
          }, {
            label: 'A2. 是否适应老师教学风格',
            name: 'A2',
            type: 'radio',
            options: ['很不适应', '不适应', '一般', '比较适应', '很适应']
          }, {
            label: 'A3. 课前预习的主动性',
            name: 'A3',
            type: 'radio',
            options: ['很不主动', '不主动', '一般', '比较主动', '很主动']
          }, {
            label: 'A4. 课堂笔记的主动性',
            name: 'A4',
            type: 'radio',
            options: ['很不主动', '不主动', '一般', '比较主动', '很主动']
          }, {
            label: 'A5. 课堂练习的自觉性',
            name: 'A5',
            type: 'radio',
            options: ['很不自觉', '不自觉', '一般', '比较自觉', '很自觉']
          }, {
            label: 'A6. 课堂回答问题的主动性',
            name: 'A6',
            type: 'radio',
            options: ['很不主动', '不主动', '一般', '比较主动', '很主动']
          }, {
            label: 'A7. 课堂听课习惯',
            name: 'A7',
            type: 'radio',
            options: ['很不好', '不好', '一般', '较好', '很好']
          }, {
            label: 'A8. 课后复习习惯',
            name: 'A8',
            type: 'radio',
            options: ['很不好', '不好', '一般', '较好', '很好']
          }, {
            label: 'A9. 每天家庭作业完成速度',
            name: 'A9',
            type: 'radio',
            options: ['很慢', '较慢', '一般', '较快', '很快']
          }, {
            label: 'A10. 家庭作业正确率',
            name: 'A10',
            type: 'radio',
            options: ['低于20%', '21%—40%', '41%—60%', '61%—80%', '81%—100%']
          }, {
            label: 'A11. 将错题收集到错题本的频率',
            name: 'A11',
            type: 'radio',
            options: ['基本不做', '约两周1次', '约每周1次', '每周多次', '每日都做']
          }, {
            label: 'A12. 大型考试（月考以上）发挥情况',
            name: 'A12',
            type: 'radio',
            options: ['很不好', '不好', '一般', '较好', '很好']
          }, {
            label: 'B1. 学习上遇到问题大部分时候如何应对',
            name: 'B1',
            type: 'radio',
            options: ['直接置之不理', '思考一会就不了了之', '直接求助学霸', '直接求助老师', '直接求助家长', '直接使用搜题软件', '思考后求助学霸', '思考后求助老师', '思考后求助家长', '思考后使用搜题软件', '独立思考,做不出来不罢休']
          }, {
            label: 'B2. 兴趣爱好（多选）',
            name: 'B2',
            type: 'checkbox',
            options: ['体育', '游戏', '看电视电影', '阅读', '棋类', '美术', '音乐', '舞蹈', '户外', '其他'],
            noScore: true
          }, {
            label: 'B3. 性格',
            name: 'B3',
            type: 'radio',
            options: ['开朗', '比较开朗', '比较内向', '内向'],
            noScore: true
          }]
        }, {
          itemTitle: '（三）家长评价（必填）',
          dataLabel: [{
            label: 'C1. 性格',
            name: 'C1',
            type: 'radio',
            options: ['开朗', '比较开朗', '比较内向', '内向'],
            noScore: true
          }, {
            label: 'C2. 孩子的兴趣爱好（多选）',
            name: 'C2',
            type: 'checkbox',
            options: ['体育', '游戏', '看电视电影', '阅读', '棋类', '美术', '音乐', '舞蹈', '户外', '其他'],
            noScore: true
          }, {
            label: 'C3. 学习主动性',
            name: 'C3',
            type: 'radio',
            options: ['很不主动', '不主动', '一般', '比较主动', '很主动']
          }, {
            label: 'C4. 在家里是否叛逆',
            name: 'C4',
            type: 'radio',
            options: ['叛逆', '比较叛逆', '比较容易沟通', '容易沟通'],
            noScore: true
          }, {
            label: 'C5. 家庭教育的观念',
            name: 'C5',
            type: 'radio',
            options: ['民主', '比较民主', '比较严格', '严格'],
            noScore: true
          }, {
            label: 'C6. 孩子有心事一般给谁讲',
            name: 'C6',
            type: 'radio',
            options: ['爸爸', '妈妈', '同学朋友', '其他亲人'],
            noScore: true
          }, {
            label: 'C7. 平时是否有时间管理孩子学习',
            name: 'C7',
            type: 'radio',
            options: ['基本有时间', '偶尔抽空', '完全没时间管'],
            noScore: true
          }, {
            label: 'C8. 家庭环境对孩子学习的影响',
            name: 'C8',
            type: 'radio',
            options: ['非常不利', '不利', '一般', '比较有利', '非常有利']
          }]
        }]
      }
    },
    methods: {
      // 只能输入数字限制
      onlyNumber(e, num) {
        this.qualities = []
        this.sortingData()
        if (!num) return
        let tar = e.target.value
        e.target.value = tar.replace(/\D/g, '')
      },
      submit() {
        if (this.onlyRead) return
        this.qualities = []
        this.getValueInInput()
        this.uncheckedList = []
        for (let i in this.radioType) {
          if (i !== 'sex' && i !== 'grade') {
            if (!this.radioType[i].choice) {
              this.uncheckedList.push(i)
            }
          }
        }
        this.scoreLimit()
        if (this.uncheckedList.length || this.scoreStatus || !this.telStyleState) {
          this.uncheckedStyle()
        } else {
          this.saving = true
          this.getData()
          this.datas.studentId = this.studentId
          this.datas.classId = this.classId
          this.datas.qualities = this.qualities
          embeddedPageService.saveQualitySurvey(this.datas).then(res => {
            if (res.code === 10000) {
              // 手机端回调函数
              this.saving = false
              Message({
                message: this.btnText + '成功',
                customClass: 'center-reminder',
                iconClass: 'no-icon',
                duration: 1500,
                onClose: () => {
                  this.phoneCallback({isUpdateSuccess: true, qualityModify: res.data.modify})
                  window.open('about:blank', '_self').close()
                }
              })
            } else {
              this.saving = false
              Message({
                message: this.btnText + '失败，请再试一次～',
                customClass: 'center-reminder',
                iconClass: 'no-icon',
                duration: 1500,
                onClose: () => {
                  this.phoneCallback({isUpdateSuccess: false, qualityModify: false})
                }
              })
            }
          })
        }
      },
      // 整合数据
      sortingData() {
        this.getValueInInput()
        this.getData()
        editData = JSON.stringify(this.qualities)
      },
      // 输入限制
      inputLimit(e, data) {
        let srcValue = e.target.value || 0
        let newValue = document.getElementsByName(data)[0].value || 0
        if (Number(srcValue) < Number(newValue)) {
          e.target.value = newValue
        }
        this.changeHandle()
      },
      // 点击保存后分数输入限制
      scoreLimit() {
        this.scoreStatus = false
        let score = document.getElementsByName('testScore')[0]
        let div = score.parentNode
        div.className = ''
        if (score.value === '') return
        if (score.value !== '' && this.totalScore !== '' && (Number(score.value) <= Number(this.totalScore))) return
        else {
          this.scoreStatus = true
          div.className = 'unchecked-border'
          let toTop = div.offsetTop
          document.body.scrollTop = toTop - 100
        }
      },
      selectHandle() {
        this.qualities = []
        this.sortingData()
        if (this.scoreStatus) {
          this.scoreLimit()
          return
        }
        document.getElementsByName('tel')[0].focus()
      },
      // 手机端回调函数
      phoneCallback(data) {
        if (window.androidSDK && window.androidSDK.getQualityAnalysisResult) {
          window.androidSDK.getQualityAnalysisResult(data.isUpdateSuccess, data.qualityModify)
        } else if (window.jsBridge) {
          window.jsBridge.postNotification('getQualityAnalysisResult', {
            data: data
          })
        }
      },
      // 数据处理
      getData() {
        for (let i in this.inputValue) {
          this.qualities.push(this.inputValue[i])
        }
        for (let i in this.radioType) {
          this.qualities.push(this.radioType[i])
        }
      },
      // 有些选项未选时，效果设置
      uncheckedStyle() {
        if (this.scoreStatus) return
        let toTop
        if (this.uncheckedList.length) {
          for (let i = 0; i < this.uncheckedList.length; i++) {
            let ulNode = document.querySelector('#' + this.uncheckedList[i])
            ulNode.className = 'unchecked-border'
            // 滚动条设置
            toTop = document.querySelector('#' + this.uncheckedList[0]).offsetTop
          }
        }
        let telNode = document.getElementsByName('tel')
        if (/^1[34578]\d{9}$/.test(telNode[0].value)) {
          this.telValidationState = false
          this.telStyleState = true
        } else {
          this.telValidationState = true
          this.telStyleState = false
        }
        if (this.telValidationState) {
          document.body.scrollTop = telNode[0].offsetTop - 100
        } else document.body.scrollTop = toTop - 100
      },
      // 获取文本输入框中的数据
      getValueInInput() {
        let self = this
        this.inputType.forEach(function(item) {
          let name = document.getElementsByName(item)
          let datas = {}
          datas.questionId = item
          datas.answer = item === 'totalScore' ? self.totalScore : name[0].value
          datas.score = 0
          datas.index = -1
          self.inputValue[item] = datas
        })
      },
      // 输入框的值是否有变化
      changeHandle(e, name) {
        if (!name) return
        this.qualities = []
        let value = Number(e.target.value)
        if (name === 'testScore') {
          if (value > 150) e.target.value = 150
          if (this.totalScore !== '') this.scoreLimit()
        }
        if (name === 'gradeRank') {
          let domValue = document.getElementsByName('gradeTotal')[0].value
          if (domValue !== '' && value > Number(domValue)) {
            e.target.value = domValue
          }
        }
        if (name === 'classRank') {
          let domValue = document.getElementsByName('classTotal')[0].value
          if (domValue !== '' && value > Number(domValue)) {
            e.target.value = domValue
          }
        }
        this.sortingData()
      },
      // 手机号验证
      blurHandle(e, name) {
        if (name !== 'tel') return
        if (/^1[34578]\d{9}$/.test(e.target.value)) {
          this.telValidationState = false
          this.telStyleState = true
        } else {
          this.telValidationState = true
          this.telStyleState = false
        }
      },
      // 多选控制
      checkboxHandle(e) {
        if (this.onlyRead) return
        this.qualities = []
        let div, p, ulNode
        if (e.target.className !== 'my-radio') {
          ulNode = e.target.parentNode.parentNode
          div = e.target.parentNode.querySelector('div')
          p = e.target.parentNode.querySelector('p')
        } else {
          ulNode = e.target.parentNode
          div = e.target.querySelector('div')
          p = e.target.querySelector('p')
        }
        if (p.className === 'checkbox') {
          p.className = ''
          div.className = ''
        } else {
          p.className = 'checkbox'
          div.className = 'textcolor'
        }
        ulNode.className = ''
        this.saveCheckboxData(ulNode, div)
        this.sortingData()
      },
      // 单选控制
      radioHandle(e) {
        if (this.onlyRead) return
        this.qualities = []
        let ulNode
        if (e.target.className !== 'my-radio') ulNode = e.target.parentNode.parentNode
        else ulNode = e.target.parentNode
        let checkNode = ulNode.querySelectorAll('p')
        let textNode = ulNode.querySelectorAll('div')
        for (let i = 0; i < checkNode.length; i++) {
          checkNode[i].className = ''
          textNode[i].className = ''
        }
        let div, p
        if (e.target.className !== 'my-radio') {
          div = e.target.parentNode.querySelector('div')
          p = e.target.parentNode.querySelector('p')
        } else {
          div = e.target.querySelector('div')
          p = e.target.querySelector('p')
        }
        ulNode.className = ''
        p.className = 'ischeck'
        div.className = 'textcolor'
        this.saveRadioData(div)
        this.sortingData()
      },
      // 单选数据缓存
      saveRadioData(div) {
        let questionid = div.dataset.questionid
        let score = Number(div.dataset.score)
        let index = Number(div.dataset.index)
        let answer = div.innerText
        let noScore = div.dataset.noscore
        // 没有分数的选项
        if (noScore) score = -1
        // 如果题目id是B1,做分数限制
        if (questionid === 'B1') {
          if (score > 1 && score < 6) {
            score = 2
          }
          if (score >= 6 && score < 10) {
            score = 3
          }
          if (score === 10) {
            score = 4
          }
        }
        // 获取输入的数据
        this.radioType[questionid].questionId = questionid
        this.radioType[questionid].answer = answer
        this.radioType[questionid].score = score + 1
        this.radioType[questionid].index = index
        this.radioType[questionid].choice = true
      },
      // 多选数据缓存
      saveCheckboxData(ulNode, div) {
        // 获取选中的数据
        let checkNode = ulNode.querySelectorAll('.textcolor')
        let questionid = div.dataset.questionid
        let score = 0
        let answer, choice, index
        if (checkNode.length) {
          answer = checkNode[0].innerText
          index = '-3' + checkNode[0].dataset.index
          for (let i = 1; i < checkNode.length; i++) {
            answer += ',' + checkNode[i].innerText
            index += ',' + checkNode[i].dataset.index
          }
          choice = true
        } else {
          answer = ''
          choice = false
        }
        this.radioType[questionid].questionId = questionid
        this.radioType[questionid].answer = answer
        this.radioType[questionid].score = score
        this.radioType[questionid].index = index
        // 是否选中
        this.radioType[questionid].choice = choice
      },
      // 素质分析查询
      queryQualityList(n) {
        let self = this
        embeddedPageService.queryQualitySurvey({studentId: this.studentId, n: n}, function(res) {
          res.data.forEach(item => {
            if (item.index !== -1) {
              if (String(item.index).indexOf('-3') === -1) {
                // 单选框
                self.showRadioValue(item)
              } else {
                // 多选框
                self.showCheckboxValue(item)
              }
            } else {
              // input框
              self.showInputValue(item)
            }
          })
          self.sortingData()
          initialData = JSON.stringify(self.qualities)
        })
      },
      // 回显input的内容
      showInputValue(item) {
        if (item.questionId === 'totalScore') {
          this.totalScore = item.answer
          return
        }
        document.getElementsByName(item.questionId)[0].value = item.answer
      },
      // 回显单选的内容
      showRadioValue(item) {
        if (item.index === -2) return
        let ul = document.querySelector('#' + item.questionId)
        let li = ul.querySelectorAll('li')[item.index]
        let div = li.querySelector('div')
        let p = li.querySelector('p')
        p.className = 'ischeck'
        div.className = 'textcolor'
        this.saveRadioData(div)
      },
      // 回显多选的内容 -3 表示是多选框
      showCheckboxValue(item) {
        let ul = document.querySelector('#' + item.questionId)
        let lis = ul.querySelectorAll('li')
        let div, p
        String(item.index).split('').splice(2).forEach(function(index) {
          div = lis[index].querySelector('div')
          p = lis[index].querySelector('p')
          if (p.className === 'checkbox') {
            p.className = ''
            div.className = ''
          } else {
            p.className = 'checkbox'
            div.className = 'textcolor'
          }
        })
        this.saveCheckboxData(ul, div)
      }
    },
    computed: {
      status() {
        return Number(this.$route.params.status)
      },
      reportData() {
        return store.state.report.reportData
      },
      classId() {
        return this.$route.params.classId
      },
      studentId() {
        return this.$route.params.studentId
      },
      source() {
        return Number(this.$route.query.source) || 0
      }
    },
    mounted() {
      // 0 新建，1查看并修改，2查看不能修改
      if (this.source === 1) this.btnText = '提交'
      if (this.source === 0) this.btnText = '保存'
      switch (this.status) {
        case 0:
          this.sortingData()
          initialData = JSON.stringify(this.qualities)
          break
        case 1:
          this.onlyRead = false
          if (this.source === 1) {
            this.queryQualityList(-1)
          } else {
            this.queryQualityList()
          }
          break
        case 2:
          this.onlyRead = true
          this.queryQualityList()
          break
      }
    }
  }
</script>
<style scoped>
  .unchecked-border {
    outline:solid 2px #FF3D2F;
  }
  .blank{
    position: absolute;
    top: 5px;
    left: 25px;
    height: 8px;
    line-height:0;
    & img{
      height: 8px;
    }
  }
  footer {
    width: 100%;
    height: 50px;
    background: url('~assets/imgs/image_hill.png') no-repeat;
    background-size: 100% 50px;
  }
 .btn {
  width: 12.5rem;
  height: 3.38rem;
  line-height: 3.38rem;
  background: #48B8FF;
  border-radius: 24px;
  font-size: 1.25rem;
  color: #FFFFFF;
  text-align: center;
  margin: 2.5rem auto 0rem;
 }
 .colorBtn {
  background: #D4EEFF;
  cursor: pointer;
 }
 .slash{
  display: inline-block;
  width: 55px;
  height: 50px;
  position: relative;
  & span {
    display: inline-block;
    height: 47px;
    border-left: solid 2px #DCCEE1;
    position: absolute;
    top:0px;
    left: 27px;
    transform: rotate(30deg);
  }
 }
  ul{
    list-style:none
  }
  .item-title{
    background: #DEC1E7;
    border-radius: 1.25rem;
    height: 2.5rem;
    text-align: center;
    line-height: 2.5rem;
    font-size: 1.25rem;
    color: #885F95;
    font-weight: bold;
    position: relative;
  }
  input.text{
    border: 2px solid #DCCEE1;
    border-radius: 5px;
    background: #FFFFFF;
    height: 50px;
    line-height: 50px;
    width: 100%;
    outline: none;
    font-size: 1.25rem;
    color: #977EA2;
    text-align: center;
  }
  p {
    display: block;
    color: #977EA2;
    font-size: 1.25rem;
    margin:1rem 0rem;
    font-weight: bold;
  }
  .gradient {
    opacity: 0.66;
    background-image: linear-gradient(-180deg, rgba(139,171,255,0.94) 0px, rgba(233,201,255,0.20) 66px, rgba(177,195,255,0.33) 140px, rgba(72,184,255,0.00) 220px);
    padding:1.25rem 5% 0rem;
  }
  .my-radio{
    height: 48px;
    width: 100%;
    background: #FDF8FF;
    margin-bottom: 2px;
    display: flex;
    align-items: center;
    position: relative;
  }
  span.input{
    width: 14px;
    height: 14px;
    border: 1px solid #48B8FF;
    border-radius: 100%;
    display: block;
    position: absolute;
    top: 17px;
    left: 10px;
  }
  span.checkboxInput{
    width: 14px;
    height: 14px;
    border: 1px solid #48B8FF;
    border-radius: 2px;
    display: block;
    position: absolute;
    top: 16px;
    left: 10px;
  }
  .my-radio div{
    font-size: 1.25rem;
    color: #666666;
    margin-left: 30px;
  }
  .textcolor{
    color: #48B8FF!important;
  }
  .ischeck{
      width: 10px;
      height: 10px;
      border-radius: 100%;
      background:#48B8FF;
      display: block;
      position:absolute;
      top: 19px;
      left: 12px;
      margin: 0;
    }
  .checkbox{
    width: 14px;
    height: 14px;
    background:#48B8FF url('~assets/imgs/ic_checker.svg') no-repeat 2px 3px;
    display: block;
    position:absolute;
    top: 16px;
    left: 10px;
    margin: 0;
  }
</style>
<style>
  .el-select-dropdown__item{
    text-align: center;
    color: #9372A0;
  }
  .el-select:hover .el-input__inner{
    border: 2px solid #DCCEE1;
  }
  .el-select{
    width: calc((100% - 55px)/2);
  }
  .el-input__inner{
    height: 50px;
    border: 2px solid #DCCEE1;
    outline: none;
    text-align: center;
    border-radius: 5px;
    color: #977EA2;
    font-size: 20px;
  }
  input.el-input__inner::-webkit-input-placeholder {
    color: #999999;
  }
  .center-reminder {
    top: calc(50% - 26px);
    min-width: 235px;
    height: 120px;
    border-radius: 20px;
    background-color: #000;
    opacity: 0.6;
    padding-top: 14px;
    & .el-message__group {
      width: 100%;
      height: 100%;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      & p {
        font-size: 18px;
        color: #fff;
      }
    }
  }
</style>

