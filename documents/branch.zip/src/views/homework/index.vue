<template lang="pug">
  router-view.body-container
</template>
<script>
  export default {
    name: 'homework'
  }
</script>
<style scoped>
</style>
