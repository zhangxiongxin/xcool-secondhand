<template lang="pug">
  div.flex
    .container
      img(src="~assets/imgs/cry.png", draggable="false")
      p 没有搜到含有该关键字的结果
</template>
<script>
  export default {
    name: 'noSearchResult'
  }
</script>
<style scoped>
  .flex {
    height: calc(100% - 109px);
    margin-top: -40px;
    display: flex;
    align-items: top;
    justify-content: center;
  }
  
  .container {
    text-align: center;
    font-size: 18px;
    margin-top: 25%;
    color: #666666;
    & p {
      line-height: 26px;
    }
  }
</style>
