<template lang="pug">
  div.homework_container
    x-header.homework_header(style="font-size: 20px;" @on-click-back="back" :left-options="{ preventGoBack:true }") 校内作业/考试
    search(@search="search1")
    div.slicer
    no-result(v-if="resultFlag && !sResultFlag")
    no-search-result(v-if="sResultFlag && !resultFlag")
    card(v-if="assignHistory", v-for="(item, index) in assignHistory", :item='item', :key="index", :onInfinite="onInfinite", :loadData="loadHistoryLists", :lightTarget="homeworkQuery.examName", @demo="upData")
    infinite-loading(v-if="assignHistory", :on-infinite="onInfinite", ref="infiniteLoading", spinner="circles")
      span(slot="no-more") 没有更多内容了
      span(slot="no-results")
</template>
<script>
// import userService from '@/services/user'
import homeworkService from '@/services/homework'
import store from '@/store'
import card from './card'
import InfiniteLoading from 'vue-infinite-loading'
import noResult from './noResult'
import noSearchResult from './noSearchResult'
export default {
  data() {
    return {
      resultFlag: false,
      sResultFlag: false,
      sClick: false,
      searchModel: '',
      assignHistory: [],
      homeworkQuery: { pageNum: 1, pageSize: 5, teacherId: store.getters.teacherId, examName: '', status: 0, submit: 0, correct: 0 },
      parentExamIdList: []
    }
  },
  components: { card, InfiniteLoading, noResult, noSearchResult },
  methods: {
    search1(data) {
      this.sClick = true
      this.resultFlag = false
      this.sResultFlag = false
      this.assignHistory = []
      this.homeworkQuery.pageNum = 1
      this.homeworkQuery.examName = data
      // this.onInfinite() 下面的reset方法已经发了一次请求了
      this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
    },
    back() {
      this.$router.push('/homepage')
    },
    upData() {
      this.assignHistory = []
      this.homeworkQuery.pageNum = 1
      this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
    },
    onInfinite() {
      this.loadHistoryLists().then((v) => {
        if (v && v.items && v.items.length) {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
          this.homeworkQuery.pageNum += 1
        } else {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
        }
      })
    },
    loadHistoryLists(data) {
      return homeworkService
        .homeworkList(this.homeworkQuery).then(res => {
          this.assignHistory = this.assignHistory.concat(res.data.items)
          if (this.assignHistory.length === 0) {
            if (this.sClick) {
              this.sResultFlag = true
            } else {
              this.resultFlag = true
            }
          }
          // console.log(this.parentExamIdList)
          return Promise.resolve(res.data)
        }).catch(res => {
          this.resultFlag = true
        })
    }
  }
}
</script>

<style scoped>
  .homework_container {
    position: relative;
  }
  .slicer {
    background: #EBF2FD;
    width:100%;
    height:10px;
    margin-top: 99px;
  }
  .homework_header {
    width: 100%;
    height: 44px;
    position: fixed;
    top: 0;
    left: 0;
    /*margin-bottom: 44px;*/
    z-index: 2
    }
  .search {
    position: fixed;
    top: 44px;
    left: 0;
    height: 55px;
    width: 100%;
    background: #F4F8FF;
    z-index: 2;
  }
  .search_left {
    position: fixed;
    left: 0;
  }
  .search span {
    position: fixed;
    left: 44px;
  }
  .search_input {
    margin-top: 13px;
    width: 78.6666%;
    height: 28px;
    border-radius: 5px;
    color: #666;
    background: #fff;
    font-size: 14px;
    float: left;
    border: 1px solid #BFD7FF;
    margin-left: 2.1333%;
  }
  .search_icon {
    margin-left: 8px;
    margin-right: 12px;
  }
  .search_input::-webkit-input-placeholder {
    color: #999;
  }
  .search_btn {
    margin-top: 13px;
    border: none;
    float: left;
    width: 13.8666%;
    background: #3399FF;
    color: #fff;
    font-size: 14px;
    border-radius: 4px;
    margin-left: 2.4%;
  }
  .search_input.weui-cell {
    padding-left: 0;
  }
  .search_input.vux-x-input.weui-cell.search_input::before {
    border-top: none;
  }
  .out_word {
    font-size: 13px;
    color: #8F8E94;
    text-align: center;
    line-height: 45px;
    background: #fff;
    border-radius: 12px 12px 0 0;
    width: 94.6666%;
    margin: 0 auto;
  }
  .affirm_btn {
    font-size: 20px;
    color: #3399FF;
    line-height: 54px;
    border-radius: 0 0 12px 12px;
    background: #fff;
    width: 94.6666%;
    margin: 0 auto;
  }
  .vux-popup-dialog {
    background: rgba(255,255,255,0);
  }
  .cancel_btn {
    width: 94.6666%;
    margin: 0 auto;
    margin-top: 10px;
    margin-bottom: 9px;
    border-radius: 12px;
    background: #fff;
    color: #3399FF;         
  }
  .assist_icon {
    width: 25px;
    height: 20px;
    margin-left: 6px;
    vertical-align: -22%;
  }
</style>
