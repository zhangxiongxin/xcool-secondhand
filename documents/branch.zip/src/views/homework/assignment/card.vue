<template lang="pug">
  div.content(v-show="item.revoked === 0")
    div.content_detail
      div.content_detail_top
        div.content_detail_top_up
          div.content_detail_status
            img.notstart_icon(src="~assets/imgs/assignment/no_start.png" v-if="item.status === 1")
            img.notstart_icon(src="~assets/imgs/assignment/ing.png" v-if="item.status === 2")
            img.notstart_icon(src="~assets/imgs/assignment/end.png" v-if="item.status === 3")
            span.end.words(v-if="item.status === 3") 已结束
            span.ing.words(v-if="item.status === 2") 进行中
            span.notstart.words(v-if="item.status === 1") 未开始          
          div.content_detail_title
            z-high-light.subject-name(:text="item.examName", :target="lightTarget")
              img.test_icon(src="~assets/imgs/kaoshi.png" v-if="item.sourceType === 'training'")
              img.test_icon(src="~assets/imgs/assignment/icon_coach@3x.png" v-if="item.sourceType === 'book'")
              img.test_icon.vacation_icon(src="~assets/imgs/assignment/ico.hanjiatubiao@4x.png" v-if="item.sourceType === 'vacation'")            
        div.shin_slicer
        div.content_detail_top_down
          div.content_detail_topic(style="float:left") 单选题<i>{{ item.choiceCount }}</i>道 填空题<i>{{ item.fillInCount }}</i>道 解答题<i>{{ item.solutionCount }}</i>道<br>共{{ item.questionCount }}道
            div(v-if="item.sourceType === 'training'")
              img.score_icon(src="~assets/imgs/assignment/bg_homeworklist_score@2x.png")
              span.score 总分 <i>{{ item.totalScore }}分</i>
          div.content_detail_number(style="float:left") 已提交 <i>{{ item.countSubmited }}</i> 人<br>共 {{ item.studentCount }} 人
      div.content_detail_center
        img.calendar_icon(src="~assets/imgs/assignment/icon_hoeworklist_calender@3x.png")
        div.content_detail_center_right
          span.detail_time {{item.createTime | date}} 布置给&nbsp
          span.className(v-for="(item, index) in classNameList[0]") {{ item.className }}
            i(v-if="classNameList[0].length !== 0 && index !== classNameList[0].length - 1") 、
        div.shin_slicer
      div.content_detail_bottom
        div.content_detail_bottom_left(style="float:left;")
          div.start_time
            img.time_icon(src="~assets/imgs/assignment/icon_hoeworklist_time_start@3x.png")
            span.time_word {{item.startTime | date}} 开始
          div.end_time
            img.time_icon(src="~assets/imgs/assignment/icon_hoeworklist_time_end@3x.png")
            span.time_word {{item.endTime | date}} 结束
        div.content_detail_bottom_right(v-if="item.countSubmited > 0")
          span.not_over(v-if="item.countNotCorrected !== 0 || item.countSubmited !== item.studentCount") 已批阅 <i>{{ item.countCorrected }} </i>人 <br> 待批阅 {{ item.countNotCorrected }} 人
          span.all_over(v-if="item.countNotCorrected === 0 && item.countSubmited === item.studentCount") 全部批阅完成
        button.withdraw.active(@click="withdraw(item.examId, item.sourceType, item.creatorId)" v-if="item.countSubmited === 0") 撤回
        button.withdraw(disabled v-if="item.countSubmited > 0") 撤回
        button.check_btn(@click="to" v-if="item.countCorrected > 0") 班级{{item.sourceType === 'training' ? '考试' : '作业'}}报告
        button.check_btn(disabled @click="to" v-if="item.countCorrected === 0" style="background: #C8C8C8;") 班级{{item.sourceType === 'training' ? '考试' : '作业'}}报告
    div.slicer(style="background: #EBF2FD;width:100%;height:10px;box-shadow: 0 2px 4px 0 rgba(38, 93, 148, 0.23) inset;")
</template>

<script>
import store from '@/store'
import homeworkService from '@/services/homework'
export default {
  name: 'item',
  props: ['item', 'loadData', 'lightTarget', 'onInfinite'],
  data() {
    return {
      sourceType: 0, // 0 套题，1 教辅
      classListStr: '',
      showDialog: false,
      stuLists: [],
      showNoDownload: false,
      notDownloadState: false,
      downloadedState: false,
      notSubmitState: false,
      submitedState: false,
      hasSubmitedState: false,
      hasNotSubmitedState: false,
      correctedState: false,
      haveWorkJob: false,
      itemStatus: 0,
      classNameList: []
    }
  },
  methods: {
    loadClassName() {
      var that = this
      var params = {
        examIds: this.item.examId,
        teacherId: store.getters.teacherId
      }
      homeworkService
        .homeworkListExtra(params).then(res => {
          if (res.data) {
            that.classNameList.push(res.data[0].classInfo)
          }
        }).catch(() => {
        })
    },
    withdraw(id, type, createdId) {
      let that = this
      this.$vux.confirm.show({
        // 组件除show外的属性
        title: '确定要撤回吗？',
        onConfirm () {
          if (createdId === store.getters.teacherId) {
            homeworkService
            .revokeHomework({ examId: id, teacherId: store.getters.teacherId, teacherName: store.getters.teacherName }).then(res => {
              if (res.data.success) {
                var source = ''
                switch (type) {
                  case 'training':
                    source = 'training'
                    break
                  default :
                    source = 'exerhome'
                    break
                }
                that.classNameList[0].forEach(v => {
                  let eventParams = {
                    teacherId: store.getters.teacherId,
                    operationType: 'retract',
                    sourceType: source,
                    eventName: 'EVENT_OPERATION_RECORD',
                    classId: v.classId,
                    examId: id
                  }
                  that.$event(eventParams)
                })
                that.$emit('demo')
              } else {
                that.$vux.alert.show({
                  title: '',
                  content: '已有学生上传，撤回失败',
                  onHide() {
                    that.$emit('demo')
                  }
                })
              }
            }).catch(res => {
            })
          } else {
            that.$vux.alert.show({
              title: '',
              content: '不能撤回由其他老师布置的作业，请返回查看后重试！！',
              onHide() {
                that.$emit('demo')
              }
            })
          }
        }
      })
    },
    to() {
      let url = `/homework/workpaper/${this.item.examId}/${this.item.sourceType}/${this.item.examName}`
      this.$router.push(url)
    }
  },
  created() {
    this.loadClassName()
  }
}
</script>

<style scoped>
  .content_detail {
    
  }
  .content_detail_top {
    /* overflow: hidden; */
    width: 100%;
    /*height: 98.4px;  */
    background: #fff;
  }
  .content_detail_title {
    display: inline-block;
    /*overflow: hidden;*/
    /*text-overflow: ellipsis;*/
    /*white-space: nowrap;*/
    width: 100%;
    padding-bottom: 10px;
  }
  .content_detail_top_up {
    /*height: 38.5px;*/
    margin-left: 2.9333%;
    margin-right: 2.9333%;
    position: relative;
    /*overflow: hidden;*/
  }
  .content_detail_status {
    display: inline-block;
    position: absolute;
    top: 13px;
    left: 10px;
    width: 55px;
    vertical-align: center;
  }
  .notstart_icon {
    width: 14px;
    height: 14px;
  }
  .words {
    font-size: 12px;
    line-height: 14px;
    position: absolute;
    left: 18px;
  }
  .notstart {
    color: #FF8625;
  }
  .ing {
    color: #7FD349
  }
  .end {
    color: #999
  }
  .shin_slicer {
    background: #ECF2FC;
    height: 1px;
    width: 96%;
    margin-left: 2%;
  }
  .subject-name{
    position: relative;
    font-size: 18px;
    line-height: 25px;
    margin-top: 7px;
    color: #333;
    text-indent: 68px;
    padding:0 10px;
    word-break: break-all;
/*    display: flex;
    flex-wrap: wrap;*/
  }
  .content_detail_top_down {
    height: 74.5px;
  }
  .score_icon {
    position: absolute;
    bottom: -5px;
    right: -5px;
    width: 40px;
    height: 40px;
  }
  .score {
    position: absolute;
    bottom: 5px;
    right: 0;
    color: #333;
  }
  .score i {
    color: #EE3E3E;
    font-size: 12px;
    font-style: normal;
  }
  .content_detail_topic {
    position: relative;
    height: 48px;
    width: 65.0666%;
    background: #F8FBFF;
    margin-top: 12.5px;
    margin-left: 2.9333%;
    margin-right: 2.6666%;
    background-image: url('~assets/imgs/assignment/bg_homeworklist_subjects@3x.png');
    background-size: 50px 41.4px;
    background-repeat: no-repeat;
    background-position: 100% 91.6666%;
    padding-left: 2.6666%;
    padding-top: 7px;
    font-size: 12px;
    line-height: 17px;
    color: #666;
  }
  .content_detail_topic i {
    color: #267ACF;
  }
  .content_detail_topic .score i {
    color: #EE3E3E;
  }
  .content_detail_number {
    background: #FFF9F0;
    height: 48px;    
    width: 26.6666%;
    margin-top: 12.5px;
    background-size: 50px 41.4px;
    background-image: url('~assets/imgs/assignment/bg_homeworklist_nu_students@3x.png');
    background-repeat: no-repeat;
    background-position: 100% 91.6666%;
    padding-left: 2.6666%;
    padding-top: 7px;
    font-size: 12px;
    line-height: 17px;
    color: #666;
  }
  .content_detail_number i {
    font-style: normal;
    color: red;
  }
  .content_detail_center {
    position: relative;
    width: 100%;
    /* height: 48px; */
    /* padding-left: 6px; */
  }
  .content_detail_center_right {
    display: inline-block;
    width: calc(94.6666% - 25px);
    padding-left: calc(5.3333% + 25px);
    padding-top: 14px;
    line-height: 20px;
    padding-bottom: 14px;
  }
  .test_icon {
    display: inline-block;
    width: 25px;
    height: 20px;
    margin-left: 6px;
    position: relative;
    top: 3px;
/*    position: absolute;
    right: 0;
    bottom: 0;*/
  }

  .vacation_icon {
    height: 24px;
  }
  .content_detail_bottom {
    width: 100%;
    height: 129px;
    box-shadow: 0 2px 4px 0 rgba(38, 93, 148, .23);
  }
  .calendar_icon {
    width: 14px;
    height: 14.4px;
    margin-left: 5.3333%;
    position: absolute;
    top: 17px;
  }
  .detail_time {
    display: inline-block;
    font-size: 14px;
    line-height: 20px;
    color: #151515;
  }
  .content_detail_bottom_left {
    margin-left: 5.3333%;
    margin-right: 5.3666%;
    width: 60%;
  }
  .start_time {
    margin-top: 14px;
    height: 24px; 
  }
  .className {
    font-size: 14px;
    color:#333;
  }
  .time_icon {
    width: 14px;
    height: 14px;
    vertical-align: middle;       
  }
  .time_word {
    display: inline-block;
    padding-left: 10px;
    color: #999;
    font-size: 12px;
    line-height: 24px;       
  }
  .content_detail_bottom_right {
      margin-top: 14px;
      background: #F1FFCE;
      width: 26.6666%;
      height: 48px;
      float: left;
      background-image: url('~assets/imgs/assignment/bg_homeworklist_correcting@3x.png');
      background-size: 48px 47px;
      background-position: right top;
      background-repeat: no-repeat;
      /* padding-top: 18px; */
      font-size: 14px;
      color: #77B830;
  }
  .not_over {
      display: inline-block;
      margin-top: 7px;
      font-size: 12px;
      line-height: 17px;
      margin-left: 11px;
      color: #666;
  }
  .not_over i {
    color: #7FD349;
  }
  .all_over {
      display: inline-block;
      margin-left: 11px;    
      line-height: 48px;
  }
  .content_detail_bottom_right i {
      font-style: normal;
      color: #7FD349;
  }
  .check_btn {
    display: initial;
    border:none;
    width: 50.6666%;
    margin: 0 auto;
    margin-top: 14px;
    text-align: center;
    margin-left: 2.6666%;
    border-radius: 19.5px;
    background: #4F9AFB;
    color: #fff;
    height: 39px;
    font-size: 18px;
    line-height: 39px;
    float: left;
  }
  .check_btn.weui-btn.weui-btn_default {
    margin-top: 14px;
  }
  .withdraw {
    display: initial;
    border:none;
    margin: 0 auto;
    margin-top: 14px;
    text-align: center;
    margin-left: 5.0666%;
    border-radius: 19.5px;
    background: #C7C7C7;
    color: #fff;
    height: 39px;
    font-size: 18px;
    line-height: 37px;
    width: 36.5333%;
    float: left;
  }
  .withdraw.active {
    background: #EDF2FB;
    border: 2px solid #4F9AFB;
    color: #4F9AFB;
  }
</style>
