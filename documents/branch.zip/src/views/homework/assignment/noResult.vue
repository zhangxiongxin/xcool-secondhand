<template lang="pug">
  div.flex
    .container
      img(src="~assets/imgs/cry.png", draggable="false")
      p 没有查询到校内作业/考试
</template>
<script>
  export default {
    name: 'noResult'
  }
</script>
<style scoped>
  .flex {
    height: calc(100% - 129px);
    /*margin-top: -40px;*/
    display: flex;
    align-items: top;
    justify-content: center;
  }
  
  .container {
    text-align: center;
    margin-top: 25%;
    font-size: 18px;
    color: #666666;
    & p {
      line-height: 26px;
    }
  }
</style>
