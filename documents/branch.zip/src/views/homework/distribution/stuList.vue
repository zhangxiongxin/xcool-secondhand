<template lang="pug">
  div.answer_container
    div.stu_option(v-if="$store.state.homework.activeIndex !== -1")
      div.left_container
        button.left.side(v-if="$store.state.homework.activeIndex !== 0" @click="pre")
          x-icon.left_icon(type="arrow-left-b" size="20px")
          span.btn_name {{ stuList[$store.state.homework.activeIndex - 1].studentName }}
      div.center_container(flex="main:center")
        button.center(v-if="stuList.length !==0", @click="back", :class="{ up: $store.state.homework.up }")
          span.active_name {{ stuList[$store.state.homework.activeIndex].studentName }}
          x-icon.up_icon(type="arrow-up-b" size="20px" v-if="up")
          x-icon.down_icon(type="arrow-down-b" size="20px" v-if="!up")
      div.right_container
        button.right.side(v-if="$store.state.homework.activeIndex < stuList.length - 1" @click="next")
          span.btn_name {{ stuList[$store.state.homework.activeIndex + 1].studentName }}
          x-icon.right_icon(type="arrow-right-b" size="20px")
</template>
<script>
import { detailName, detailAnswer, up } from '@/store/types'
import store from '@/store'

export default {
  props: ['stuList'],
  data() {
    return {
      index: 0,
      isActive: false,
      up: false
    }
  },
  methods: {
    pre() {
      store.state.homework.activeIndex -= 1
    },
    next() {
      store.state.homework.activeIndex += 1
    },
    back() {
      this.up = !this.up
      store.commit(detailAnswer)
      store.commit(detailName)
      store.commit(up)
    }
  }
}
</script>
<style scoped>
  .up_icon {
    fill: #4F9AFB;
    position: absolute;
    top: 5px;
    right: 2px;
  }
  .down_icon {
    fill: #4F9AFB;
    position: absolute;
    top: 5px;
    right: 2px;
  }
  .left_icon {
    fill: #fff;
    position: absolute;
    top: 5px;
    left: 1px;
  }
  .right_icon {
    fill: #fff;
    position: absolute;
    top: 5px;
    right: 1px;
  }
  .stu_option {
    /*margin-top: 44px;*/
    height: 48px;
    background: #ECF2FC;
    width: 100%;
    position: relative;
    box-shadow: 0 2px 6px 0 #D4DDEE;
  }
  .stu_option button {
    float: left;
    border: none;
    margin-top: 10px;
  }
  .left_container {
    position:absolute;
    top:0;
    left:0;
    width:80px;
    height:100%;
    margin-left: 2.6666%;
  }
  .center_container {
    margin: 0 calc(2.6666% + 80px);
    height: 100%;
    text-align: center;
    position: relative;
  }
  .right_container {
    position:absolute;
    top:0;
    right:0;
    width:80px;
    height:100%;
    margin-right: 2.6666%;
  }
  .center {
    position: relative;
    max-width: 100px;
    color: #4F9AFB;
    text-align: center;
    font-size: 18px;
    height: 30px;
    line-height: 25px;
    text-shadow: 0 2px 4px rgba(49,118,187,0.26);
  }
  .side {
    position: relative;
    overflow: hidden;
    background: #3399ff;
    border-radius: 15px;
    box-shadow: 0 2px 6px 0 rgba(45,94,144,0.40);
    color: #fff;
    font-size: 12px;
    line-height: 17px;
    height: 30px;
    width: 80px;
  }
  .btn_name {
    display: inline-block;
    width: 48px;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    line-height: 30px;
  }
  .active_name {
    display: inline-block;
    max-width: 90px;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    line-height: 30px;
    padding-right: 23px;
  }
</style>
