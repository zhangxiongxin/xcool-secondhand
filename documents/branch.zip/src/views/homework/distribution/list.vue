<template lang="pug">
  div.container
    div.list_container
      p 本题答错的学生{{ errorNum }}人
      section.names
        button.stu_btn.error_btn(v-for="(name,index) in errorList", @click="scan(index)" v-bind:class="{ active: index === $store.state.homework.activeIndex }") {{ name.studentName }}
    div.list_container
      p 本题答对的学生{{ rightNum }}人
      section.names
        button.stu_btn.right_btn(v-for="(name,index) in rightList", @click="scan(index + errorList.length)", v-bind:class="{ active: index === $store.state.homework.activeIndex - errorList.length }") {{ name.studentName }}
</template>
<script>
import { up, activeIndex, headName, detailName, detailAnswer } from '@/store/types'
import store from '@/store'

export default {
  props: ['rightNum', 'errorNum', 'rightList', 'errorList'],
  data() {
    return {
    }
  },
  methods: {
    scan(n) {
      store.commit(activeIndex, n)
      store.commit(detailName)
      if (!store.state.homework.headName) {
        store.commit(headName)
      }
      store.commit(detailAnswer)
      if (store.state.homework.up) {
        store.commit(up)
      }
    }
  }
}
</script>
<style scoped>
  .stu_btn.right_btn.active {
    background: #77B830;
    color: #fff;
  }
  .stu_btn.error_btn.active {
    background:  #FF6B6B;
    color: #fff;
  }
  .container {
    background: #fff;
    position: relative;
  }
  .container.top {
    /*margin-top: 44px;*/
  }
  .list_container {
    margin-left: 5.3333%;
    overflow: hidden;
    color: #666;
    font-size: 14px;
    line-height: 20px;
  }
  .list_container p {
    width: 150px;
    margin-top: 20px;
  }
  .stu_btn {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-top: 10px;
    width: 105px;
    float: left;
    text-align: center;
    background: none;
    margin-right:10px;
    border-radius: 6px;
    height: 40px;
    font-size: 18px;
    line-height: 25px;
  }
  .error_btn {
    color: #FF6B6B;
    border: 1px #FF6B6B solid;
  }
  .right_btn {
    color: #77B830;
    border: 1px #77B830 solid;
    background: #EEF9E3;
  }
</style>
