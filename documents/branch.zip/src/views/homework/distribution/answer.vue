<template lang="pug">
  div(style="height: calc(100% - 48px);")
    .temg(v-if="item.stemg")
      .questionType {{ itemType }}
      div
        latex.stemg(:text='numInPaper + "、" + item.stemg', :latexImgs='item.stemLatexGraph', :imgs='item.stemGraph')
      div
        latex.stemg(:text="item.subStemg", :imgs="item.subStemGraph", :latexImgs="item.subStemLatexGraph")
    loading(:show="true", v-if="!item.stemg")
    .answer(v-if="$store.state.homework.activeIndex !== -1 && item.stuNotes")
      button.ansBtn.stuAnswer(@click="scanStuAnswer", v-bind:class="{ active: stuActive  }") 学生答案
      button.ansBtn.standardAnswer(@click="scanStandardAnswer", v-bind:class="{ active: staActive  }") 参考答案
      //- 如果没有学生笔记提示  该题未作答
      template(v-if="result[$store.state.homework.activeIndex] && stuAnswer")
        section.answerDetail
          div(style="position: relative; display: inline-block; width: 100%;")
            img.pic.custom-img(@load="imgLoad = true", :src="result[$store.state.homework.activeIndex] | remoteFile(true)", draggable="false", style="width: 100%;",v-show="imgLoad")
            check-mark(v-show="imgLoad", v-for="(ckMark, index) in JSON.parse(mark[$store.state.homework.activeIndex])", :key="index", :markInfo="ckMark", :index="index", :disabled="true")
      section.answerDetail(v-if="!result[$store.state.homework.activeIndex] && stuAnswer") 该题未作答
      div.answerDetail(v-if="standardAnswer")
        p(v-for="answer in item.stdAnswers")
          latex(:text="answer.contentg", :imgs="answer.graph", :latexImgs="answer.contentLatexGraph")
</template>
<script>
import store from '@/store'
import homeworkService from '@/services/homework'
import latex from '@/components/common/latex'
export default {
  props: [ 'numInPaper', 'questionId', 'questionType', 'stuList' ],
  components: { latex },
  data() {
    return {
      item: {},
      testPath: '',
      itemType: '',
      imgLoad: false,
      standardAnswer: false,
      stuAnswer: true,
      stuActive: true,
      staActive: false,
      result: [],
      mark: []
    }
  },
  methods: {
    scanStuAnswer() {
      this.stuActive = true
      this.staActive = false
      this.stuAnswer = true
      this.standardAnswer = false
    },
    scanStandardAnswer() {
      this.staActive = true
      this.stuActive = false
      this.stuAnswer = false
      this.standardAnswer = true
    }
  },
  watch: {
    questionType: function () {
      if (this.questionType === 'fillIn') {
        this.itemType = '填空题'
      } else if (this.questionType === 'choice') {
        this.itemType = '选择题'
      } else if (this.questionType === 'solution') {
        this.itemType = '解答题'
      } else {
        this.itemType = '未知题型'
      }
    }
  },
  created() {
    if (this.questionType === 'fillIn') {
      this.itemType = '填空题'
    } else if (this.questionType === 'choice') {
      this.itemType = '选择题'
    } else if (this.questionType === 'solution') {
      this.itemType = '解答题'
    } else {
      this.itemType = '未知题型'
    }
    const params = {
      questionId: this.questionId,
      examId: store.state.homework.examId,
      classId: store.state.homework.classId,
      examType: store.state.homework.examType === 'training' ? 3 : 2
    }
    homeworkService
      .stuWrongDetail(params).then(res => {
        this.item = res.data
        for (let path1 of this.stuList) {
          for (let path2 of this.item.stuNotes) {
            if (path1.studentId === path2.studentId) {
              this.result.push(path2.path)
              this.mark.push(path2.checkResult)
            }
          }
        }
      }).catch(res => {
      })
  }
}
</script>
<style scoped>
  .ansBtn.standardAnswer.active {
    box-shadow: none;
    height: 44px;
    border-bottom: none;
  }
  .ansBtn.stuAnswer.active {
    box-shadow: none;
    height: 44px;
    border-bottom: none;
  }
  .stemg {
    max-width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
  }
  .stemg .latex-warp .latex-img {
    max-width: 100%;
  }
  .stemg .stem-graph {
    max-width: 100%;
  }
  .temg {
    margin: 0 auto;
    margin-top: 20px;
    margin-bottom: 22px;
    width: 89.3333%;
  }
  .answer {
    padding-top: 12px;
    background: #ECF2FC;
    vertical-align: top;
    position: relative;
    height: 56px;
  }
  .ansBtn {
    position: absolute;
    top: 12px;
    display: inline-block;
    padding: 0;
    width: calc(50% - 2px);
    height: 40px;
    font-size: 16px;
    line-height: 22px;
    color: #4F9BFF;
    background: #FFFFFF;
  }
  .stuAnswerImg {
    width: 100%;
  }
  .stuAnswer {
    margin-right: 4px;
    border-radius: 0 4px 0 0;
    border: none;
    border-top: 1px solid #D0E0FF;
    border-right: 1px solid #D0E0FF;
    border-bottom: 1px solid #D0E0FF;
    height: 40px;
    box-shadow: 0 2px 4px 0 #D4DDEE;
  }
  .standardAnswer {
    left: calc(50% + 2px);
    box-shadow: 0 2px 4px 0 #D4DDEE;
    border: 1px solid #D0E0FF;
    border-right: none;
  }
  .answerDetail {
    position: absolute;
    top: 70px;
    left: 5.3333%;
    width: 89.3333%;
  }
  .questionType {
    font: 18px;
    line-height: 25px;
    margin-bottom: 10px;
  }
</style>
<style>
  .stemg .stem-graph {
    max-width: 100%;
  }
</style>
