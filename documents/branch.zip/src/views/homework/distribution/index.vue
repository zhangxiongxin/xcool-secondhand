questionType<template lang="pug">
  //- 题目的正确与错误的分布
  div.container
    x-header.mistakes_header(style="font-size: 20px;", :left-options="{preventGoBack: true}", @on-click-back='close')
      span 学生答案
    //- router-view
    div.component_container(style="overflow: auto;")
      stu-list(v-if="$store.state.homework.headName", :stuList='stuList')
      list(v-if="$store.state.homework.detailName", :errorNum='errorNum', :rightNum='rightNum', :rightList='rightList', :errorList='errorList')
      answer(v-if="$store.state.homework.detailAnswer", :numInPaper="numInPaper", :questionId="questionId", :questionType="questionType", :stuList='stuList')
      p {{ a }}
</template>
<script>
import list from './list'
import stuList from './stuList'
import answer from './answer'
import homeworkService from '@/services/homework'
import store from '@/store'
import { questionId, initStatus, classId, examId, examType } from '@/store/types'

export default {
  props: ['config'],
  data() {
    return {
      a: '',
      errorNum: 0,
      rightNum: 0,
      errorList: [],
      rightList: [],
      stuList: [],
      index: this.config.index,
      questionId: this.config.questionId,
      subQuestionId: this.config.subQuestionId,
      numInPaper: '',
      questionType: ''
    }
  },
  components: { list, stuList, answer },
  methods: {
    close() {
      this.$emit('close')
    },
    loadStuList(data) {
      var params1
      if (this.subQuestionId !== 'undefined') {
        params1 = {
          questionId: this.questionId,
          examId: store.state.homework.examId,
          classId: store.state.homework.classId,
          examType: store.state.homework.examType === 'training' ? 3 : 2,
          subQuestionId: this.subQuestionId
        }
        this.subQuestionId = null
      } else {
        params1 = {
          questionId: this.questionId,
          examId: store.state.homework.examId,
          classId: store.state.homework.classId,
          examType: store.state.homework.examType === 'training' ? 3 : 2
        }
      }
      if (store.state.homework.examType !== 'training') {
        var params2 = {
          classId: store.state.homework.classId,
          examId: store.state.homework.examId,
          source: store.state.homework.examType === 'book' ? 1 : 0
        }
      } else {
        var params3 = {
          classId: store.state.homework.classId,
          examId: store.state.homework.examId
        }
      }
      homeworkService
        .stuWrongDetail(params1).then(res => {
          let data = res.data
          this.errorNum = data.wrongStudents.length
          this.errorList = data.wrongStudents
          this.rightList = data.rightStudents
          this.rightNum = data.rightStudents.length
          if (!this.rightList && this.errorList) {
            this.stuList = this.errorList
          } else if (this.rightList && !this.errorList) {
            this.stuList = this.rightList
          } else if (!this.rightList && !this.errorList) {
            this.stuList = null
          } else {
            this.stuList = this.errorList.concat(this.rightList)
          }
        }).catch(res => {
        }).then(res => {
          if (params2) {
            homeworkService
              .getErrorSpread(params2).then(res => {
                let index = this.index
                this.numInPaper = res.data.wrongQuestionList[index].numInPaper
                let indexPoint = res.data.wrongQuestionList[index].numInPaper.indexOf('.')
                if (indexPoint > 0) {
                  this.numInPaper = res.data.wrongQuestionList[index].numInPaper.slice(0, indexPoint)
                } else {
                  this.numInPaper = res.data.wrongQuestionList[index].numInPaper
                }
                this.questionType = res.data.wrongQuestionList[index].questionType
              })
          } else {
            homeworkService
              .getWeekErrorSpread(params3).then(res => {
                let index = this.index
                this.numInPaper = res.data.paperWrongQuestionList[index].numInPaper
                let indexPoint = res.data.paperWrongQuestionList[index].numInPaper.indexOf('.')
                if (indexPoint > 0) {
                  this.numInPaper = res.data.paperWrongQuestionList[index].numInPaper.slice(0, indexPoint)
                } else {
                  this.numInPaper = res.data.paperWrongQuestionList[index].numInPaper
                }
                this.questionType = res.data.paperWrongQuestionList[index].questionType
              })
          }
        })
    }
  },
  mounted() {
    this.loadStuList()
    store.commit(questionId, this.questionId)
  },
  created() {
    this.$store = store
    store.commit(initStatus)
    store.commit(classId, this.config.classId)
    store.commit(examId, this.config.examId)
    store.commit(examType, this.config.questionType)
  }
}
</script>
<style scoped>
  .container {
    height: 100%;
    position: relative;
    /*padding-bottom: 44px;*/
  }
  .component_container {
    height: calc(100% - 44px);
    margin-top: 44px;
    position: relative;
  }
  .mistakes_header {
    width: 100%;
    height: 44px;
    position: fixed;
    top: 0;
    left: 0;
    /*margin-bottom: 44px;*/
    z-index: 2
    }
</style>
