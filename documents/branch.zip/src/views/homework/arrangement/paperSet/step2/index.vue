<template lang="pug">
  div(style="height: 100%")
    x-header.header(title="填写作业信息", :left-options="{preventGoBack: true, backText: '首页'}", @on-click-back='openConfirm()')
    confirm(v-model="showConfirm", title="退出布置作业将不会保存您当前选择的内容", confirm-text="退出", cancel-text="继续布置", @on-confirm="onConfirm")
    warning-box(v-show="showWarning", @goback="closeDialog")
      .warning_box(slot="body", v-if="errorStatus === 2")
        div
          span 您正在布置的教辅或套题不能在当前班级
          span(v-for="(item, index) in notBugClass", :key="index") 【{{item.className}}】
            span(v-if="index !== (notBugClass.length - 1)") 、
          span 所在的学校中使用，请返回查看后重试
      .warning_box(slot="body", v-if="errorStatus === 1")
        div
          span(v-for="(item, index) in notBugClass", :key="index") 【{{item.className}}】
            span(v-if="index !== (notBugClass.length - 1)") 、
          span 没有关联将要布置的教辅或套题。
        p(style="margin-top: 10px;") 您可以联系豆豆客服添加教辅或套题后再布置，客服电话：400-9928-918。
      .warning_box(slot="body", v-if="errorStatus === 3")
        div 24小时内本次作业已布置给同一批学生。
    .fill_conatin
      .name_title 作业名称
      input.title_input(v-model="hometitle", :show-clear="false", :maxlength="30", :class="{warn: hasError === 'examName'}", @focus="focus", @blur='nameChange')
      .tip 
        span(v-show='hasError === "examName"') *请填写作业名称
      upload-method(@selectMethod="selectMethod")
      .tip 
        span(v-show=" hasError === 'noMethod'") *请选择上传方式
      class-list(@saveGroup="saveGroup")
      .tip 
        span(v-show=" hasError === 'class'") *至少选择一个班级
      group.time_select
        datetime(v-model="begintime", title="开始时间", format="YYYY-MM-DD HH:mm", @on-change="startChange")
      group.time_select
        datetime(v-model="endtime", title="结束时间", format="YYYY-MM-DD HH:mm", @on-change="timeChange", :class="{warn: hasError === 'endTime'}")
      .tip
        span(v-show=" hasError === 'weekLimit'") 开始与结束时间间隔不能超过7天 
        span(v-show=" hasError === 'endTime'") *至少比开始时间晚1小时
          span.auto-adjust(@click="adjustEnd") 自动调整
      .count_box
        .title 已选择{{detailResource[0].title}}
        .flex
          div 单选题{{detailResource[0].choiceCount}}道
          div 填空题{{detailResource[0].fillInCount}}道
          div 解答题{{detailResource[0].solutionCount}}道
          div (共{{detailResource[0].questionCount}}题)
    toast(v-model="showToast" type="warn" :time="1000" is-show-mask text="作业布置失败" )
    alert(v-model="showAlert", button-text="知道了", @on-hide="hideAlert")
      div.alert_slot(slot="default")
        img.alert_icon(src="~assets/imgs/提示-3@3x.png")
        p
          span(v-for="stu in sameStuArry", style="margin-right: 8px") {{stu.studentName}}
          span(style="margin-left: 4px") 同时存在于多个班级
        p 无法完成布置
    .btn_box
      button.btn(@click="back('/homework/arrangement/paperSet/step1')") 重新选题
      button.btn(@click="beginAssign", :disabled="!!progress") {{btnLabel}}
    dd-loading(:ddLoading="!!progress")
</template>
<script>
  import { dateCompatible } from '@/filters/doudou'
  import dateFilter from '@/filters/date'
  import classList from './classList'
  import uploadMethod from '../../textBook/step2/uploadMethod.vue'
  import warningBox from '../../warningBox'
  const oneDay = 24 * 60 * 60 * 1000
  const oneHour = 60 * 60 * 1000

  import homeworkService from '@/services/homework'
  import store from '@/store'
  import { updatePaperValue, replaceInPaper, checkPaperInfo, assignPaperSet, initPaperAssign, filtInfoInPaper } from '@/store/types'

  const btnLabels = ['完成布置', '请稍候...', '布置成功']

  export default {
    name: 'step2',
    components: { classList, warningBox, uploadMethod },
    data() {
      const dateNow = Date.parse(new Date())
      return {
        showWarning: false,
        showConfirm: false,
        showToast: false,
        showAlert: false,
        progress: 0,
        queryId: this.$route.params.id,
        hometitle: dateFilter(dateNow, 'yyyy-MM-dd') + ' 作业',
        begintime: dateFilter(dateNow),
        endtime: dateFilter(dateNow + oneDay),
        notBugSchoolIds: [],
        errorStatus: 0
      }
    },
    methods: {
      pushEvent(classId, examId) {
        this.$event({ classId: classId, operationType: 'create', sourceType: 'exerhome', examId: examId })
      },
      openConfirm() {
        this.showConfirm = true
      },

      back(url) {
        this.$router.push(url)
      },

      onConfirm() {
        store.commit(initPaperAssign)
        this.back('/homepage')
      },

      // 自动调整开始时间
      adjustStart(othertime) {
        let now = othertime || Date.parse(new Date())
        this.begintime = dateFilter(now)
        this.startChange()
        store.commit(checkPaperInfo, true)
      },

      // 自动调整结束时间
      adjustEnd() {
        let now = Date.parse(dateCompatible(this.begintime))
        this.endtime = dateFilter(now + oneHour)
        store.commit(checkPaperInfo, true)
      },

      // 开始布置作业，先作业名称判重，再布置
      beginAssign() {
        store.commit(checkPaperInfo)
        if (this.hasError) return

        this.progress = 1

        let times = 0
        let rename
        const defaultTitle = this.hometitle
        var homework = this.hometitle

        var that = this
        const pollingTitle = function() {
          homeworkService
            .renameHomework({ name: homework })
            .then(res => {
              // 重复返回 1 ，未重复返回 2
              let repeat = res.data
              if (repeat === 1) {
                ++times
                rename = ('0000' + times).substr(times.toString.length + 2)
                homework = defaultTitle + rename
                pollingTitle()
              } else {
                that.hometitle = homework
                store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'examName', value: that.hometitle })

                that.assign()
              }
            })
            .catch(() => {
              that.progress = 0
            })
        }
        pollingTitle()
      },

      // 布置作业
      assign() {
        store.dispatch(assignPaperSet)
          .then(res => {
            // res.status  0:成功，1：套题、教辅权限问题
            if (res.status === 0) {
              this.progress = 2

              // 发送点击流事件,,每个班发送一次
              let tempArry = []
              let tempMap = {}

              res.homeworks.forEach(v => {
                if (!tempMap[v.classId]) {
                  tempMap[v.classId] = true
                  tempArry.push(v)
                }
              })

              tempArry.forEach(v => {
                this.pushEvent(v.classId, v.examId)
              })

              store.commit(initPaperAssign)
              this.$router.push('/homework/assignment')
            } else if ((res.status === 1) || (res.status === 2) || (res.status === 3)) {
              // 教辅、套题有权限问题
              // 保存权限信息并显示
              if (res.errPermissions && res.errPermissions.length) {
                res.errPermissions.forEach(item => {
                  this.notBugSchoolIds.push(item.schoolId)
                })
              }
              this.errorStatus = res.status

              this.showWarning = true

              this.progress = 0
            }
          })
          .catch(() => {
            this.progress = 0
            this.showToast = true
          })
      },

      // 作业名改变后重新提交
      nameChange() {
        store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'examName', value: this.hometitle })
        store.commit(checkPaperInfo, true)
      },

      focus() {
        store.commit(checkPaperInfo, true)
      },

      // 时间改变重新提交
      timeChange() {
        store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'startTime', value: Date.parse(dateCompatible(this.begintime)) })
        store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'endTime', value: Date.parse(dateCompatible(this.endtime)) })
      },

      startChange() {
        this.endtime = dateFilter(Date.parse(dateCompatible(this.begintime)) + oneDay)
        this.timeChange()
      },

      hideAlert() {
        store.commit(checkPaperInfo, true)
      },

      closeDialog() {
        this.showWarning = false
        this.notBugSchoolIds = []
        this.errorStatus = 0
      },

      // 修改上传方式
      selectMethod(type) {
        store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'uploadType', value: type })
        store.commit(checkPaperInfo, true)
      },

      // 是否保存自组合
      saveGroup(isSave) {
        store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'saveGroup', value: isSave })
      }
    },
    computed: {
      hasError() {
        return store.state.paperSet.hasError
      },
      btnLabel() {
        return btnLabels[this.progress || 0]
      },
      detailResource() {
        return store.state.paperSet.paperList.filter(v => {
          return v.paperSetId === this.queryId
        })
      },
      sameStuArry() {
        let selectStu = store.state.paperSet.assignPaperSet.students
        if (selectStu && !selectStu.length) return selectStu
        let tempArry = []
        let sameStuArry = []
        selectStu.forEach(v => {
          if (!tempArry[v.studentId]) {
            tempArry[v.studentId] = true
          } else {
            sameStuArry.push(v)
          }
        })
        return sameStuArry
      },
      selectClassMap() {
        let selectStu = store.state.paperSet.assignPaperSet.students
        let tempMap = {}
        if (!selectStu.length) return []
        else {
          selectStu.forEach(item => {
            // 构建学校id键值对
            if (!tempMap[item.schoolId]) {
              tempMap[item.schoolId] = []
            }

            // 根据班级id判断是否已添加班级元素
            let index = tempMap[item.schoolId].findIndex(x => {
              return x.classId === item.classId
            })

            // 为找到对应班级信息push进数组
            if (index === -1) tempMap[item.schoolId].push({ classId: item.classId, className: item.className })
          })
        }
        return tempMap
      },
      notBugClass() {
        let arry = []
        if (this.notBugSchoolIds.length) {
          this.notBugSchoolIds.forEach(item => {
            arry = arry.concat(this.selectClassMap[item])
          })
        }
        return arry
      }
    },
    created() {
      // 获取过滤的套题index信息
      store.dispatch(filtInfoInPaper, { paperId: this.queryId })
      store.commit(updatePaperValue, { key: 'assignPaperSet', name: 'paperSetId', value: this.queryId })
    },
    mounted() {
      // 提交时间
      this.timeChange()
        // 初始化有误为空
      store.commit(replaceInPaper, { name: 'hasError', value: '' })

      this.nameChange(this.hometitle)
    },
    watch: {
      hasError(n, o) {
        if (n === 'sameStu') this.showAlert = true
        else this.showAlert = false
      }
    }
  }
</script>
<style scoped>
  .header {
    width: 100%;
    position: fixed;
    z-index: 200;
    top: 0px;
  }
  
  .name_title {
    font-size: 20px;
    color: #666666;
    line-height: 28px;
    padding-left: 10px;
    border-left: 4px solid #3399FF;
    margin: 65px 0px 10px 30px;
  }
  
  .title_input {
    border: none;
    outline: none;
    border-top: 1px solid #D2D2D2;
    border-bottom: 1px solid #D2D2D2;
    height: 50px;
    width: 100%;
    font-size: 18px;
    color: #666666;
    padding-left: 45px;
  }
  
  .time_select {
    & .vux-datetime {
      border-top: 1px solid #D2D2D2;
      border-bottom: 1px solid #D2D2D2;
      height: 50px;
      background: #FFFFFF;
    }
    & p {
      font-size: 20px;
      color: #666;
    }
  }
  
  .count_box {
    margin: 10px 30px 100px 30px;
  }
  
  .title {
    line-height: 22px;
    font-size: 16px;
    color: #666;
    margin-bottom: 5px;
    & span {
      color: #FF7B02;
      margin-left: 6px;
    }
  }
  
  .flex {
    line-height: 22px;
    display: flex;
    flex-wrap: wrap;
    & div {
      font-size: 16px;
      color: #666;
      margin-right: 5px;
    }
  }
  
  .btn_box {
    position: fixed;
    z-index: 200;
    display: flex;
    justify-content: space-between;
    align-items: center;
    bottom: 0px;
    width: 100%;
    height: 93px;
    background: rgba(255, 255, 255);
    box-shadow: 0 -2px 6px 0 rgba(0, 0, 0, 0.1);
    padding: 0px 23px;
    & .btn {
      font-size: 20px;
      color: #FFFFFF;
      border: none;
      width: 45%;
      height: 50px;
      background: #3399FF;
      box-shadow: 0 2px 4px 0 rgba(42, 108, 173, 0.50);
      border-radius: 100px;
    }
  }
  
  .tip {
    height: 22px;
    line-height: 22px;
    font-size: 14px;
    color: #FF5353;
    margin-left: 30px;
  }
  
  .warn {
    border: 1px solid red !important;
  }
  
  .auto-adjust {
    color: #E4CEFF;
    margin-left: 5px;
  }
  
  .alert_icon {
    width: 50px;
    margin-bottom: 20px;
  }
  
  .alert_slot {
    & p {
      line-height: 25px;
    }
  }
  
  .fill_conatin {
    height: 100%;
    overflow: auto;
  }
  
  .warning_box {
    color: #666;
  }
</style>
<style>
  .time_select {
    & .vux-datetime {
      & p {
        padding-left: 15px;
        font-size: 20px;
        color: #666;
      }
    }
  }
</style>
