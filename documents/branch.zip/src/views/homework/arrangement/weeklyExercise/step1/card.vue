<template lang="pug">
  .card_contain
    .title
      z-high-light.name(:text="item.title", :target="lightTarget")
      z-high-light.name(:text="item.gradeName", :target="lightTarget")
      z-high-light.name(:text="createTime", :target="lightTarget")
      .source(v-if="item.authority === 'organization'") 校本 
    .info_container
      .item_count
        div 单选题 {{item.choiceCount}} 道
        div 填空题 {{item.fillInCount}} 道
        div 解答题 {{item.solutionCount}} 道
        div 共 {{item.questionCount}} 道
      .flex_box
        .left_box
          div 我用过 {{item.useTimesByCurrentUser}} 次
          .mid_line |
          div 使用 {{item.useTimes}} 次
          .mid_line |
          div {{item.collectorNum}} 人收藏
        .right_box(v-if="item.paperSetType === 'examSet'") 总分
          .score_num {{item.totalScore}}分
    .btn_container
      router-link(:to="`/homework/arrangement/questionsDetail?paperSetId=${item.paperSetId}&paperSetType=${item.paperSetType}`", style="width: 100%")
        button.check 查看
      button.select(@click="select(item)") 选择
</template>
<script>
  import dateFilter from '@/filters/date'
  import store from '@/store'

  export default {
    name: 'card',
    props: ['item'],
    methods: {
      select(item) {
        let url = '/homework/arrangement/weeklyExercise/step2/' + item.paperSetId
        this.$router.push(url)
      }
    },
    computed: {
      lightTarget() {
        return store.state.weeklyExercise.queryPaperList.keyWords
      },
      createTime() {
        return dateFilter(this.item.createTime)
      }
    }
  }
</script>
<style scoped>
  .card_contain {
    margin-top: 2px;
    margin-bottom: 8px;
    box-shadow: 0 0px 6px 0 #D4DDEE;
    background: #FFFFFF;
    padding: 7px 10px 18px;
    & .title {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      font-size: 18px;
      color: #333333;
      padding-bottom: 8px;
      border-bottom: 1px solid #ECF2FC;
      & .name {
        max-width: 100%;
        line-height: 25px;
        margin-left: 10px;
      }
    }
  }
  
  .source {
    width: 38px;
    height: 21px;
    text-align: center;
    line-height: 19px;
    background: #EDF2FB;
    border: 1px solid #3399FF;
    border-radius: 4px;
    color: #3399FF;
    font-size: 14px;
    margin-left: 15px;
  }
  
  .info_container {
    position: relative;
    background: #F7FAFF;
    min-height: 48px;
    margin: 12px 10px 20px;
    padding-left: 11px;
    padding-top: 7px;
    background-image: url('~assets/imgs/assignment/bg_homeworklist_subjects@3x.png');
    background-size: 48px 47px;
    background-position: right top;
    background-repeat: no-repeat;
  }
  
  .item_count {
    line-height: 18px;
    font-size: 12px;
    color: #666666;
    display: flex;
    flex-wrap: wrap;
    & div {
      margin-right: 8px;
    }
  }
  
  .flex_box {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    & .left_box {
      width: calc(100% - 70px);
      line-height: 18px;
      color: #666666;
      display: flex;
      flex-wrap: wrap;
      & div {
        margin-right: 8px;
      }
    }
    & .right_box {
      margin-right: 40px;
      line-height: 18px;
    }
  }
  
  .score_num {
    width: 40px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    color: #EE3E3E;
    position: absolute;
    right: 0px;
    bottom: -6px;
    background-size: 40px 40px;
    background-image: url('~assets/imgs/assignment/bg_homeworklist_score@2x.png');
  }
  
  .btn_container {
    display: flex;
    justify-content: space-between;
    margin: 0 10px;
    & button {
      font-size: 16px;
      width: 85%;
      height: 42px;
      box-shadow: 0 2px 6px 0 rgba(32, 103, 174, 0.27);
      border-radius: 78px;
      border: none;
    }
    & .check {
      line-height: 38px;
      background: #EDF2FB;
      border: 2px solid #3399FF;
      color: #3399FF;
    }
    & .select {
      background: #3399FF;
      color: #FFF;
    }
  }
</style>
