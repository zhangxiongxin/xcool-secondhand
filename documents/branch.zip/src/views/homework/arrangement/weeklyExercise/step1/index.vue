<template lang="pug">
  div(style="height: 100%; padding-top: 160px;")
    .fix_header
      x-header(title="选择套题(考试)", :left-options="{preventGoBack: true}", @on-click-back='back')
      sort(@sortClick="sortClick")
      search(@search="searchHandle", placeholder="搜索套题名称")
    .item_contain
      no-paper(v-if="paperList && !paperList.length && !searchKey && !loading")
      no-search-paper(v-if="paperList && !paperList.length && searchKey && !loading")
      template(v-for="item in paperList", v-show="!loading && paperList && paperList.length")
        card(:item="item")
      infinite-loading(:on-infinite="onInfinite" ref="infiniteLoading" spinner="circles")
        span(slot="no-more") 没有更多内容了
        span(slot="no-results") 
</template>
<script>
  import card from './card'
  import noPaper from '../../noPaper'
  import noSearchPaper from '../../noSearchPaper'
  import InfiniteLoading from 'vue-infinite-loading'
  import store from '@/store'
  import { getWeeklyPapers, addWeeklyPageNum, replaceInWeek, updateWeeklyValue, initWeeklyPaper, initWeeklyAssign } from '@/store/types'

  export default {
    name: 'step1',
    components: { card, InfiniteLoading, noPaper, noSearchPaper },
    data() {
      return {
        loading: true,
        firstLoad: true,
        searchKey: ''
      }
    },
    computed: {
      paperList() {
        return store.state.weeklyExercise.paperList
      }
    },
    methods: {
      back() {
        store.commit(initWeeklyAssign)
        this.$router.push('/homepage')
      },
      // 排序回调
      sortClick(data) {
        this.loading = true
        this.cleanData()
        store.commit(updateWeeklyValue, { key: 'queryPaperList', name: 'sort', value: data })
          // 必须对懒加载做初始化，否则下拉失效
        this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
      },
      // 搜索回调
      searchHandle(data) {
        this.searchKey = data
        this.loading = true
        this.cleanData()
        store.commit(updateWeeklyValue, { key: 'queryPaperList', name: 'keyWords', value: data })
          // 必须对懒加载做初始化，否则下拉失效
        this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
      },
      // 初始化数据
      cleanData() {
        store.commit(initWeeklyPaper)
        store.commit(replaceInWeek, { name: 'paperList', value: [] })
      },
      // 懒加载
      onInfinite() {
        store.dispatch(getWeeklyPapers)
          .then((v) => {
            if (v.data.items && v.data.items.length) {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
              store.commit(addWeeklyPageNum)
              this.loading = false
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
              this.loading = false
            }
          })
      }
    },
    created() {
      // 初始化数据
      this.cleanData()
    }
  }
</script>
<style scoped>
  .fix_header {
    width: 100%;
    position: fixed;
    z-index: 200;
    top: 0px;
  }
  
  .item_contain {
    height: 100%;
  }
</style>
