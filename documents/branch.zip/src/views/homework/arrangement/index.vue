<template lang="pug">
  router-view.bg_color
</template>
<script>
  export default {
    name: 'arrangement'
  }
</script>
<style scoped>
  .bg_color {
    background-color: #E8F3FF
  }
</style>
