<template lang="pug">
  div
    x-header(title="布置作业/考试")
    .btn_contain
      .btn(@click="to('/homework/arrangement/textBook')") 选择教辅 (作业)
      .btn.margin-top(@click="to('/homework/arrangement/paperSet')") 选择套题 (作业)
      .btn.margin-top(@click="to('/homework/arrangement/weeklyExercise')") 选择套题 (考试)
</template>
<script>
  export default {
    name: 'arrangeHome',
    methods: {
      to(url) {
        this.$router.push(url)
      }
    }
  }
</script>
<style scoped>
  .btn_contain {
    padding-top: 50px;
    padding-bottom: 50px;
    height: calc(100% - 46px);
    overflow: auto;
/*    display: flex;
    align-items: center;
    justify-content: center;*/
    /*margin-top: -25px;*/
    & .btn {
      margin: 0 auto;
      width: 80%;
      height: 116px;
      text-align: center;
      line-height: 112px;
      background: #3399FF;
      border: 2px solid #FFFFFF;
      box-shadow: 0 4px 10px 0 rgba(23, 77, 132, 0.50);
      border-radius: 20px;
      font-size: 28px;
      color: #FFFFFF;
      text-shadow: 0 2px 6px #1C6BB9;
    }
    & .margin-top {
      margin-top: 20px;
    }
  }
</style>
