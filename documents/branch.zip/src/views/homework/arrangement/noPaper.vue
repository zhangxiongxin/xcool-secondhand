<template lang="pug">
  div.flex
    .container
      img(src="~assets/imgs/cry.png", draggable="false")
      p 没有可用的套题
      p 请使用PC客户端组建套题或联系
      p 400-9928-918
</template>
<script>
  export default {
    name: 'noPaper'
  }
</script>
<style scoped>
  .flex {
    height: calc(100% - 20px);
    /*margin-top: -40px;*/
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .container {
    text-align: center;
    font-size: 18px;
    color: #666666;
    & p {
      line-height: 26px;
    }
  }
</style>
