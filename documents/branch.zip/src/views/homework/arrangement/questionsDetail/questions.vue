<template lang="pug">
  ul.list-questions
    li(v-for="(qType, $index) in types")
      slot(name="teachingBook",:qType="qType" v-if="source ==='1'" )
      slot(name="title", :qType="qType", :$index="$index", :qLength="formatArr[qType].length" v-if="source !== '1'")
        div(style="height: 48px;")
          h3.qs-title(:id="`${qType}Title`") {{$index+1 | localNum}}、{{qType | questionType}}
            span(v-if='paperSetType === "examSet"') &nbsp;{{countScore(formatArr[qType])}}分
      transition-group(name="list-complete", tag="div")
        div(v-for="(item, index) in formatArr[qType]", :key="item.questionId")
          slot(name="body", :qType="qType", :$index="$index", :index="item._$index", :item="item", :length="formatArr[qType].length")
</template>
<script>
  import { questionType } from '@/filters/doudou'
  const map = { choice: 0, mutichoice: 1, fillin: 2, judge: 3, calculation: 4, solution: 5 }

  export default {
    name: 'questions',
    props: ['items', 'showTotalScore', 'source', 'paperSetType'],
    computed: {
      types() {
        // 选择，填空，解答 排序
        return Object.keys(this.formatArr).sort((a, b) => (map[a] > map[b]))
      },
      formatArr() {
        const data = {}
        if (this.source !== '1') {
          if (Array.isArray(this.items)) {
            this.items.forEach((v, i) => {
              v._$index = i
              const type = questionType(v.questionType, true)
              if (!data[type]) data[type] = []
              data[type].push(v)
            })
          }
        } else {
          if (Array.isArray(this.items)) {
            this.items.forEach((v, i) => {
              v._$index = i
              const type = v.bookName + ' ' + v.sectionName
              if (!data[type]) data[type] = []
              data[type].push(v)
            })
          }
        }
        return data
      }
    },
    methods: {
      countScore(itemArry) {
        let totalScore = 0
        itemArry.forEach(v => {
          totalScore += v.score
        })
        return totalScore
      }
    }
  }
</script>
<style scoped>
  .qs-title {
    width: 100%;
    padding: 15px;
    font-size: 18px;
    color: #333333;
  }
  .qs-title.fixed{
    position: fixed;
    top: 0px;
    background-color: #EDF2FB;
    box-shadow: 0 2px 6px 0 #D4DDEE;
  }
</style>
