<template lang="pug">
  //- 单题详情
  section.card
    //- 题目信息
    div.question-info
      div.left
        p.info(v-if="paperSetType === 'examSet'") {{item.score}}分
        rater(:value="difficult", :max="5", :disabled="true", active-color="#FFEA75", :margin="0", :font-size="16")
        span.points(:title="knowledgesContent") 知识点：{{ knowledgesContent }}
        p.error-rate 错误率 {{ item.errorRate | rateFilter }}
      div.right
        p 使用 {{ item.useTimes }} 次
        p {{ item.likeTimes }} 人收藏
    //- 题目题干、答案
    div.question-stem
      .qs-stem
        latex(:text="item.stemg", :latexImgs="item.stemLatexGraph", :imgs="item.stemGraph")
          slot
            span {{item.numInPaper}} 、
      .qs-sub-stem
        latex(:text="item.subStemg", :latexImgs="item.subStemLatexGraph || item.subLatexGraph", :imgs="item.subStemGraph || item.subGraph", :class="'sub-stem-'+item.questionType")
</template>
<script>
  import { difficulty } from '@/filters/doudou'

  export default {
    name: 'itemInfo',
    props: {
      // 单题数据
      item: {
        type: Object,
        required: true
      },
      index: {
        type: Number,
        required: true
      },
      // 套题类型  试卷/普通套题
      paperSetType: {
        type: String,
        required: true
      }
    },
    computed: {
      // 难度星级
      difficult() {
        if (!this.item.difficult) return 0
        return difficulty(this.item.difficult)
      },
      // 知识点
      knowledgesContent() {
        if (!this.item.knowledges) return ''
        else return this.item.knowledges.map(v => v.knowledgePointName).join('、')
      }
    }
  }
</script>
<style scoped>
  .card {
    min-height: 145px;
    margin-top: 8px;
    padding: 20px 10px;
    box-shadow: 1px 0 3px 5px #F6F8FA;
    &>.question-info {
      display: flex;
      align-items: center;
      height: 48px;
      font-size: 12px;
      color: #666666;
    }
    & .left {
      width: 70%;
      height: 100%;
      margin-right: 10px;
      padding: 7px 9px;
      background: #F7FAFF url('~assets/imgs/bg_homeworklist_subjects@2x.png') no-repeat right center;
      background-size: 50px 41.4px;
      &>.info {
        display: inline-block;
        margin-right: 5px;
        font-size: 12px;
        color: #3399FF;
      }
      &>.vux-rater {
        width: 80px;
      }
    }
    & .points {
      display: inline-block;
      width: calc(100% - 121.4px);
      padding-left: 10px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    & .error-rate {
      margin-top: 5px;
    }
    & .right {
      width: 30%;
      height: 100%;
      padding: 7px 10px;
      background: #FFF8F0 url('~assets/imgs/bg_homeworklist_nu_students@2x.png') no-repeat right center;
      background-size: 50px 41.4px;
      line-height: 17px;
      &>p {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }

    &>.question-stem {
      color: #666666;
      padding: 0 9px;
      &>.qs-stem {
        margin-top: 10px;
        margin-bottom: 7px;
      }
    }
  }
</style>
<style>
  /*特殊latex-break样式,一个答案单独占一行*/
  .card {
    /*兼容safari横屏时字体变大*/
    -webkit-text-size-adjust: 100%;
    & .qs-sub-stem .latex-break {
      display: block;
      margin: 5px 0;
    }
    & img {
      max-width: 100%;
    }
  }
</style>
