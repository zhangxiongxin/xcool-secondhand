<template lang="pug">
  //- 套题/试卷 详情
  div.questions-detail
    x-header.questions-header(:title="paperSetType === 'examSet' ? '查看试卷题目' : '查看套题题目'", @on-click-title="goTopHandle")
    scroll(ref="scroll", :refreshDelay="1000", :probeType="3", style="height: calc(100% - 46px); margin-top: 46px;", :data="detailData.questions", :listenScroll="true", @scroll="scrollHandle", :pullup="true", @scrollToEnd="refreshHandle")
      div.content-container(ref="contentContainer", v-show="detailData.questions.length")
        //- 题目数量
        section.question-count
          ul
            li 单选题 {{ detailData.choiceCount }} 道
            li 填空题 {{ detailData.fillInCount }} 道
            li 解答题 {{ detailData.solutionCount }} 道
          div 
            p 共 {{ detailData.questionCount }} 题
            p.total-score(v-if="paperSetType === 'examSet'") 总分 {{ detailData.totalScore }} 分
        //- 题目列表
        section.question-list
          questions(:items="detailData.questions", :paperSetType="detailData.paperSetType")
            template(slot="body", scope="scope")
              item-info(:item="scope.item", :index="scope.index", :paperSetType="detailData.paperSetType")
        load-more(:show-loading="false", tip="没有更多内容了")

    //- 粘性题型标题
    div.sticky-title(ref="stickyTitle", style="height: 48px;", v-show="stickyTitleVisible")
      h3.qs-title-fixed {{ stickyTitleText }}
</template>
<script>
  import store from '@/store'

  import homeworkServices from '@/services/homework'
  import questions from './questions'
  import itemInfo from './itemInfo'

  // import boxHeightJudge from '@/utils/boxHeightJudge'

  export default {
    name: 'questionsDetail',
    components: { questions, itemInfo },
    data() {
      return {
        // 套题类型 exerhomeSet：套题  examSet：试卷
        paperSetType: '',
        // 套题详情数据
        detailData: {
          questions: []
        },
        // 粘性标题显隐
        stickyTitleVisible: false,
        // 粘性标题内容
        stickyTitleText: '',

        // 是否是UC浏览器(手机上的IE，毒瘤！)
        isUC: window.navigator.userAgent.indexOf('UCBrowser') >= 0
      }
    },
    methods: {
      // 获取套题详情
      getQuestionsDetail(paperSetId) {
        this.$vux.loading.show({ text: '玩命加载中' })
        const teacherId = store.getters.teacherId
        homeworkServices.queryPaperDetail({ teacherId: teacherId, paperSetId: paperSetId, isSearchTime: true })
          .then(res => {
            this.detailData = res.data
            this.$nextTick(() => {
              // // 判断内容容器高度是否稳定
              // boxHeightJudge(this.$refs.contentContainer, () => {
              //   // 重新计算滚动效果
              //   this.$refs.scroll.refresh()
              // })
              this.$vux.loading.hide()
            })
          })
          .catch(() => { this.$vux.loading.hide() })
      },
      // 滚动事件
      scrollHandle() {
        // 题型标题DOM
        const titleDoms = document.querySelectorAll('.qs-title')

        // 粘性标题显隐切换
        if (titleDoms[0].getBoundingClientRect().top <= 46) this.stickyTitleVisible = true
        else this.stickyTitleVisible = false

        // 粘性标题内容切换
        if (!titleDoms[1] || titleDoms[1].getBoundingClientRect().top > 60) {
          this.stickyTitleText = titleDoms[0].innerText
          return
        }

        // titleDoms.forEach((v, i) => {
        //   // this.demo ++
        //   if (i && v.getBoundingClientRect().top <= 60) {
        //     this.stickyTitleText = v.innerText
        //   }
        // })

        // 用for是为了兼容坑爹的UC浏览器！！
        for (let i = 0, len = titleDoms.length; i < len; i++) if (i && titleDoms[i].getBoundingClientRect().top <= 60) this.stickyTitleText = titleDoms[i].innerText
      },
      // 重新计算滚动效果
      refreshHandle() {
        this.$refs.scroll.refresh()
      },
      // 回到顶部
      goTopHandle() {
        this.$refs.scroll.scrollTo(0, 0, 500)
      }
    },
    created() {
      // 套题类型
      this.paperSetType = this.$route.query.paperSetType
      // 获取套题详情数据
      this.getQuestionsDetail(this.$route.query.paperSetId)
    }
  }
</script>
<style scoped>
  .questions-detail {
    background-color: #FFFFFF;
  }
  .questions-header {
    position: fixed;
    z-index: 999;
    top: 0;
    width: 100%;
  }
  .content-container {
    overflow: hidden;
    /*padding-top: 46px;*/
  }
  .question-count {
    display: flex;
    align-items: center;
    margin: 10px;
    height: 90px;
    background-color: #EDF2FB;
    border-radius: 4px;
    color: #3479D2;
    &>ul {
      width: 66%;
      height: calc(100% - 14px);
      padding-left: 14px;
      border-right: 1px solid #90C2F3;
      font-size: 16px;
      &>li {
        line-height: calc(76px / 3);
      }
    }
    &>div {
      display: flex;
      flex-direction: column;
      width: 34%;
      height: 100%;
      font-size: 21px;
      align-items: center;
      justify-content: center;
    }
    & .total-score {
      font-size: 16px;
      margin-top: 6px;
    }
  }
  .sticky-title {
    position: fixed;
    top: 46px;
    background-color: #EDF2FB;
    box-shadow: 0 2px 6px 0 #D4DDEE;
    width: 100%;
    padding: 15px;
    font-size: 18px;
    color: #333333;
  }
</style>
<style>
  .questions-header {
    & .vux-header-title {
      margin-right: 0;
      padding-right: 88px;
    }
  }  
</style>
