<template lang="pug">
  .no-contain
    div(style="text-align: center; margin-top: -100px;")
      .no-img
      .no-tip 还没有教辅资源，请联系客服添加
      .phone-num 400-9928-918
</template>
<script>
  export default {
    name: 'noBook'
  }
</script>
<style scoped>
  .no-contain {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .no-img {
    margin: 0 auto;
    width: 183px;
    height: 183px;
    background: url('~assets/imgs/cry.png');
  }
  
  .no-tip {
    line-height: 30px;
    font-size: 18px;
    color: #666;
    text-align: center;
    margin-top: 20px;
  }
  
  .phone-num {
    line-height: 30px;
    font-size: 18px;
    color: #666;
  }
</style>
