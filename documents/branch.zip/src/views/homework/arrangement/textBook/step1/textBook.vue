<template lang="pug">
  .textbook
    warning-dialog(v-show="showWarning", @goback="gobackHandle")
      .limit_tip(slot="body") 不能跨教辅选题哦，亲。
    el-tree.tree(:data="textBook",:props="textbookProps",empty-text='加载中...', :highlight-current="false", :render-content="renderContent", @node-click="nodeClick", :expand-on-click-node='true')
</template>
<script>
  import store from '@/store'
  import { getSectionItems, textbookTreeClick } from '@/store/types'

  export default {
    name: 'textBook',
    data() {
      return {
        showWarning: false,
        textbookProps: {
          children: 'sections',
          label: 'sectionName'
        }
      }
    },
    computed: {
      textBook() {
        return store.state.textBook.textBook
      }
    },
    methods: {
      // 关闭warningDiaglog
      gobackHandle() {
        this.showWarning = false
      },
      nodeClick(data, node) {
        if (!data.canClick) return
          // 如果是叶子节点且sections没有数据，则获取数据
        if (data.position === 'sectionLeaf' && !data.sections[0]) {
          this.$emit('loading', true)
          store.dispatch(getSectionItems, data)
            .then(res => {
              // 异步加载结束打开节点
              node.expanded = true
              this.$emit('loading', false)
            })
        }
      },
      countCheck(data) {
        if (data && data.sections) {
          let checked = data.sections.filter(v => v.checked)
          let all = data.sections.length
          if (checked.length > 0 && checked.length < all) return true
          else return false
        }
        return false
      },
      renderContent(createElement, { node, data }) {
        var that = this
        return createElement('span', {
          class: {
            'margin-left': data.position === 'sectionLeaf' && !data.sections[0],
            'par_span': true
          }
        }, [
          createElement('span', {
            'class': {
              'expand-icon': data.position === 'sectionLeaf' && !data.sections[0]
            }
          }),
          createElement('span', {
            'class': {
              'label_span': true
            }
          }, node.label),
          createElement('span', {
            'class': {
              'click_area': (data.position !== 'sectionLeaf' && data.canClick) || (data.position === 'sectionLeaf' && data.sections[0])
            },
            'on': {
              click: function(e) {
                if (!data.canClick) return
                  // 如果有数据
                if ((data.position === 'sectionLeaf' && data.sections[0]) || data.position !== 'sectionLeaf') {
                  e.stopPropagation()
                    // 点击节点选中所有
                  if (data.position === 'sectionLeaf') {
                    data.singleClick = false
                    store.dispatch(textbookTreeClick, data).catch(() => {
                      that.showWarning = true
                    })
                  } else {
                    // 点击题目选中当前
                    data.singleClick = true
                    store.dispatch(textbookTreeClick, data).catch(() => {
                      that.showWarning = true
                    })
                  }
                }
              }
            }
          }, [
            createElement('span', {
              'class': {
                'cus-checkbox': (data.position !== 'sectionLeaf' && data.canClick) || (data.position === 'sectionLeaf' && data.sections[0]),
                'checkin': data.checked,
                'indeterminate': data.position === 'sectionLeaf' && this.countCheck(data)
              }
            })
          ])
        ])
      }
    }
  }
</script>
<style scoped>
  .limit_tip {
    font-size: 20px;
    color: #666;
    line-height: 28px;
    margin-top: 30px;
    margin-bottom: 40px;
  }
</style>
<style>
  .textbook {
    overflow: hidden;
    & .el-tree {
      border: none;
      background: transparent;
    }
    & .el-tree-node__label {
      font-size: 20px;
      color: #666;
    }
    & .el-tree-node__content {
      height: 50px;
      line-height: 50px;
      position: relative;
      &:after {
        content: "";
        position: absolute;
        top: 47px;
        left: 0px;
        z-index: 1100;
        margin-left: 60px;
        width: 100%;
        height: 1px;
        background-color: #90C2F4;
      }
    }
    & .el-tree-node__expand-icon {
      border-left-color: #3399FF;
    }
    & .el-tree-node__expand-icon.is-leaf {
      border-color: transparent;
    }
    & .el-tree > .el-tree-node > .el-tree-node__content {
      background: #EDF2FB !important;
      border: 1px solid #CBE5FF;
    }
    & .el-tree > .el-tree-node {
      & >.el-tree-node__content:first-child {
        &:after {
          background-color: transparent;
        }
      }
    }
    & .el-tree-node__content:hover {
      background-color: transparent !important;
    }
  }
  
  .cus-checkbox {
    vertical-align: middle;
    display: inline-block;
    position: relative;
    border-radius: 50%;
    border: 1px solid #C7C7CD;
    width: 22px;
    height: 22px;
    background-color: #FFF;
    z-index: 1;
    margin-left: 24px;
  }
  
  .checkin {
    vertical-align: middle;
    display: inline-block;
    position: relative;
    border-radius: 50%;
    border: 1px solid #0076FF;
    width: 22px;
    height: 22px;
    background-color: #0076FF;
    border-color: #0076FF;
    z-index: 1;
    margin-left: 24px;
    &::after {
      content: '';
      border: 2px solid #FFF;
      border-left: 0;
      border-top: 0;
      height: 12px;
      width: 6px;
      position: absolute;
      top: 3px;
      left: 7px;
      transform: rotate(45deg) scaleY(1);
      transition: transform .15s cubic-bezier(.71, -.46, .88, .6) .05s;
      transform-origin: center;
    }
  }
  
  .indeterminate {
    vertical-align: middle;
    display: inline-block;
    position: relative;
    border-radius: 50%;
    border: 1px solid #C7C7CD;
    width: 22px;
    height: 22px;
    background-color: #FFF;
    z-index: 1;
    margin-left: 24px;
    &::before {
      content: '';
      position: absolute;
      display: block;
      border: 1px solid #84C826;
      margin-top: -1px;
      width: 8px;
      height: 8px;
      left: 6px;
      top: 7px;
      border-radius: 50%;
      background-color: #0076FF;
      border-color: #0076FF;
    }
  }
  
  .expand-icon {
    display: inline-block;
    vertical-align: middle;
    cursor: pointer;
    width: 0;
    height: 0;
    margin-left: 10px;
    margin-right: 8px;
    border: 6px solid transparent;
    border-right-width: 0;
    border-left-color: #3399FF;
    border-left-width: 7px;
    transform: rotate(0deg);
  }
  
  .margin-left {
    margin-left: -25px;
  }
  
  .click_area {
    display: inline-block;
    position: absolute;
    right: 0px;
    width: 70px;
    height: 100%;
  }

  .par_span {
    display: inline-block;
    width: calc(100% - 40px);
  }

  .label_span {
    vertical-align: middle;
    display: inline-block;
    max-width: 70%;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>
