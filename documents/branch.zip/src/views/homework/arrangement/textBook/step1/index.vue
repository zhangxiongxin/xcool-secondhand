<template lang="pug">
  div
    x-header(title="选择教辅(作业)", :left-options="{preventGoBack: true}", @on-click-back='back')
    loading(:show="loading", text="玩命加载中")
    warning-dialog(v-show="showWarning", @goback="gobackHandle")
      .limit_tip(slot="body") 单次教辅作业添加题数不能超过40题，您可以把一份教辅作业拆分成多份作业进行布置。
    p.is_loading(v-if="isLoading")
      inline-loading
      span(style="vertical-align:middle;display:inline-block;font-size:14px;") 加载中
    no-book.nobook(v-if="textBook && !textBook.length && !loading")
    .textbook_conatin(v-if="textBook && textBook.length && !loading")
      div(style="display: flex; align-items: center; padding: 0 20px; height: 45px;")
        .title 题目选择
        .tips (教辅名前加“DZ_”的是按豆豆数学特定格式排版的定制教辅，未加“DZ_”的是学校发放的原版教辅。)
      .text_book 
        text-book(@loading='changeLoading')
      btn-box.btn(@next='next', :selectQues="selectQues")
</template>
<script>
  import store from '@/store'
  import { getTextbooks, initTextbook, updateBookValue } from '@/store/types'

  import textBook from './textBook'
  import btnBox from './btnBox'
  import noBook from './noBook'

  export default {
    name: 'step1',
    components: { textBook, btnBox, noBook },
    data() {
      return {
        showWarning: false,
        loading: true,
        isLoading: false
      }
    },
    computed: {
      textBook() {
        return store.state.textBook.textBook
      },
      selectQues() {
        let selectQues = []
        store.state.textBook.questions.forEach(v => {
          if (v.selected) selectQues.push(v)
        })
        return selectQues
      },
      textBookMap() {
        return store.state.textBook.textBookMap
      }
    },
    methods: {
      // 关闭warningDiaglog
      gobackHandle() {
        this.showWarning = false
      },
      next(totalCount) {
        if (totalCount > 40) {
          this.showWarning = true
          return
        }

        // 选取第一道题取bookId，对照textBookMap判断是否是假期作业教辅
        let bookId = this.selectQues[0].bookId
        let type = this.textBookMap[bookId]
        let sourceType = type === 'vacationwork' ? 'vacation' : 'book'
        // 修改布置参数中的sourceType
        store.commit(updateBookValue, { key: 'assignTextbook', name: 'sourceType', value: sourceType })
        // 路由跳转
        this.$router.push('/homework/arrangement/textBook/step2/' + sourceType)
      },
      changeLoading(data) {
        this.isLoading = data
      },
      back() {
        store.commit(initTextbook)
        this.$router.push('/homepage')
      },
      getBooks() {
        store.dispatch(getTextbooks)
          .then(() => {
            this.loading = false
          })
          .catch(() => {
            this.loading = false
          })
      }
    },
    created() {
      this.getBooks()
    }
  }
</script>
<style scoped>
  .textbook_conatin {
    height: calc(100% - 130px);
  }
  
  .btn {
    position: fixed;
    bottom: 0px;
  }
  
  .title {
    width: 50px;
    font-size: 12px;
    color: #666;
    margin-top: 2px;
  }

  .tips {
    font-size: 12px;
    display: block;
    width: calc(100% - 50px);
    color: #666666;
    margin-left: 8px;
    line-height: 15px;
  }
  
  .text_book {
    height: calc(100% - 45px);
    overflow: auto;
  }
  
  .nobook {
    height: calc(100% - 46px);
  }

  .is_loading {
    position: absolute;
    z-index: 500;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .limit_tip {
    font-size: 20px;
    color: #666;
    line-height: 28px;
  }
</style>
