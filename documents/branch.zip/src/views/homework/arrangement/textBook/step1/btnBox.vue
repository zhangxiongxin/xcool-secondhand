<template lang="pug">
  .btn_box
    .left
      .margin_right.margin_top 选择题 {{ countItem.choice }} 道
      .margin_right.margin_top 填空题 {{ countItem.fillin }} 道
      .margin_top 解答题 {{ countItem.solution }} 道
    .right
      button.overbtn(:disabled="!!!totalCount", @click="selectOver", :class="{'dis-btn': !!!totalCount}") 完成选题
</template>
<script>
  import { questionType } from '@/filters/doudou'

  export default {
    name: 'btnBox',
    props: ['selectQues'],
    computed: {
      countItem() {
        const data = {}
        if (Array.isArray(this.selectQues)) {
          this.selectQues.forEach((v, i) => {
            const type = questionType(v.questionType, true)
            if (!data[type]) data[type] = []
            data[type].push(v)
          })
        }
        const count = {
          choice: data.choice && data.choice.length ? data.choice.length : 0,
          fillin: data.fillin && data.fillin.length ? data.fillin.length : 0,
          solution: data.solution && data.solution.length ? data.solution.length : 0
        }
        return count
      },
      totalCount() {
        return this.countItem.choice + this.countItem.fillin + this.countItem.solution
      }
    },
    methods: {
      selectOver() {
        this.$emit('next', this.totalCount)
      }
    }
  }
</script>
<style scoped>
  .btn_box {
    display: flex;
    align-items: center;
    width: 100%;
    height: 80px;
    background: rgba(237, 242, 251, 0.69);
    box-shadow: 0 -2px 5px 0 rgba(43, 106, 168, 0.21);
    & .left {
      padding-left: 30px;
      font-size: 16px;
      color: #3399FF;
      width: calc(100% - 150px);
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 10px;
      & div {
        /*margin-bottom: 10px;*/
      }
    }
    & .right {
      width: 150px;
    }
  }
  
  .overbtn {
    border: none;
    background: #3399FF;
    box-shadow: 0 2px 6px 0 rgba(42, 106, 169, 0.56);
    border-radius: 92px;
    width: 130px;
    height: 40px;
    font-size: 20px;
    color: #FFFFFF;
  }
  
  .margin_right {
    margin-right: 11px;
  }

  .margin_top {
    margin-top: 10px;
  }

  .dis-btn {
    background: #999;
  }
</style>
