<template lang="pug">
  router-view.bg_white
</template>
<script>
  export default {
    name: 'textBookHome'
  }
</script>
<style scoped>
  .bg_white {
    background-color: #F6F6F6;
  }
</style>
