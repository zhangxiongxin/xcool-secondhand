<template lang="pug">
  div(style="padding: 0 30px;")
    .class_title 选择作业班级
    el-checkbox.name_box(v-model="saveNameList", @change="saveGroup") 保存这次学生名单组合（可保存最近3次）
    .class_box
      template(v-for="(item, index) in groupList")
        label
          span.class_name {{item.groupName}}
          input(type="checkbox", v-model="item.checked")
          img.check_img(src="~assets/imgs/ic_option_choosed.png" v-show="item.checked")
          img.check_img(src="~assets/imgs/ic_option_not_choose.png" v-show="!item.checked")
      template(v-for="(item, index) in classList")
        label
          span.class_name {{item.className}}
          input(type="checkbox", v-model="item.checked")
          img.check_img(src="~assets/imgs/ic_option_choosed.png" v-show="item.checked")
          img.check_img(src="~assets/imgs/ic_option_not_choose.png" v-show="!item.checked")
</template>
<script>
  import store from '@/store'
  import { queryBookStu } from '@/store/types'

  export default {
    name: 'classList',
    data() {
      return {
        saveNameList: true
      }
    },
    computed: {
      classList() {
        return store.state.textBook.stuData
      },
      groupList() {
        return store.state.textBook.groupData
      }
    },
    methods: {
      saveGroup() {
        this.$emit('saveGroup', this.saveNameList)
      }
    },
    created() {
      store.dispatch(queryBookStu)
    }
  }
</script>
<style scoped>
  .class_title {
    font-size: 20px;
    color: #666666;
    line-height: 28px;
    border-left: 4px solid #3399FF;
    margin-bottom: 15px;
    padding-left: 10px;
  }
  
  .class_box {
    & label {
      display: inline-block;
      width: 100%;
      margin-bottom: 20px;
      line-height: 40px;
      padding: 0px 15px 0px 52px;
      height: 40px;
      background: #3399FF;
      box-shadow: 0 2px 4px 0 rgba(34, 79, 124, 0.28);
      border-radius: 100px;
      position: relative;
      display: inline-block;
      font-size: 16px;
      color: #FFFFFF;
      & img {
        position: absolute;
        left: 20px;
        top: 9px;
      }
      & input {
        display: none;
      }
    }
  }
  
  .check_img {
    width: 22px;
  }

  .name_box {
    margin-bottom: 20px;
  }

  .class_name {
    display: inline-block;
    max-width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
<style type="text/css">
    .name_box {
    & .el-checkbox__inner {
      border: 1px solid #3399FF;
    }
    & .el-checkbox__input.is-checked .el-checkbox__inner {
      background-color: #3399FF;
      border-color: #3399FF;
    }
  }
</style>
