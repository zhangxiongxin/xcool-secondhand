<template lang="pug">
  div.container
    template(v-for="(itme, index) in bookIdList")
      .count
        p(style="margin-right: 5px") 已选择
          span {{itme.split('-')[1]}} 
        .flex
          p  单选题{{ countQuesByType(itme, 'choice') }}道   
          p  填空题{{ countQuesByType(itme, 'fillin') }}道   
          p  解答题{{ countQuesByType(itme, 'solution') }}道 
          p  （共{{ countQuesByType(itme, 'choice') + countQuesByType(itme, 'fillin') + countQuesByType(itme, 'solution') }}题） 
        .num(v-for="item in getSectionName(itme.split('-')[0])")
          p {{item}}
          p {{getNumInPaper(itme.split('-')[0], item)}}
</template>
<script>
  import { questionType } from '@/filters/doudou'

  export default {
    name: 'countBook',
    props: ['selectQues'],
    data() {
      return {}
    },
    methods: {
      // 获取节名称
      getSectionName(bookId) {
        let obj = this.formatBySectionName[bookId]
        return Object.keys(obj)
      },
      // 获取节下面numInPaper
      getNumInPaper(bookId, sectionName) {
        return this.formatBySectionName[bookId][sectionName].join('、')
      },
      formatArr(arry = []) {
        const data = {}
        if (Array.isArray(arry)) {
          arry.forEach((v, i) => {
            // 题型分类
            const type = questionType(v.questionType, true)
            if (!data[type]) data[type] = []
            data[type].push(v)
          })
        }
        return data
      },
      formatSection(arry = []) {
        const data = {}
        if (Array.isArray(arry)) {
          arry.forEach((v, i) => {
            let sectionArry = v.sectionArry.concat()
            sectionArry.shift()
            const sectionName = sectionArry.join(' ')
            if (!data[sectionName]) data[sectionName] = []
            data[sectionName].push(v.numInPaper)
          })
        }
        return data
      },
      countQuesByType(name, type) {
        return this.formatByType[name] && this.formatByType[name][type] && this.formatByType[name][type].length ? this.formatByType[name][type].length : 0
      }
    },
    computed: {
      // 按bookId bookName分类,防止教辅重名情况
      formatByName() {
        const data = {}
        if (Array.isArray(this.selectQues)) {
          this.selectQues.forEach((v, i) => {
            const type = v.bookId + '-' + v.sectionArry[0]
            if (!data[type]) data[type] = []
            data[type].push(v)
          })
        }
        return data
      },
      // 按bookId bookName分类后 按题型分类
      formatByType() {
        let keys = Object.keys(this.formatByName)
        const data = this.formatByName
        keys.forEach(v => {
          let questions = data[v]
          data[v] = this.formatArr(questions)
        })
        return data
      },
      // 按bookId分类
      formatByBookId() {
        const data = {}
        if (Array.isArray(this.selectQues)) {
          this.selectQues.forEach((v, i) => {
            const type = v.bookId
            if (!data[type]) data[type] = []
            data[type].push(v)
          })
        }
        return data
      },
      // 按节名分类
      formatBySectionName() {
        let keys = Object.keys(this.formatByBookId)
        const data = this.formatByBookId
        keys.forEach(v => {
          let questions = data[v]
          data[v] = this.formatSection(questions)
        })
        return data
      },
      // 书名 id list
      bookIdList() {
        return Object.keys(this.formatByType)
      }
    }
  }
</script>
<style scoped>
  .container {
    font-size: 16px;
    color: #666666;
    line-height: 24px;
    padding: 0 30px;
  }

  .flex {
    display: flex;
    flex-wrap: wrap;
    & p {
      margin-right: 8px;
    }
  }

  .num {
    margin-top: 8px;
    & p:nth-of-type(2) {
      margin-top: 5px;
    }
  }

  .count {
    margin-bottom: 20px;
  }
</style>
