<template lang="pug">
  div.method_box
    .name_title 选择上传方式
    el-radio-group.method_group(v-model="method", @change="selectMethod")
      el-radio(:label="0") 学生APP拍照上传
      el-radio(:label="1") 老师PC扫描上传
</template>
<script>
  export default {
    name: 'uploadMethod',
    data() {
      return {
        method: null
      }
    },
    methods: {
      selectMethod() {
        this.$emit('selectMethod', this.method)
      }
    }
  }
</script>
<style scoped>
  .method_box {
    width: 100%;
  }

  .name_title {
    font-size: 20px;
    color: #666666;
    line-height: 28px;
    padding-left: 10px;
    border-left: 4px solid #3399FF;
    margin: 0px 0px 10px 30px;
  }

  .method_group {
    width: 100%;
    height: 95px;
    padding: 12px 45px;
    border-color: #D2D2D2;
    border-style: solid;
    border-width: 1px 0px 1px 0px;
    background: #FFFFFF;
  }
</style>
<style type="text/css">
  .method_group {
    & .el-radio__label {
      font-size: 18px;
      color: #666666;
    }
    & .el-radio+.el-radio {
      margin-left: 0px;
      margin-top: 20px;
    }
    & .el-radio__input.is-checked .el-radio__inner {
      border-color: #3399FF;
      background: #3399FF;
    }
  }
</style>
