<template lang="pug">
  transition(name="fade")
    .bg_contain
      .warning_contain
        slot(name="body")
        .return_btn(@click="goback") 知道了
</template>
<script>
  export default {
    name: 'warningBox',
    data() {
      return {}
    },
    methods: {
      goback() {
        this.$emit('goback')
      }
    }
  }
</script>
<style scoped>
  .fade-enter-active,
  .fade-leave-active {
    transition: all .2s linear;
    transform: translate3D(0, 0, 0);
  }
  
  .fade-enter,
  .fade-leave-active {
    transform: translate3D(100%, 100%, 100%);
  }
  
  .bg_contain {
    position: fixed;
    top: 0px;
    left: 0px;
    z-index: 2000;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
  }
  
  .warning_contain {
    line-height: 28px;
    font-size: 20px;
    background: #FFFFFF;
    border-radius: 6px;
    width: 67%;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    padding: 20px 25px 80px 25px;
    & .return_btn {
      position: absolute;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      cursor: pointer;
      text-align: center;
      color: #fff;
      font-size: 16px;
      width: 150px;
      height: 42px;
      line-height: 42px;
      background: #3399FF;
      border-radius: 78px;
      box-shadow: 0 2px 6px 0 rgba(27,78,129,0.43);
      &:hover {
        background: #FFCC66;
      }
    }
  }
</style>
