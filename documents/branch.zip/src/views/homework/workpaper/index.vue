<template lang='pug'>
  //- 作业报告页面
  div
    loading(:show="loading", :text="loadingText")
    x-header.paper_header(:left-options="{ backText: '返回' }") 班级{{reportType === 'training' ? '考试' : '作业'}}报告

    div.big_container
      div.worktime
        //- paperSet 普通  book 教辅  training 考试
        img(v-show="reportType==='book'", src='~assets/imgs/workpaper/icon_coach.png') 
        img(v-show="reportType==='training'" src='~assets/imgs/kaoshi.png')
        img(v-show="reportType==='vacation'" src='~assets/imgs/assignment/ico.hanjiatubiao@4x.png')  
        span.report_title {{examName}}
      p.pick_class(@click='changeTrue', :class="{ single_class: classNum < 2 }")
        span(v-model='classOption')  {{classOption}}
      p.black_shadow
      div.pick_class_pupop
        popup(v-model='show_radio' position='bottom')
          group.pick_cell
            p.placeholder_radio 选择您想查看报告的班级
            cell(v-for='i in classList', :key='i.classId', :title='i.className' @click.native='changeClass($event,i)')
          div
            x-button(@click.native='show_radio = false' plain type='primary') 取消
      button-tab.tab_box( v-model='tab_index')
        button-tab-item 
          span 班级{{reportType === 'training' ? '考试' : '作业'}}分析
        button-tab-item
          span {{reportType === 'training' ? '成绩单' : '学生作业情况'}}
      work-analysis(v-show='tab_index === 0 && !loading', :reportType="reportType", :errorSpreads="errorSpreads", :scoreSpreads="scoreSpreads", :loreIcons="loreIcons", :classId='classOptionId', :examId='examId', :needAttention="needAttention", :potentialList="potentialList")
      taskCondition(v-show='tab_index === 1 && !loading', :reportType="reportType", :scoresheetLists="scoresheetLists")
      div.little_shadow(:class="{not_show: loading }")
      div.catalog.toTop(v-if="scrollTopPx", :class="{move_bottom: tab_index === 1 }", @click='toTop')
        img(src="~assets/imgs/workpaper/back_top.png")
        span 回顶部
      div.catalog(v-if="tab_index === 0 ", v-model='catalog' @click='openCatalog') 
        span 目录
    div
      popup(v-model="catalog", position="right")
        div.catalog_detail
          p 目录
          ul#catalog_content
            li(v-for='(item,index) in headers', :key="index", v-model="headers[index]", @click="changeCatalog(item.index)") {{item.value}}
</template>
<script>
  import HomeworkService from '@/services/homework'
  import workAnalysis from './workAnalysis'
  import taskCondition from './taskCondition'
  import store from '@/store'
  export default {
    name: 'workpaper',
    data() {
      return {
        examId: this.$route.params.examId,
        reportType: this.$route.params.reportType,
        examName: this.$route.params.examName,
        classOption: '',
        classOptionId: '',
        classList: [],
        headers: [],
        tab_index: 0,
        show_radio: false,
        catalog: false,
        classNum: 0,
        scoresheetLists: null,
        errorSpreads: { averageAccuracy: 0.0 },
        scoreSpreads: { averageScore: 0, isFirstFlag: false, befAverageScore: 0, befTotalScore: 0, befScoreIndex: { excellent: 0, good: 0, average: 0, poor: 0 }, scoreList: [] },
        loreIcons: {},
        needAttention: { unSubmit: [], top10List: [], biggestProgress: [], biggestRetrogression: [] },
        potentialList: {},
        source: 3,
        loading: true,
        loadingText: '玩命加载中',
        scrollTopPx: 0
      }
    },
    components: { workAnalysis, taskCondition },
    created() {
      if (this.reportType === 'paperSet') {
        this.source = 0
      } else if (this.reportType === 'book' || this.reportType === 'vacation') {
        this.source = 1
      } else {
        this.source = 3
      }
      this.init()
    },
    mounted() {
      document.addEventListener('scroll', this.listenTop)
      this.timer = setInterval(() => {
        this.catelogTitle()
      }, 1000)
    },
    destroy() {
      clearInterval(this.timer)
    },
    methods: {
      // 点击流推送
      pushEvent() {
        if (this.reportType === 'training') {
          this.$event({classId: this.classOptionId, examId: this.examId, operationType: 'lookClassReport', sourceType: 'training'})
        } else {
          this.$event({classId: this.classOptionId, examId: this.examId, operationType: 'lookClassReport', sourceType: 'exerhome'})
        }
      },
      // 改变班级操作
      changeClass(event, i) {
        this.classOption = i.className
        this.classOptionId = i.classId
        this.init()
        this.headers = []
        this.scoresheetLists = null
        this.tab_index = 0
        this.show_radio = false
      },
      realClass(classList) {
        let newClass = []
        classList.forEach((element, index) => {
          if (element.haveReview) {
            newClass.push(element)
          }
        })
        if (!this.classOptionId) {
          this.classOption = newClass[0].className
          this.classOptionId = newClass[0].classId
        }
        return newClass
      },
      listenTop() {
        this.scrollTopPx = window.scrollTop || document.scrollTop || document.documentElement.scrollTop || document.body.scrollTop || 0
      },
      catelogTitle() {
        let result = []
        let headlist = document.getElementsByClassName('head')
        for (let i = 0; i < headlist.length; i++) {
          result.push({ index: i, value: headlist[i].childNodes[0].innerText })
        }
        if (!this.headers || this.headers.length !== result.length) {
          this.headers = result
        }
      },
      toTop() {
        window.scrollTop = document.scrollTop = document.documentElement.scrollTop = document.body.scrollTop = 0
      },
      changeCatalog(key) {
        let headlist = document.getElementsByClassName('head')
        let pos = headlist[key].getBoundingClientRect().top
        this.catalog = false
        setTimeout(() => {
          window.scrollTop = document.scrollTop = document.documentElement.scrollTop = document.body.scrollTop = pos - 45
        }, 400)
      },
      changeTrue() {
        this.show_radio = true
      },
      openCatalog() {
        this.catalog = true
      },
      // 初始化或者改变班级时调用的方法
      init() {
        // 获取班级列表
        HomeworkService
          .homeworkClassList({ examId: this.examId, teacherId: store.getters.teacherId })
          .then(res => {
            this.classList = this.realClass(res.data)
            this.classNum = this.classList.length
            this.pushEvent()
          })
          .catch((reason) => {
          })
          .then(() => {
            if (this.reportType === 'training') {
              // 获取成绩分布
              HomeworkService
                .getScoreSpread({ classId: this.classOptionId, examId: this.examId })
                .then(res => {
                  this.scoreSpreads = res.data
                })
                .catch((reason) => {
                })
            }
          })
          .then(() => {
            // 获取需要关注数据
            if (this.reportType !== 'training') {
              HomeworkService
                .needAttention({ classId: this.classOptionId, examId: this.examId, type: 1 })
                .then(res => {
                  this.needAttention = res.data
                })
                .catch((reason) => {
                })
            } else {
              HomeworkService
                .needAttention({ classId: this.classOptionId, examId: this.examId, type: 2 })
                .then(res => {
                  this.needAttention = res.data
                })
                .catch((reason) => {
                })
            }
          })
          .then(() => {
            // 获取错题分布
            if (this.reportType !== 'training') {
              HomeworkService
                .getErrorSpread({ classId: this.classOptionId, examId: this.examId, source: this.source })
                .then(res => {
                  this.errorSpreads = res.data
                })
                .catch((reason) => {
                })
            } else {
              HomeworkService
                .getWeekErrorSpread({ classId: this.classOptionId, examId: this.examId })
                .then(res => {
                  this.errorSpreads = res.data
                })
                .catch((reason) => {
                })
            }
          })
          .then(() => {
            // 提分潜力榜
            HomeworkService
              .potentialList({ classId: this.classOptionId, examId: this.examId })
              .then(res => {
                this.potentialList = res.data
              })
              .catch((reason) => {
              })
          })
          .then(() => {
            // 获取知识点
            if (this.reportType !== 'training') {
              HomeworkService
                .getLoreIcon({ classId: this.classOptionId, examId: this.examId, source: this.source })
                .then(res => {
                  this.loreIcons = res.data
                })
                .catch((reason) => {
                })
            } else {
              HomeworkService
                .getWeekLoreIcon({ classId: this.classOptionId, examId: this.examId, type: 2 })
                .then(res => {
                  this.loreIcons = res.data
                })
                .catch((reason) => {
                })
            }
            this.loading = false
          })
      }
    },
    watch: {
      tab_index: {
        handler: function(val, oldVal) {
          if (this.tab_index === 1 && this.reportType !== 'training' && this.scoresheetLists === null) {
            this.loading = true
            HomeworkService
              .getScoresheetList({ classId: this.classOptionId, examId: this.examId, source: this.source })
              .then(res => {
                this.loading = false
                this.scoresheetLists = res.data
              })
              .catch((reason) => {
                this.loading = false
              })
          } else if (this.tab_index === 1 && this.reportType === 'training' && this.scoresheetLists === null) {
            this.loading = true
            HomeworkService
              .getWeekScoresheetList({ classId: this.classOptionId, examId: this.examId })
              .then(res => {
                this.loading = false
                this.scoresheetLists = res.data
              })
              .catch((reason) => {
                this.loading = false
              })
          }
        }
      }
    }
  }
</script>
<style scoped>
  .vux-header {
    z-index: 666;
    position: fixed;
    background: #3399FF;
  }
  
  .worktime img {
    vertical-align: middle;
    width: 25px;
    margin-right: 5px;
  }
  
  .tab_box {
    width: 96%;
    margin-left: 2%;
  }
  
  .worktime {
    text-align: center;
    font-size: 18px;
    line-height: 44px;
    height: 44px;
  }
  
  .report_title {
    vertical-align: middle;
    font-size: 18px;
    max-width: 80%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    display: inline-block;
    margin: 0 auto;
  }
  
  .choose_placeholder {
    height: 45px;
    text-align: center;
    padding-top: 11px;
    font-size: 13px;
    color: #8F8E94;
    letter-spacing: -0.08px;
  }
  
  .not_show {
    display: none;
  }
  
  .vux-button-group > a.vux-button-group-current {
    background: #fff;
  }
  
  .vux-button-group > a.vux-button-tab-item-first:after,
  .vux-button-group > a.vux-button-tab-item-last:after {
    border: 0px;
  }
  
  .vux-button-group > a.vux-button-tab-item-first>span {
    border-radius: 4px 0px 0px 4px;
  }
  
  .vux-button-group > a.vux-button-tab-item-last>span {
    border-radius: 0px 4px 4px 0px;
  }
  
  .vux-button-group-current span {
    background: #3399FF;
  }
  
  .vux-button-tab-item span {
    border: 1px solid #3399FF;
    display: inline-block;
    width: 100%;
  }
  
  .vux-button-tab-item {
    padding-top: 10px;
  }
  
  .vux-header .vux-header-left .vux-header-back {
    padding-left: 17px;
  }
  
  .pick_class_pupop .vux-popup-dialog {
    background: transparent;
    width: 96%;
    margin-left: 2%;
  }
  
  .placeholder_radio {
    font-size: 13px;
    line-height: 45px;
    color: #8F8E94;
    letter-spacing: -0.08px;
    text-align: center;
  }
  
  .pick_class {
    border-top: 1px solid #D4DDEE;
    position: relative;
    text-align: center;
    background: #ECF2FC;
    width: 100%;
  }
  
  .pick_class span {
    display: inline-block;
    font-size: 18px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    margin-top: 16px;
    margin-bottom: 13px;
    position: relative;
  }
  
  .pick_class span:after {
    position: absolute;
    left: 102%;
    margin-top: -13px;
    content: '';
    border-radius: 4px;
    display: block;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 10px;
    border-color: #4F9AFB transparent transparent transparent;
  }
  
  .single_class span:after {
    display: none;
  }
  
  .black_shadow {
    width: 100%;
    height: 10px;
    background: #ECF2FC;
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
  }
  
  .little_shadow {
    background-color: #ECF2FC;
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    width: 100%;
    height: 30px;
  }
  
  .catalog {
    text-align: center;
    padding-top: 16px;
    box-shadow: 0px 0px 6px 0px #21578D;
    background: rgba(51, 153, 255, 0.70);
    position:fixed;
    width: 60px;
    height: 60px;
    border-radius: 60px;
    right: 14px;
    bottom: 16px;
    border: 0px;
  }
  
  .catalog>span {
    line-height: 24px;
    text-align: center;
    margin: 0 auto;
    white-space: nowrap;
    width: 100%;
    font-size: 14px;
    color: #FFFFFF;
  }
  
  .toTop {
    bottom: 89px;
  }
  
  .toTop img {
    height: 8.8px;
    display: block;
    margin: 0 auto;
  }
  
  .catalog_detail {
    padding-left: 20px;
    height: 100%;
    padding-top: 60px;
    width: 200px;
    background: #fff;
  }
  
  .catalog_detail>p {
    font-size: 24px;
    color: #666666;
    letter-spacing: 0;
    padding-bottom: 29px;
  }
  
  .catalog_detail>ul>li {
    font-size: 18px;
    color: #666666;
    letter-spacing: 0;
    height: 43px;
    padding-top: 14px;
    border-bottom: 1px solid #90C2F4;
  }
  
  .catalog_detail>ul>li:after {
    content: '';
    width: 50px;
    height: 4px;
    background-color: #90C2F4;
    display: block;
    margin-top: 10px;
  }
  
  .big_container {
    padding-top: 46px;
    height: calc(100% - 46px);
  }
  
  .move_bottom {
    bottom: 16px;
  }
  
  .paper_header>.vux-header-title {
    font-size: 20px;
  }
  
  .paper_header {
    width: 100%;
  }
  
  .paper_header>.vux-header-left>.vux-header-back {
    font-size: 17px;
    margin-top: -2px;
  }
  
  .paper_header .vux-header-left {
    color: #FFFFFF;
  }
  
  .paper_header .vux-header-left a,
  .vux-header-left>.left-arrow:before {
    color: #FFFFFF;
  }
  
  .paper_header .vux-header-left .left-arrow:before {
    border: 1px solid #FFFFFF;
    border-width: 2px 0 0 2px;
  }
  
  .pick_class_pupop button {
    font-size: 20px;
    color: #3399FF;
    letter-spacing: 0.38px;
    background: #FFFFFF;
    border-radius: 12px;
    margin-top: 10px;
    margin-bottom: 10px;
    border: 0px solid #1aad19;
  }
</style>
<style type="text/css">
  .pick_class_pupop label {
    text-align: center;
    font-size: 20px;
    color: #3399FF;
    letter-spacing: 0.38px;
  }
  
  .pick_cell>.weui-cells {
    border-radius: 12px;
  }
  
  .pick_cell>.weui-cells .weui-cell:before {
    left: 0px;
  }
</style>
