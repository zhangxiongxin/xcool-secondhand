<template lang="pug">
  //- 学生作业情况组件
  div.container(v-if="scoresheetLists")
    div.analysis
      p 本班本次作业共 {{scoresheetLists.totalStudent >=0 ? scoresheetLists.totalStudent : scoresheetLists.totalCount}} 人
      p 已上传成功 {{scoresheetLists.uploadStudent >=0 ? scoresheetLists.uploadStudent : scoresheetLists.uploadCount}} 人
      p 已批阅完成 {{scoresheetLists.done >=0 ? scoresheetLists.done : scoresheetLists.markCount}} 人
    stu-list(:reportType="reportType", :studentLists="scoresheetLists.studentList || scoresheetLists.studentScoreList")
</template>
<script>
  import stuList from './stuList'
  export default {
    name: 'taskCondition',
    props: ['scoresheetLists', 'reportType'],
    data() {
      return {
      }
    },
    components: { stuList }
  }
</script>
<style scoped>
  .analysis {
    margin-bottom: 20px;
    width: 96%;
    background: #EDF2FB;
    border-radius: 4px;
    margin-top: 35px;
    margin-left: 2%;
    font-size: 16px;
    color: #3479D2;
    letter-spacing: -0.1px;
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .analysis p{
    padding-left: 20px;
    font-size: 16px;
    color: #3479D2;
    letter-spacing: -0.1px;
    line-height: 22px;
  }
</style>
