<template lang="pug">
  //- 学生作业情况列表
  div.all_stu
    div.single_box(v-for='(item,index) in studentLists', :key='index') 
      div.single_stu 
        div.single_detail 
          p 
            span(style="max-width:165px;width:auto;padding-right:5px;") {{item.studentName}}
            button.already_up(v-if="item.status > 1 ") 已提交
            button.already_read(v-if="item.status === 4 ") 已批阅
            button.wait_read(v-if="item.status === 2 ") 待批阅
            button.read_ing(v-if="item.status === 3 ") 批阅中
            button.ever_up(v-if="item.status <= 1 ") 未提交
          p(v-if="reportType === 'training' && item.status === 4 ") 
            span 得分：
            span {{item.score}}
          p(v-if="reportType === 'training' && item.status === 4 ") 
            span 排名：
            span {{item.scoreRank}}
          p(v-if="item.status === 4 && reportType !=='training' ") 
            span 正确率：
            span {{item.accuracy | rateFilter}}
          p(v-if="item.status === 4 ") 
            span 答对题数：
            span  {{ item.rightCount >= 0 ? item.rightCount : showRight(item.totalQuestioNumber,item.wrongCount)}}
          p(v-if="item.status === 4 ") 
            span 答错题数： 
            span {{item.wrongCount}}
          p(v-if="item.wrongCount !== 0 && item.status === 4 ")
            span 答错题目： 
            span(v-html="showwrongQuestionNum(item.choiceQuestionNumber, item.fillInQuestionNumber, item.solutionQuestionNumber, item.wrongQuestionNum)", style="width: calc(100% - 70px);")
          p(v-if="item.status > 1 ")
            span 提交顺序：
            span {{item.submitRank}}
          p(v-if="item.status > 1 ") 
            span 提交时间：
            span {{item.submitTime | date}}
</template>
<script>
  export default {
    name: 'stuList',
    props: ['studentLists', 'reportType'],
    data() {
      return {}
    },
    methods: {
      showRight: function(totalQuestioNumber, wrongCount) {
        return totalQuestioNumber - wrongCount
      },
      showwrongQuestionNum: function(choiceQuestionNumber, fillInQuestionNumber, solutionQuestionNumberm, wrongQuestionNum) {
        let str = ''
        if (this.reportType === 'book' || this.reportType === 'vacation') {
          return wrongQuestionNum.split('#%#').join('<br/>')
        } else {
          if (choiceQuestionNumber) {
            str += '选择题 ' + choiceQuestionNumber + '<br/>'
          }
          if (fillInQuestionNumber) {
            str += '填空题 ' + fillInQuestionNumber + '<br/>'
          }
          if (solutionQuestionNumberm) {
            str += '解答题 ' + solutionQuestionNumberm
          }
          return str
        }
      }
    },
    computed: {}
  }
</script>
<style scoped>
  .all_stu {
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    margin-bottom: 30px;
    padding-top: 20px;
    background: #ECF2FC;
  }
  
  .single_box {
    padding-top: 20px;
    width: 100%;
    background: #fff;
  }
  
  .single_stu {
    border-radius: 4px;
    width: 95%;
    margin: 0 auto;
    background: #FFFFFF;
    border: 1px solid #3399FF;
    border-left: 10px solid #3399FF;
  }
  
  .single_detail {
    margin-bottom: 10px;
    position: relative;
    padding-left: 20px;
  }
  
  .single_detail>p:first-child {
    font-size: 20px;
    color: #333333;
    letter-spacing: -0.09px;
    padding-bottom: 10px;
    padding-top: 10px;
  }
  
  .single_detail p {
    line-height: 22px;
    font-size: 14px;
    color: #666666;
    letter-spacing: -0.09px;
    display: flex;
  }
  
  .single_detail>p>span:first-child {
    width: 70px;
  }
  
  .single_detail>p>p {
    display: inline-block;
  }
  
  .single_detail button {
    vertical-align: middle;
    padding: 0px 0px;
    width: 60px;
    line-height: 21px;
    font-size: 14px;
    color: #FFFFFF;
    letter-spacing: -0.06px;
    border: 0px;
    height: 21px;
    border-radius: 4px;
    margin-right: 10px;
  }
  
  .single_detail button:first-child {
    margin-left: 20px;
  }
  
  .single_detail>p>span:not(:first-child) {
    display: block;
  }
  
  .already_up {
    background: #3399FF;
  }
  
  .already_read {
    background: #77B830;
  }
  
  .wait_read {
    background: #BF722A;
  }
  
  .read_ing {
    background: #C38924;
    color: #C38924;
  }
  
  .ever_up {
    background: #FF6B6B;
  }
</style>
