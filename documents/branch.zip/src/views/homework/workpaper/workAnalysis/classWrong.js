export default function classWrong(data, reportType) {
  // 处理错题分布数据
  const res = []
  data.forEach((v, i) => {
    res.push({
      questionId: v.questionId,
      subQuestionId: v.subQuestionId,
      questionType: (function() {
        if (!v.questionType) {
          return '默认题型'
        } else if (v.questionType.toLowerCase() === 'choice') {
          return '单选题：'
        } else if (v.questionType.toLowerCase() === 'fill_in' || v.questionType.toLowerCase() === 'fillIn' || v.questionType.toLowerCase() === 'fillin') {
          return '填空题：'
        } else if (v.questionType.toLowerCase() === 'solution') {
          return '解答题：'
        }
      })(),
      numInPaper: v.numInPaper,
      typeNumInPaper: (function() {
        if (reportType === 'book' || !v.questionType || reportType === 'vacation') {
          return v.numInPaper
        } else {
          if (v.questionType.toLowerCase() === 'choice') {
            return '单选题：' + v.numInPaper
          } else if (v.questionType.toLowerCase() === 'fill_in' || v.questionType.toLowerCase() === 'fillIn' || v.questionType.toLowerCase() === 'fillin') {
            return '填空题：' + v.numInPaper
          } else if (v.questionType.toLowerCase() === 'solution') {
            return '解答题：' + v.numInPaper
          }
        }
      })(),
      errorPersonCount: v.errorPersonCount,
      correctRate: (function() {
        let correct = v.correctRate >= 0 ? v.correctRate : v.scoreRate
        const str = (correct * 100) + ''
        return Math.round(str) + '%'
      })(),
      sectionName: (function() {
        if (v.sectionName == null) {
          return ''
        } else {
          let partName = v.sectionName.split('#%#')
          return partName[partName.length - 1]
        }
      })(),
      studentInfoList: v.studentInfoList || v.studentWrongList,
      studentNameList: (function() {
        let arr = []
        let studentInfoList = v.studentInfoList || v.studentWrongList
        studentInfoList.forEach(s => {
          arr.push(s.studentName)
        })
        return arr.join('、')
      })(),
      rightStuInfoList: v.studentInfoList || v.studentRightList,
      errStuId: (function() {
        let arr = []
        let studentInfoList = v.studentInfoList || v.studentWrongList
        studentInfoList.forEach(s => {
          arr.push(s.studentId)
        })
        return arr.join(',')
      })()
    })
  })
  return res
}
