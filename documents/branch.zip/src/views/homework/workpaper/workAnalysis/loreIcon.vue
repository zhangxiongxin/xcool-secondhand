<template lang="pug">
  //- 四级知识点组件
  div.head(v-if="knowledgeList && knowledgeList[0]")
    div.lore_head 四级知识点
    div.lore_detail 
      div.single_lore(v-for='(item,index) in knowledgeList', :key='index') 
        span
          span.lore_name {{item.knowledgePointName}}
        div.single_detail
          div.icon_block1 
            p {{countRight(item.rightCount,item.totalCount)}}
            p 正确率
          div.icon_block2 
            p {{item.totalCount}}
            p 出现人次
          div.icon_block3 
            p {{item.rightCount}}
            p 正确人次
        p.lore_sub 含该知识点的题目
        p.lore_sub_content(v-if="item.knowledgeRealtionVo[0]") {{handleKnowledge(item.knowledgeRealtionVo)}}
        p.lore_sub_content(v-else) 无

</template>
<script>
  export default {
    name: 'loreIcon',
    props: ['knowledgeList'],
    data() {
      return {}
    },
    methods: {
      countRight(rightCount, totalCount) {
        let rightPercent = rightCount / totalCount
        let str = Number(rightPercent * 100).toFixed(0)
        str += '%'
        return str
      },
      handleKnowledge(data) {
        if (!Array.isArray(data)) return data
        let arr = [].concat(data)
        let text = ''
        arr.forEach((item) => {
          let singleText = ''
          if (item.sectionName) {
            let partName = item.sectionName.split('#%#')
            singleText += partName[partName.length - 1] + '：'
          } else {
            if (item.type.toLowerCase() === 'choice') {
              singleText += '选择题：'
            } else if (item.type.toLowerCase() === 'fill_in' || item.type.toLowerCase() === 'fillIn' || item.type.toLowerCase() === 'fillin') {
              singleText += '填空题：'
            } else if (item.type.toLowerCase() === 'solution') {
              singleText += '解答题：'
            }
          }
          item.questionNum.forEach((subItem) => {
            singleText += subItem.numInPaper + '、'
          })
          singleText = singleText.substring(0, singleText.length - 1) + '；'
          text += singleText
        })
        text = text.substring(0, text.length - 1)
        return text
      }
    }
  }
</script>
<style scoped>
  .icon_block1 {
    background: #FFEEDE;
  }
  
  .icon_block2 {
    background: #EEF9E3;
  }
  
  .icon_block3 {
    background: #ECF2FC;
  }
  
  .icon_block1 p {
    color: #C7803F;
  }
  
  .icon_block2 p {
    color: #8DC451;
  }
  
  .icon_block3 p {
    color: #3479D2;
  }
  
  .single_detail>div {
    border-radius: 1px;
    width: 110px;
    height: 72px;
    padding-top: 15px;
  }
  
  .single_detail>div:nth-child(2) {
    margin-left: 10px;
    margin-right: 10px;
  }
  
  .single_detail>div p {
    line-height: 20px;
    text-align: center;
    letter-spacing: -0.08px;
  }
  
  .single_detail>div p:first-child {
    font-size: 18px;
  }
  
  .single_detail>div p:nth-child(2) {
    font-size: 14px;
  }
  
  .single_detail {
    margin-left: 10px;
    margin-right: 10px;
    padding-top: 5px;
    display: flex;
    margin-top: -32px;
    justify-content: space-between;
    border-bottom: 1px solid #ECF2FC;
    padding-bottom: 12px;
  }
  
  .single_lore>span {
    display: inline-block;
    position: relative;
    left: 15px;
    top: -32px;
    max-width: 88%;
  }
  
  .single_lore .lore_name {
    padding-right: 10px;
    padding-left: 10px;
    line-height: 26px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    font-size: 18px;
    color: #333333;
    letter-spacing: -0.08px;
    background: white;
  }
  
  .lore_sub {
    font-size: 14px;
    color: #333333;
    letter-spacing: -0.34px;
    line-height: 33px;
    padding-left: 10px;
  }
  
  .lore_sub_content {
    line-height: 30px;
    padding-left: 10px;
    font-size: 16px;
    color: #666666;
    line-height: 20px;
  }
  
  .head {
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    width: 100%;
    background-color: #ECF2FC;
    padding-top: 10px;
  }
  
  .lore_head {
    position: relative;
    background: url('~assets/imgs/workpaper/lore_head.png') no-repeat;
    width: 163.30px;
    height: 55px;
    background-size: 163.30px 55px;
    text-align: center;
    font-size: 17px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    padding-left: 25px;
    padding-top: 18px;
  }
  
  .lore_detail {
    margin-top: -35px;
    padding-top: 25px;
    background: #fff;
    width: 100%;
  }
  
  .single_lore {
    position: relative;
    padding-bottom: 18px;
    padding-top: 18px;
    width: 96%;
    margin-left: 2%;
    border: 1px solid #ECF2FC;
    margin-bottom: 20px;
    margin-top: 35px;
  }
</style>
