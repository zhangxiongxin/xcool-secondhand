export default function handleImproveData(data) {
  if (!(Array.isArray(data) && data.length)) return data
  let arr = [].concat(data)
  arr.forEach((item) => {
    let text = []
    if (!item.resultQuestionVos) item.resultQuestionVos = []
    item.resultQuestionVos.forEach((subItem) => {
      if (subItem[0].sectionName) {
        text.push(getText('sectionName', subItem))
      } else {
        subItem.typeText = getType(subItem[0].questionType)
        text.push(getText(subItem.typeText, subItem))
      }
    })
    item.questionNumText = text
  })
  arr = arr.sort((a, b) => {
    var c = a.idealIndex - a.actualIndex
    var d = b.idealIndex - b.actualIndex
    return d - c
  })
  return arr
}

function getText(type, item) {
  let questionNums = []
  item.map(subItem => {
    if (subItem.numInPaper) {
      questionNums.push(subItem.numInPaper)
    }
  })
  if (type === 'sectionName') {
    let textStart = item[0].sectionName.split('#%#')
    let text = textStart[textStart.length - 1]
    return `${text}：${questionNums.join('、 ')}`
  }
  if (type.length > 2) return `${type}：${questionNums.join('、 ')}`
  else return `${type}：${questionNums.join('、 ')}`
}

function getType(questionType) {
  if (questionType.toLowerCase() === 'choice') {
    return '单选题'
  } else if (questionType.toLowerCase() === 'fill_in' || questionType.toLowerCase() === 'fillIn' || questionType.toLowerCase() === 'fillin') {
    return '填空题'
  } else if (questionType.toLowerCase() === 'solution') {
    return '解答题'
  }
}
