<template lang="pug">
  //- 切换卡1  班级作业分析页面
  div.container
    div.analysis_train(v-if="reportType=== 'training' ")
      p
        span.detail 班级平均分 (总分 {{scoreSpreads.scoreList[0] ? scoreSpreads.scoreList[0].totalScore : 150}} 分)
      p.a_count {{scoreSpreads.averageScore.toFixed(1)}} 分
      p.train_average(v-if="!scoreSpreads.isFirstFlag")  上次考试平均分 {{scoreSpreads.befAverageScore.toFixed(1)}}分 (总分 {{scoreSpreads.befTotalScore}} 分)
    div.analysis_head(v-if="reportType !== 'training' ")
      div.analysis
        p 班级平均正确率
        p.a_count {{countPercent(errorSpreads.averageAccuracy)}}
        p(v-if="!errorSpreads.isFirstFlag")
          span.analysis_detail {{showGeneral}}
          span.detail_img(:class="{up: errorSpreads.increaseAccuracy > 0, down:errorSpreads.increaseAccuracy < 0, flat:errorSpreads.increaseAccuracy === 0}")
    p 当前已有 {{reportType=== 'training' ? scoreSpreads.done :  errorSpreads.done}} 位同学的{{reportType === 'training' ? '考试' : '作业'}}批阅完成进入本次统计
    score-spread(v-if="reportType=== 'training' && scoreSpreads && scoreSpreads.scoreList[0]", :handleScore="formatedData", :scoreSpreads="scoreSpreads")
    need-attention(v-if="needAttention", :reportType="reportType", :needAttention="needAttention")
    error-spread(v-if="errorSpreads", :reportType="reportType", :handleError="manipuData", :classId='classId', :examId='examId')
    potential-list(v-if="potentialList.scoreRankItemList && potentialList.scoreRankItemList[0]", :reportType="reportType", :scoreRankItemList="potentialData")
    lore-icon(:knowledgeList="loreIcons")
</template>
<script>
  import classWrong from './classWrong'
  import classGrade from './classGrade'
  import classPotentialList from './classPotentialList'
  import scoreSpread from './scoreSpread'
  import errorSpread from './errorSpread'
  import loreIcon from './loreIcon'
  import needAttention from './needAttention'
  import potentialList from './potentialList'

  export default {
    name: 'workAnalysis',
    props: ['reportType', 'errorSpreads', 'scoreSpreads', 'loreIcons', 'classId', 'examId', 'needAttention', 'potentialList'],
    data() {
      return {}
    },
    components: { scoreSpread, errorSpread, loreIcon, needAttention, potentialList },
    computed: {
      showGeneral: function() {
        if (this.errorSpreads.increaseAccuracy > 0) {
          return '比上次作业上升' + this.countPercent(this.errorSpreads.increaseAccuracy)
        } else if (this.errorSpreads.increaseAccuracy === 0) {
          return '与上次作业持平'
        } else if (this.errorSpreads.increaseAccuracy < 0) {
          return '比上次作业下降' + this.countPercent(this.errorSpreads.increaseAccuracy)
        }
      },
      formatedData: function() {
        if (this.scoreSpreads.scoreList && this.scoreSpreads.scoreList[0]) {
          return classGrade(this.scoreSpreads)
        } else {
          return
        }
      },
      manipuData: function() {
        let wrongQuestionList = this.errorSpreads.wrongQuestionList || this.errorSpreads.paperWrongQuestionList
        if (wrongQuestionList && wrongQuestionList[0]) {
          return classWrong(wrongQuestionList, this.reportType)
        } else {
          return
        }
      },
      potentialData: function() {
        let scoreRankItemList = this.potentialList && this.potentialList.scoreRankItemList
        if (scoreRankItemList && scoreRankItemList[0]) {
          return classPotentialList(scoreRankItemList)
        } else {
          return
        }
      }
    },
    methods: {
      countPercent(point) {
        const str = (point * 100) + ''
        let str2 = Math.round(str)
        return Math.abs(str2) + '%'
      }
    }
  }
</script>
<style scoped>
  .analysis_train {
    background: #FFECEC;
    margin-top: 24px;
    margin-bottom: 3px;
    border-radius: 4px;
    text-align: center;
    padding-top: 11px;
    padding-bottom: 11px;
    font-size: 14px;
    margin-left: 2%;
    width: 96%;
  }
  
  .analysis_train p {
    width: 100%;
    font-size: 13px;
    color: #666666;
    letter-spacing: -0.07px;
  }
  
  .analysis_train .a_count {
    font-size: 20px;
    line-height: 28px;
    color: #FF6B6B;
    margin-top: 2px;
    letter-spacing: -0.07px;
  }
  
  .train_average {
    padding-top: 10px;
    line-height: 18px;
  }
  
  .analysis_train .detail {
    font-size: 13px;
    line-height: 18px;
  }
  
  .analysis_train>div {
    height: 60px;
    width: 50%;
  }
  
  .analysis_train>div:first-child {
    background-color: #FFFAFA;
  }
  
  .analysis_head {
    margin-bottom: 0px;
    padding-top: 30px;
    background-color: white;
    padding-bottom: 5px;
  }
  
  .container>p {
    padding-bottom: 10px;
    font-size: 14px;
    color: #999999;
    text-align: center;
    padding-top: 10px;
  }
  
  .detail_img {
    vertical-align: -15%;
    margin-left: 4px;
    height: 17px;
    display: inline-block;
  }
  
  .analysis {
    flex-direction: column;
    display: flex;
    justify-content: space-evenly;
    padding-top: 10px;
    border-radius: 4px;
    text-align: center;
    margin-left: 2%;
    color: #C38924;
    font-size: 14px;
    line-height: 27px;
    width: 96%;
    padding-bottom: 10px;
    background-color: #FFEDD1;
  }
  
  .analysis .a_count {
    font-size: 24px;
    line-height: 24px;
  }
  
  .analysis_detail {
    letter-spacing: -0.08px;
    color: #333333;
    font-size: 14px;
  }
  
  .up {
    background: url('~assets/imgs/workpaper/icon_up.png') no-repeat;
    width: 20px;
    background-size: 20px 17px;
  }
  
  .down {
    background: url('~assets/imgs/workpaper/icon_down.png') no-repeat;
    width: 20px;
    background-size: 20px 17px;
  }
  
  .flat {
    background: url('~assets/imgs/workpaper/icon_flat.png') no-repeat;
    width: 15.4px;
    background-size: 15.4px 17px;
  }
</style>
