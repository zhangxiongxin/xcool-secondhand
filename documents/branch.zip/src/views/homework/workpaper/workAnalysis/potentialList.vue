<template lang="pug">
  //- 正确率提升潜力榜组件
  div.head
    div.potential_head(:class="{ training_sub : reportType === 'training'}") {{showType}}
    div.potential_detail 
      div.single_potential(v-for='(item,index) in scoreRankItemList', :key='index') 
        p.single_title {{item.studentName}}
        div.single_detail
          div.icon_block1 
            p {{potentialNum(item.idealIndex, item.actualIndex)}}
            p 提升潜力
          div.icon_block2 
            p {{reportType === 'training' ? item.actualIndex : rateFilter(item.actualIndex)}}
            p {{reportType === 'training' ? '本次得分' : '本次正确率'}}
          div.icon_block3 
            p {{reportType === 'training' ? item.idealIndex : rateFilter(item.idealIndex)}}
            p {{reportType === 'training' ? '理想得分' : '理想正确率'}}
        p.icon_sub 正确率有提升潜力的题目
        div.sub_detail(:class="{ book_detail: reportType === 'book' || reportType === 'vacation' }") 
          span(v-for='subItem, subIndex in item.questionNumText', key="subIndex") {{subItem}} {{subIndex === item.questionNumText.length - 1 ? '' : '；'}}

</template>
<script>
  export default {
    name: 'potentialList',
    data() {
      return {
        showType: this.reportType === 'training' ? '提分潜力榜' : '正确率提升潜力榜'
      }
    },
    props: ['reportType', 'scoreRankItemList'],
    methods: {
      rateFilter(num) {
        const str = (num * 100) + ''
        return Math.round(str) + '%'
      },
      potentialNum(idealIndex, actualIndex) {
        if (this.reportType === 'training') {
          let num = idealIndex - actualIndex
          return Math.round(num + '') + '%'
        } else {
          let num = Math.round((idealIndex * 100) + '') - Math.round((actualIndex * 100) + '')
          return num + '%'
        }
      }
    },
    computed: {}
  }
</script>
<style scoped>
  .icon_block1 {
    background: #FFEEDE;
  }
  
  .icon_block2 {
    background: #EEF9E3;
  }
  
  .icon_block3 {
    background: #ECF2FC;
  }
  
  .icon_block1 p {
    color: #C7803F;
  }
  
  .icon_block2 p {
    color: #8DC451;
  }
  
  .icon_block3 p {
    color: #3479D2;
  }
  
  .single_detail>div {
    margin-left: 5px;
    margin-right: 5px;
    border-radius: 1px;
    width: 110px;
    height: 72px;
    padding-top: 15px;
  }
  
  .single_title {
    height: 32px;
    font-size: 20px;
    color: #333333;
    letter-spacing: -0.09px;
  }
  
  .single_detail>div p {
    line-height: 20px;
    text-align: center;
    letter-spacing: -0.08px;
  }
  
  .single_detail {
    display: flex;
    justify-content: space-around;
  }
  
  .single_potential>p {
    padding-left: 14px;
  }
  
  .head {
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    width: 100%;
    background-color: #ECF2FC;
    padding-top: 10px;
  }
  
  .potential_head {
    position: relative;
    background: url('~assets/imgs/workpaper/potential_head.png') no-repeat;
    width: 208.08px;
    height: 55px;
    background-size: 208.08px 55px;
    text-align: center;
    font-size: 17px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    padding-left: 30px;
    padding-top: 18px;
  }
  
  .training_sub {
    background: url('~assets/imgs/workpaper/potential_head2.png') no-repeat;
    width: 162.25px;
    height: 55px;
    background-size: 162.25px 55px;
  }
  
  .potential_detail {
    margin-top: -35px;
    padding-top: 25px;
    background: #fff;
    width: 100%;
  }
  
  .single_potential {
    position: relative;
    padding-bottom: 9px;
    padding-top: 9px;
    width: 96%;
    margin-left: 2%;
    border: 1px solid #3399FF;
    border-left: 10px solid #3399FF;
    border-radius: 4px;
    margin-bottom: 20px;
    margin-top: 35px;
  }
  
  .icon_sub {
    padding-top: 12px;
    font-size: 14px;
    color: #3479D2;
    letter-spacing: -0.06px;
    line-height: 22px;
  }
  
  .sub_detail {
    padding-left: 14px;
    line-height: 22px;
    font-size: 14px;
    color: #666666;
    letter-spacing: -0.06px;
  }
  
  .sub_detail span {
    padding-right: 10px;
  }
  
  .book_detail span {
    width: 100%;
    display: block;
  }
</style>
