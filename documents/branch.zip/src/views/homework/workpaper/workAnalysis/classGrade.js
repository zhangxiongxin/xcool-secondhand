
export default function classGrade(data) {
  const res = {
    lists: [],
    uploadNum: 0,
    countGrade: {
      gradeLevel: [],
      averageScore: Math.round(data.averageScore),
      totalScore: 0
    }
  }
  let pre = {
    excellent: data.befScoreIndex.excellent,
    good: data.befScoreIndex.good,
    average: data.befScoreIndex.average,
    poor: data.befScoreIndex.poor
  }
  let befScore = [pre.excellent, pre.good, pre.average, pre.poor]
  let totalScore = data.scoreList.length ? data.scoreList[0].totalScore : 120
  res.countGrade.totalScore = totalScore
  const lists = [
    [{ level: '（' + Math.round(totalScore * 0.9) + '-' + totalScore * 1 + '）' }],
    [{ level: '（' + Math.round(totalScore * 0.8) + '-' + Math.round(totalScore * 0.9) + '）' }],
    [{ level: '（' + Math.round(totalScore * 0.6) + '-' + Math.round(totalScore * 0.8) + '）' }],
    [{ level: '（' + 0 + '-' + Math.round(totalScore * 0.6) + '）' }]
  ]
  res.uploadNum = data.scoreList.length
  data.scoreList.forEach(v => {
    if (v.score >= Math.round(totalScore * 0.9) && v.score <= totalScore * 1) {
      lists[0].push({
        level: '（' + totalScore * 1 + '-' + Math.round(totalScore * 0.9) + '）'
      })
    }
    if (v.score >= Math.round(totalScore * 0.8) && v.score < Math.round(totalScore * 0.9)) {
      lists[1].push({
        level: '（' + Math.round(totalScore * 0.8) + '-' + Math.round(totalScore * 0.9) + '）'
      })
    }
    if (v.score >= Math.round(totalScore * 0.6) && v.score < Math.round(totalScore * 0.8)) {
      lists[2].push({
        level: '（' + Math.round(totalScore * 0.6) + '-' + Math.round(totalScore * 0.8) + '）'
      })
    }
    if (v.score < Math.round(totalScore * 0.6)) {
      lists[3].push({
        level: '（' + 0 + '-' + Math.round(totalScore * 0.6) + '）'
      })
    }
  })
  for (let i = 0; i < lists.length; i++) {
    let percent = (Math.round((lists[i].length - 1) / data.scoreList.length * 100) || 0) + '%'
    let num = lists[i].length - 1
    res.lists.push({
      level: lists[i][0].level,
      num: num,
      numChange: Number(num - befScore[i]),
      percent: percent
    })
    res.countGrade.gradeLevel.push({
      percent: percent,
      num: num,
      numChange: Number(num - befScore[i])
    })
  }
  return res
}
