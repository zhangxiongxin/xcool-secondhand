<template lang="pug">
  //- 错题分布组件  按作业中布置的题目顺序排序
  div.head(v-if="handleError")
    div.error_head 错题分布
    div.error_detail
      div.poor_mastery
        span.poor_head 掌握较差
        p.explain
          span （题目{{reportType === 'training' ? '得分' : '正确'}}率＜50%）
          span  建议重点评讲
        div.mastery.book_mastery(v-if="poorMastery[0]")
          div.single_mastery(v-for='(item,index) in poorMastery', :key='index', :class="item.accuracyClass", @click="jump(item.questionId ,item.rightIndex , item.subQuestionId)")
            span {{item.numInPaper}}
            span.correct_rate {{item.correctRate}}
        div.mastery.book_mastery(v-else)
          div.no_message 暂无
      div.poor_aver.poor_mastery
        span.poor_average 掌握一般
        p.explain
          span （50%≤题目{{reportType === 'training' ? '得分' : '正确'}}率＜80%）
          span  建议稍作评讲
        div.mastery.book_mastery(v-if="commonMastery[0]")
          div.single_mastery(v-for='(item,index) in commonMastery', :key='index', :class="item.accuracyClass", @click="jump(item.questionId ,item.rightIndex , item.subQuestionId)") 
            span {{item.numInPaper}}
            span.correct_rate {{item.correctRate}}
        div.mastery.book_mastery(v-else)
          div.no_message 暂无
      div.single_error(v-for='(item,index) in handleError', :key='index', :class="item.accuracyClass + '_middle'")
        .little_block(:class="item.accuracyClass")
        .single_detail
          .error_num(:class="item.accuracyClass + '_tail'")
            p {{item.errorPersonCount}}
            p 错误人数
          .detail(v-if="reportType==='book' || reportType==='vacation'") 
            p(v-html="showSectionName(item.sectionName)")
          .detail.detail_title 
            img(src="~assets/imgs/workpaper/section_icon.png")
            span(:key="item.questionId") {{item.questionType}} {{item.numInPaper}}
          .detail   
            img(src="~assets/imgs/workpaper/person_icon.png")
            span.student_name {{item.studentNameList}}
          .detail.tail 
            img(src="~assets/imgs/workpaper/right_person.png")
            span 题目{{reportType === 'training' ? '得分' : '正确'}}率：
            span {{item.correctRate}}
            button.find_right(@click='jump(item.questionId ,index , item.subQuestionId)') 查看答案

</template>
<script>
  import { activeIndex } from '@/store/types'
  import store from '@/store'
  import popup from '@/components/common/popup'
  import errorQuestion from '../../distribution'

  export default {
    name: 'errorSpread',
    props: ['reportType', 'classId', 'examId', 'handleError'],
    data() {
      return {
        poorMastery: [],
        commonMastery: []
      }
    },
    methods: {
      jump(qid, index, sqid) {
        store.commit(activeIndex, -1)
        popup(errorQuestion, { index: index, questionId: qid, subQuestionId: sqid, classId: this.classId, examId: this.examId, reportType: this.reportType }, () => {
        })
      },
      handleData(item, data) {
        switch (data.errorPersonCount) {
          case item[0]:
            data.accuracyClass = 'red_class'
            break
          case item[1]:
            data.accuracyClass = 'apricot_class'
            break
          case item[2]:
            data.accuracyClass = 'yellow_class'
            break
          default:
            data.accuracyClass = 'pink_class'
        }
      },
      handleMastery(item, data, poorMastery, commonMastery) {
        if (data.floatCorrect < 50) {
          switch (data.floatCorrect) {
            case item[0]:
              data.accuracyClass = 'first'
              break
            case item[1]:
              data.accuracyClass = 'second'
              break
            case item[2]:
              data.accuracyClass = 'third'
              break
            default:
              data.accuracyClass = 'normal'
          }
          poorMastery.push(data)
        }
        if (data.floatCorrect >= 50 && data.floatCorrect < 80) {
          data.accuracyClass = ''
          commonMastery.push(data)
        }
      },
      showSectionName: function(sectionName) {
        let str = sectionName.replace(/#%#/g, '<br/>')
        return str
      }
    },
    watch: {
      handleError: {
        handler: function(val, oldVal) {
          let arr = []
          let mastery = []
          let masteryCorrect = []
          let poorMastery = []
          let commonMastery = []
          if (Object.prototype.toString.call(val) !== '[object Array]') return
          val.forEach((item, index) => {
            arr.push(item.errorPersonCount)
            masteryCorrect.push(Number(item.correctRate.replace('%', '')))
            if (this.reportType === 'book' || this.reportType === 'vacation') {
              mastery.push({ correctRate: item.correctRate, numInPaper: item.sectionName + ' :  ' + item.typeNumInPaper, floatCorrect: Number(item.correctRate.replace('%', '')), questionId: item.questionId, rightIndex: index, subQuestionId: item.subQuestionId })
            } else {
              mastery.push({ correctRate: item.correctRate, numInPaper: item.sectionName + item.typeNumInPaper, floatCorrect: Number(item.correctRate.replace('%', '')), questionId: item.questionId, rightIndex: index, subQuestionId: item.subQuestionId })
            }
          })
          arr = Array.from(new Set(arr)).sort((a, b) => {
            return a - b
          }).reverse()
          masteryCorrect = Array.from(new Set(masteryCorrect)).sort((a, b) => {
            return a - b
          })
          mastery = Array.from(new Set(mastery)).sort((a, b) => {
            return a.floatCorrect - b.floatCorrect
          })
          mastery.forEach((item) => {
            this.handleMastery(masteryCorrect, item, poorMastery, commonMastery)
          })
          val.forEach((item) => {
            this.handleData(arr, item)
          })
          this.poorMastery = poorMastery
          this.commonMastery = commonMastery
        },
        deep: true
      }
    }
  }
</script>
<style scoped>
  .head {
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    padding-top: 10px;
    width: 100%;
    background-color: #ECF2FC;
  }
  
  .error_num {
    top: -10px;
    border-radius: 10px 10px 0px 0px;
    right: 0%;
    position: absolute;
    width: 71px;
    height: 58px;
    box-shadow: 0 2px 8px 0 rgba(227, 102, 102, 0.07);
  }
  
  .no_message{
    font-size:14px;
    padding-left:11px;
    line-height: 28px;
  }

  .error_num p {
    font-size: 14px;
    color: inherit;
    letter-spacing: -0.09px;
    line-height: 12px;
    padding-top: 10px;
    text-align: center;
  }
  
  .error_head {
    background: url('~assets/imgs/workpaper/error_head.png') no-repeat;
    position: relative;
    width: 138.53px;
    height: 55px;
    background-size: 138.53px 55px;
    text-align: center;
    font-size: 17px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    padding-left: 32px;
    padding-top: 18px;
  }
  
  .find_right {
    display: inline;
    background: #4F9AFB;
    border-radius: 100px;
    font-size: 14px;
    color: #FFFFFF;
    letter-spacing: -0.07px;
    border: 0px;
    width: 120px;
    height: 36px;
    position: absolute;
    right: 2%;
    top: -10px;
    box-shadow: 0 2px 4px 0 rgba(50, 101, 183, 0.50);
  }
  
  .detail {
    align-items: flex-start;
    display: flex;
    line-height: 20px;
    margin-top: 20px;
  }
  
  .error_detail {
    margin-top: -35px;
    padding-top: 58px;
    background: #fff;
    width: 100%;
  }
  
  .single_error {
    width: 96%;
    margin-left: 2%;
    margin-bottom: 28px;
    display: flex;
  }
  
  .single_detail span {
    font-size: 14px;
    color: #666666;
    letter-spacing: -0.09px;
  }
  
  .single_error .detail span {
    position: relative;
  }
  
  .single_error .detail img {
    vertical-align: middle;
    width: 19.5px;
    margin-left: 10px;
    margin-right: 10px;
  }
  
  .single_error .tail span {
    font-size: 14px;
    color: #333333;
    letter-spacing: 0;
  }
  
  .single_error .tail {
    position: relative;
    overflow: unset;
    margin-bottom: 20px;
  }
  
  .single_error .detail p {
    padding-right: 72px;
    margin-left: 40px;
    font-size: 14px;
    color: #666666;
    letter-spacing: -0.1px;
    line-height: 19px;
  }
  
  .single_error .detail p:first-child {
    padding-top: 10px;
  }
  
  .single_detail {
    position: relative;
    width: 100%;
  }
  
  .single_detail .detail_title span {
    font-size: 18px;
    color: #333333;
    letter-spacing: -0.09px;
  }
  
  .little_block {
    border-radius: 2px;
    width: 2.7%;
  }
  
  .red_class_middle {
    background: #FFFAFA;
    box-shadow: 0 2px 4px 0 rgba(196, 141, 141, 0.32);
    border-radius: 4px;
  }
  
  .apricot_class_middle {
    background: #FFFDFC;
    box-shadow: 0 2px 4px 0 rgba(246, 158, 106, 0.20);
    border-radius: 4px;
  }
  
  .yellow_class_middle {
    background: #FFFEF9;
    box-shadow: 0 2px 4px 0 rgba(179, 150, 57, 0.23);
    border-radius: 4px;
  }
  
  .red_class {
    background: #FF6B6B;
  }
  
  .red_class_tail {
    background: #FF6B6B;
    color: #fff;
  }
  
  .apricot_class {
    background: #FF9E6B;
  }
  
  .apricot_class_tail {
    background: #FF9E6B;
    color: #fff;
  }
  
  .yellow_class {
    background: #FFD86B;
  }
  
  .yellow_class_tail {
    color: #99730A;
    background: #FFD86B;
  }
  
  .pink_class {
    background: #fff;
  }
  
  .pink_class_tail {
    color: #FF6B6B;
    background: #FFDEDE;
  }
  
  .pink_class_middle {
    border: 1px solid #FFDEDE;
  }
  
  .mastery {
    display: flex;
    justify-content: flex-start;
    padding-left: 14px;
    padding-right: 14px;
    flex-wrap: wrap;
    margin-top: 5px;
  }
  
  .single_mastery {
    background: #C7EDFF;
    border: 1px solid #C7EDFF;
    border-radius: 4px;
    line-height: 30px;
    display: inline-block;
    padding: 0px;
    margin-bottom: 8px;
  }
  
  .single_mastery>span:first-child {
    text-align: left;
    padding-left: 11px;
    display: inline-block;
    font-size: 14px;
    line-height: 28px;
    width: calc(100% - 50px);
  }
  
  .correct_rate {
    width: 50px;
    text-align: center;
    font-size: 14px;
    height: 28px;
    vertical-align: middle;
    line-height: 28px;
    padding: 0px 12px;
  }
  
  .poor_mastery {
    padding-bottom: 10px;
    margin-bottom: 28px;
    position: relative;
    background: #FFF6F5;
    border: 2px solid #FCB1AF;
    box-shadow: 0 2px 6px 0 rgba(177, 49, 47, 0.27);
    border-radius: 4px;
    width: 96%;
    margin-left: 2%;
  }
  
  .poor_mastery>span {
    height: 13px;
    background: #fff;
    position: absolute;
    top: -13px;
    font-size: 20px;
    letter-spacing: -0.09px;
    margin-left: 15px;
    padding-left: 10px;
    width: 100px;
    display: inline-block;
  }
  
  .poor_aver {
    background: #FFF9F1;
    border: 2px solid #FFD096;
    box-shadow: 0 2px 6px 0 rgba(188, 121, 41, 0.25);
  }
  
  .poor_head {
    color: #E16562;
  }
  
  .poor_average {
    color: #F59E35;
  }
  
  .explain {
    padding-left: 21px;
    padding-top: 14px;
    font-size: 14px;
    color: #E16562;
    letter-spacing: -0.06px;
  }
  
  .explain>span:nth-child(2) {
    color: #999999;
  }
  
  .first {
    background: #E96666;
    border: 1px solid #E96666;
  }
  
  .second {
    background: #FF9F39;
    border: 1px solid #FF9F39;
  }
  
  .third {
    background: #FBE544;
    border: 1px solid #FBE544;
  }
  
  .normal {
    background: #C7EDFF;
    border: 1px solid #C7EDFF;
  }
  
  .poor_aver>.explain>span:first-child {
    color: #F59E35;
  }
  
  .book_mastery {
    flex-direction: column;
    align-items: end;
  }
  
  .book_mastery>.single_mastery {
    width: 100%;
    display: flex;
    justify-content: space-between;
  }
  
  .book_mastery .correct_rate {
    align-self: flex-end;
  }
</style>
