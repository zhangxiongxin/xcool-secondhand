<template lang="pug">
  //- 需要关注组件
  div.head(v-if="needAttention")
    div.need_head 需要关注
    div.need_detail 
      div.single_need.top(v-if="needAttention.top10List[0]")
        p
          img(src="~assets/imgs/workpaper/top.png") 
          span {{reportType === 'training' ? '得分前十名' : '正确率前十名'}}
        div.single_detail
          div(v-if="index < 10", v-for="(item,index) in needAttention.top10List", :key="index") 
            span {{item.studentName}}
            span(v-if="reportType === 'training'")  ({{item.score}} 分)
            span(v-else) ({{item.currAccuracy | rateFilter}} )
      div.single_need.move_quick
        p
          img(src="~assets/imgs/workpaper/move_up.png") 
          span 进步较大
        div.single_detail
          div(v-if="!needAttention.biggestProgress[0]") 暂无
          div(v-for="(item,index) in needAttention.biggestProgress", :key="index")
            span {{item.studentName}}
            img(src="~assets/imgs/workpaper/fa-arrow-up.png")  
            span.num_a {{item.lastRank - item.currRank}}
      div.single_need.down_quick
        p
          img(src="~assets/imgs/workpaper/move_down.png") 
          span 退步较大
        div.single_detail
          div(v-if="!needAttention.biggestRetrogression[0]") 暂无
          div(v-for="(item,index) in needAttention.biggestRetrogression", :key="index")
            span {{item.studentName}} 
            img(src="~assets/imgs/workpaper/fa-arrow-down.png")
            span.num_b  {{item.currRank - item.lastRank}}
      div.single_need.no_up
        p 
          img(src="~assets/imgs/workpaper/never_up.png") 
          span 未提交
        div.single_detail
          div(v-if="!needAttention.unSubmit[0]")  暂无
          div(v-for="(item,index) in needAttention.unSubmit", :key="index") {{item.studentName}}


</template>
<script>
  export default {
    name: 'needAttention',
    data() {
      return {}
    },
    props: ['reportType', 'needAttention'],
    methods: {
    },
    computed: {
    }
  }
</script>
<style scoped> 
  .single_detail>div {
    font-size: 14px;
    color: #666666;
    letter-spacing: -0.06px;
    line-height: 32px;
    padding-right: 15px;
  }
  .single_detail>div>img{
    width:14px;
    margin-top: -3px;
    margin-left: 5px;
    margin-right: 2px;
    vertical-align: middle;  
  }

  .single_detail {
    padding-left: 25px;
    padding-right: 30px;
    display: flex;
    flex-wrap: wrap;
  }
  
  .single_need>p {
    position: absolute;
    top: -13px;
    background: white;
    padding-left: 10px;
    padding-right: 10px;
    left: 15px;
  }
  .single_need>p>img {
    width:28px;
    margin-right:10px;
  }
   .single_need>p>span {
    vertical-align: super;
    display: inline-block;
    font-size: 18px;
    color: #333333;
    letter-spacing: -0.08px;
  }
  
  .head {
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    width: 100%;
    background-color: #ECF2FC;
    padding-top:10px;
  }

  .num_a{
    color:#24CB72;
  }
  .num_b{
    color:#FF5353;
  }
  
  .need_head {
    position: relative;
    background: url('~assets/imgs/workpaper/need_head.png') no-repeat;
    width: 138.53px;
    height: 55px;
    background-size: 138.53px 55px;
    text-align: center;
    font-size: 17px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    padding-left: 32px;
    padding-top: 18px;
  }
  
  .need_detail {
    margin-top: -35px;
    padding-top: 25px;
    background: #fff;
    width: 100%;
  }
  
  .single_need {
    position: relative;
    padding-bottom: 18px;
    padding-top: 18px;
    width: 96%;
    margin-left: 2%;
    border: 1px solid #C1D8FF;
    margin-bottom: 20px;
    margin-top: 35px;
  }
</style>
