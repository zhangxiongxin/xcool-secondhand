<template lang="pug">
  //- 成绩分布组件
  div.head
    div.score_head 成绩分布
    p.up_num 上传成功{{scoreSpreads.done}}人
    div.score_detail 
      div.single_detail(v-for='(item,index) in handleScore.lists', :key='index', :class="{a_level_head: index === 0, b_level_head: index === 1, c_level_head: index === 2,  d_level_head: index === 3}")  
        div
          p 
            span 成绩为
            span(:class="{a_level: index === 0, b_level: index === 1, c_level: index === 2,  d_level: index === 3}") {{showLevel(index)}} 
            span {{item.level}} 的学生占 {{item.percent}}
          p(v-if="!scoreSpreads.isFirstFlag") {{showChange(item.numChange)}}
        div 
          p 
            span(:class="{a_level: index === 0, b_level: index === 1, c_level: index === 2,  d_level: index === 3}") {{item.num}}
            span 人

</template>
<script>
  export default {
    name: 'scoreSpread',
    props: ['scoreSpreads', 'handleScore'],
    data() {
      return {
      }
    },
    methods: {
      showChange: function(numChange) {
        if (numChange > 0) {
          return '比上次考试增加' + numChange + '人'
        } else if (numChange === 0) {
          return '与上次考试持平'
        } else if (numChange < 0) {
          return '比上次考试减少' + Math.abs(numChange) + '人'
        }
      },
      showLevel: function(index) {
        if (index === 0) {
          return '优'
        } else if (index === 1) {
          return '良'
        } else if (index === 2) {
          return '中'
        } else {
          return '差'
        }
      }
    }
  }
</script>
<style scoped>
  .head {
    position: relative;
    box-shadow: 0 2px 6px 0 #D4DDEE inset;
    padding-top:10px;
    width: 100%;
    background-color: #ECF2FC;
  }
  
  .score_head {
    position: relative;
    background: url('~assets/imgs/workpaper/score_head.png') no-repeat;
    width: 138.53px;
    height: 55px;
    background-size: 138.53px 55px;
    text-align: center;
    font-size: 17px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
    padding-left: 32px;
    padding-top: 18px;
  }
  .up_num{
    right: 2%;
    top: 37px;
    position: absolute;
    font-size: 14px;
    color: #4F9AFB;
    letter-spacing: -0.08px;
  } 

  .score_detail {
    margin-bottom: 10px;
    margin-top: -35px;
    padding-top: 27px;
    background: #fff;
    width: 100%;
    border-radius: 4px;
  }

  .single_detail {
    display: flex;
    padding-top: 10px;
    padding-bottom: 10px;
    width: 96%;
    margin: 0 auto;
    margin-top: 15px;
  }
  
  .single_detail>div {
    flex-direction: column;
    align-items: baseline;
    justify-content: center;
    display: flex;
  }
  
  .single_detail>div:first-child {
    width: 76%;
  }
  
  .single_detail>div:nth-child(2) {
    width: 24%;
  }
  
  .single_detail>div:nth-child(2)>p {
    line-height: 40px;
  }
  
  .single_detail>div>p {
    line-height: 20px;
    padding-left: 26px;
    font-size: 14px;
    color: #333333;
    letter-spacing: -0.09px;
  }
  
  .a_level_head {
    background: #EEF9E3;
  }
  
  .a_level {
    font-size: 24px;
    color: #77B830;
  }
  
  .b_level_head {
    background: #EEF2FB;
  }
  
  .b_level {
    font-size: 24px;
    color: #3399FF;
  }
  
  .c_level_head {
    background: #FCEDD3;
  }
  
  .c_level {
    font-size: 24px;
    color: #BF722A;
  }
  
  .d_level_head {
    background: #FFDEDE;
  }
  
  .d_level {
    font-size: 24px;
    color: #EE726C;
  }
</style>
