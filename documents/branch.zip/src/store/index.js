// https://vuex.vuejs.org/zh-cn/intro.html
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

import report from './modules/report'
import user from './modules/user'
import weeklyExercise from './modules/weeklyExercise'
import paperSet from './modules/paperSet'
import textBook from './modules/textBook'
import homework from './modules/homework'

const store = new Vuex.Store({
  modules: { report, user, weeklyExercise, paperSet, textBook, homework }
})
export default store
