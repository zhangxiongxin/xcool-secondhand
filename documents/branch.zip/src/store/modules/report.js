import { weekWrongsReport, weekReport, clearData, homeworkReport, examReport } from '../types'
import embeddedPageService from '@/services/embeddedPage'
import {bigQuestionQid, ringNumber} from '@/filters/doudou'
import colorDistinguish from '@/utils/colorDistinguish'
export default {
  state: {
    reportData: {},
    loading: true,
    attentionListsData: {}, // 关注列表数据
    improvingListsData: [], // 提升榜
    problemRightData: [] // 难题答对表格
  },
  mutations: {
    [clearData](state, payload) {
      state.reportData = {}
      state.problemRightData = []
      state.improvingListsData = []
    }
  },
  actions: {
    // 作业个人报告查询
    [homeworkReport]({ state, commit, getters }, payload) {
      state.loading = true
      state.reportData = {}
      state.improvingListsData = []
      state.attentionListsData = {}
      state.problemRightData = []
      return embeddedPageService.homeworkReport({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(res) {
        state.loading = false
        let source = res.data.source
        state.reportData = res.data
        if (source === 0) {
          state.reportData.questionList = questions(res.data.questionDistribute[0].sectionDistribute[0].scoreDistribute, source)
        } else {
          let a = []
          res.data.questionDistribute.forEach(v1 => {
            v1.sectionDistribute.forEach(v2 => {
              a.push({
                teachingBook: v1.bookName + ' ' + v2.sectionName,
                distribute: questions(v2.scoreDistribute)
              })
            })
          })
          state.reportData.questionList = a
        }
        // 兼容假期作业和教辅
        console.log(source)
        if (source === 2) source = 1
        // 知识点
        embeddedPageService.personalHomeworkKnowledge({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, source: source}, function(data) {
          if (source === 0) {
            state.reportData.knowledgeList = handleKnowledge(data.data)
          } else {
            state.reportData.knowledgeList = [{}]
            state.reportData.knowledgeList[0].distribute = handleKnowledge(data.data)
          }
        })
        // 关注榜
        embeddedPageService.personalAttention({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 1}, function(data) {
          state.attentionListsData = data.data
          state.attentionListsData.top10List.splice(10, 1000)
        })
        // 提升榜
        embeddedPageService.improvingLists({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(data) {
          state.improvingListsData = handleImproveData(data.data.scoreRankItemList, data.data.allQuesType)
        })
        // 难题答对
        embeddedPageService.wrongRight({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 1}, function(data) {
          state.problemRightData = personalWrong(data.data)
        })
      })
    },
    // 错题周题练个人报告查询
    [weekWrongsReport]({ state, commit, getters }, payload) {
      state.loading = true
      state.reportData = {}
      return embeddedPageService.weekWrongsReport({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(res) {
        state.loading = false
        let source = res.data.source
        state.reportData = res.data
        state.reportData.questionList = questions(res.data.questionDistribute[0].sectionDistribute[0].scoreDistribute, source)
        // 知识点
        embeddedPageService.personalHomeworkKnowledge({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, source: source}, function(data) {
          state.reportData.knowledgeList = handleKnowledge(data.data)
        })
      })
    },
    [examReport]({ state, commit, getters }, payload) {
      state.loading = true
      state.reportData = {}
      state.attentionListsData = {}
      state.improvingListsData = []
      state.problemRightData = []
      return embeddedPageService.examReport({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(res) {
        state.loading = false
        state.reportData = res.data
        state.reportData.scoreDistribute = personalData(res.data.scoreDistribute)
        // 知识点
        embeddedPageService.personalExamKnowledge({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 1}, function(data) {
          state.reportData.knowledgeDistribute = handleKnowledge(data.data)
        })
        // 关注榜
        embeddedPageService.personalAttention({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 3}, function(data) {
          state.attentionListsData = data.data
          state.attentionListsData.top10List.splice(10, 1000)
        })
        // 提升榜
        embeddedPageService.improvingLists({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(data) {
          state.improvingListsData = handleImproveData(data.data.scoreRankItemList, data.data.allQuesType)
        })
        // 难题答对
        embeddedPageService.wrongRight({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 3}, function(data) {
          state.problemRightData = personalWrong(data.data)
        })
      }, function(res) {
        console.log(res)
      })
    },
    [weekReport]({ state, commit, getters }, payload) {
      state.loading = true
      state.reportData = {}
      state.improvingListsData = []
      state.attentionListsData = {}
      state.problemRightData = []
      return embeddedPageService.weekReport({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(res) {
        state.loading = false
        state.reportData = res.data
        state.reportData.scoreDistribute = personalData(res.data.scoreDistribute)
        // 知识点
        embeddedPageService.personalExamKnowledge({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 2}, function(data) {
          state.reportData.knowledgeDistribute = handleKnowledge(data.data)
        })
        // 关注榜
        embeddedPageService.personalAttention({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 2}, function(data) {
          state.attentionListsData = data.data
          state.attentionListsData.top10List.splice(10, 1000)
        })
        // 提升榜
        embeddedPageService.improvingLists({classId: payload.classId, studentId: payload.studentId, examId: payload.examId}, function(data) {
          state.improvingListsData = handleImproveData(data.data.scoreRankItemList, data.data.allQuesType)
        })
        // 难题答对
        embeddedPageService.wrongRight({classId: payload.classId, studentId: payload.studentId, examId: payload.examId, type: 2}, function(data) {
          state.problemRightData = personalWrong(data.data)
        })
      })
    }
  }
}
// 个人难题做对数据处理
function personalWrong(data, source) {
  if (!data) return
  const res = []
  let typeArr = data.allQuesType
  data.difficultQuestionList.forEach((v, i) => {
    res.push({
      questionId: v.questionId,
      sectionName: v.sectionName,
      questionType: v.questionType,
      numInPaperText: (function() {
        return bigQuestionQid(typeArr, v.questionType) + '、' + v.numInPaper
      })(),
      studentInfoList: v.studentInfoList,
      accuracy: v.correctRate
    })
  })
  return res
}
function questions(data, source) {
  if (!data) return
  const res = []
  let typeArr = []
  data.forEach(function(v) {
    typeArr.push(v.questionType)
  })
  data.forEach(v => {
    res.push({
      questionId: v.questionId,
      questionType: v.questionType,
      numInPaper: (function() {
        if (source === 0) {
          return bigQuestionQid(typeArr, v.questionType) + '、' + v.numInPaper
        } else {
          return v.numInPaper
        }
      })(),
      correct: v.correct,
      knowledgePoint: (() => {
        let knowledgePoint = []
        v.knowledges.map((item, index) => {
          knowledgePoint.push(ringNumber(index, item.knowledgePointName))
        })
        return knowledgePoint.join(' ')
      })()
    })
  })
  return res
}
// 处理个人考试周练报告数据
function personalData(data) {
  if (!data) return
  const res = []
  let typeArr = []
  data.forEach(function(v) {
    typeArr.push(v.questionType)
  })
  data.forEach(v => {
    res.push({
      questionId: v.questionId,
      questionType: v.questionType,
      numInPaper: bigQuestionQid(typeArr, v.questionType) + '、' + v.numInPaper,
      studentScore: v.studentScore,
      questionScore: v.questionScore,
      scoreRate: (function() {
        return Math.round(v.studentScore / v.questionScore * 100) + '%'
      })(),
      knowledgePoint: (() => {
        let knowledgeVoList = v.knowledgeVoList1 || v.knowledgeVoList
        if (knowledgeVoList && knowledgeVoList.length) {
          let arr = []
          knowledgeVoList.map((item, index) => {
            arr.push(ringNumber(index, item.knowledgePointName))
          })
          return arr.join(' ')
        }
        return ''
      })(),
      totalScore: v.totalScore
    })
  })
  return res
}
// 处理提升榜数据
function handleImproveData(data, type) {
  let typeArr = []
  if (!(Array.isArray(data) && data.length)) return data
  let arr = [].concat(data)
  arr.forEach((item) => {
    let text = []
    if (!item.resultQuestionVos) item.resultQuestionVos = []
    item.resultQuestionVos.forEach((subItem) => {
      // 有bookName，sectionName，表示是教辅
      if (subItem[0].sectionName) text.push(getText('sectionName', subItem))
      // 没有bookName，表示是普通作业
      if (!subItem[0].bookName) typeArr.push(subItem[0].questionType)
    })
    if (text.length) item.questionNumText = text.join(';<br>').replace(/#%#/g, ' ')
  })
  arr = arr.sort((a, b) => {
    a = Math.round(a.idealIndex * 100) - Math.round(a.actualIndex * 100)
    b = Math.round(b.idealIndex * 100) - Math.round(b.actualIndex * 100)
    return b - a
  })
  if (!typeArr.length) return arr
  typeArr = type
  arr.forEach((item) => {
    let text = []
    item.resultQuestionVos.forEach((subItem) => {
      subItem.typeText = bigQuestionQid(typeArr, subItem[0].questionType)
      text.push(getText(subItem.typeText, subItem))
    })
    item.questionNumText = text.join('; ')
  })
  return arr
}
// 处理知识点分布数据
function handleKnowledge(data) {
  let typeArr = []
  if (!(Array.isArray(data) && data.length)) return data
  let arr = [].concat(data)
  colorDistinguish(arr, 'accuracy')
  arr.forEach((item) => {
    let text = []
    item.knowledgeRealtionVo.forEach((subItem) => {
      if (subItem.type) typeArr.push(subItem.type)
      if (subItem.sectionName) text.push(getText(subItem.sectionName, subItem.questionNum))
    })
    item.questionNumText = text.join(';<br>')
  })
  if (!typeArr.length) return arr
  arr.forEach((item) => {
    let text = []
    item.knowledgeRealtionVo.forEach((subItem) => {
      subItem.typeText = bigQuestionQid(typeArr, subItem.type)
      text.push(getText(subItem.typeText, subItem.questionNum))
    })
    item.questionNumText = text.join('; ')
  })
  return arr
}
function getText(type, item) {
  let questionNums = []
  item.map(subItem => {
    if (subItem.numInPaper) {
      questionNums.push(subItem.numInPaper)
    }
  })
  if (type === 'sectionName') {
    let text = item[0].bookName + item[0].sectionName.split('#%#').join('')
    return `${text}: ${questionNums.join('、 ')}`
  } else {
    if (type.length > 2) return `${type}: ${questionNums.join('、 ')}`
    else return `${type}、 ${questionNums.join('、 ')}`
  }
}
