import { updateUserData } from '../types'
import storageServcie from '@/services/storage'
// import store from '@/store'

export default {
  state: {
    data: storageServcie.get('userData') || null
  },
  mutations: {
    // 更新用户数据信息
    [updateUserData](state, payload = null) {
      state.data = payload
      storageServcie.set('userData', payload)
    }
  },
  getters: {
    teacherId: state => {
      if (!state.data) return null
      return state.data.userInfos[0].accountId
    },
    accountId: state => {
      if (!state.data) return null
      return state.data.accountId
    },
    teacherName: state => {
      if (!state.data) return null
      return state.data.userInfos[0].reallyName
    }
  }
}
