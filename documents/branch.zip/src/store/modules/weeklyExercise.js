import { replaceInWeek, updateWeeklyValue, getWeeklyPapers, addWeeklyPageNum, queryWeelyStu, checkWeeklyInfo, assignWeeklyExercise, getPaperDetail, initWeeklyAssign, initWeeklyPaper } from '../types'
import homeworkService from '@/services/homework'

export default {
  state: {
    queryPaperList: { scope: 'shared', teacherId: '', gradeId: '', semester: '', keyWords: '', authority: '', sort: 'createTime,desc', pageNum: 1, pageSize: 5, paperSetType: 'examSet' },
    paperList: [],
    stuData: [],
    groupData: [],
    assignWeekly: { teacherId: '', teacherName: '', examName: '', startTime: '', endTime: '', paperSetId: '', sourceType: 'training', gradeId: '', semester: '', totalScore: '', students: [], questions: [], scope: 'shared', uploadType: null, saveGroup: true },
    hasError: ''
  },
  mutations: {
    [replaceInWeek](state, payload) {
      state[payload.name] = payload.value
    },

    [updateWeeklyValue](state, payload) {
      state[payload.key][payload.name] = payload.value
    },

    [addWeeklyPageNum](state) {
      state.queryPaperList.pageNum += 1
    },

    [initWeeklyPaper](state) {
      state.queryPaperList = { scope: 'shared', teacherId: '', gradeId: '', semester: '', keyWords: '', authority: '', sort: 'createTime,desc', pageNum: 1, pageSize: 5, paperSetType: 'examSet' }
    },

    [initWeeklyAssign](state) {
      state.assignWeekly = { teacherId: '', teacherName: '', examName: '', startTime: '', endTime: '', paperSetId: '', sourceType: 'training', gradeId: '', semester: '', totalScore: '', students: [], questions: [], scope: 'shared', uploadType: null, saveGroup: true }
    },

    // 布置周练检测
    [checkWeeklyInfo](state, payload) {
      state.assignWeekly.students = querySelectStu(state.groupData, state.stuData)
      const oneHour = 60 * 60 * 1000

      if (!state.assignWeekly.examName.trim()) { // 作业名称为空
        state.hasError = 'examName'
      } else if (state.assignWeekly.uploadType === null) { // 没有选择上传方式
        state.hasError = 'noMethod'
      } else if (state.assignWeekly.students.length <= 0) { // 没有选择学生
        state.hasError = 'class'
      } else if (testSameStu(state.assignWeekly.students).length) { // 一人多班
        state.hasError = 'sameStu'
      } else if (state.assignWeekly.endTime - state.assignWeekly.startTime < oneHour) { // 结束时间如果早于开始时间后1小时
        state.hasError = 'endTime'
      } else if (state.assignWeekly.endTime - state.assignWeekly.startTime > 604800000) {
        state.hasError = 'weekLimit'
      } else {
        state.hasError = ''
      }
      if (payload) {
        state.hasError = ''
      }
    }
  },
  actions: {
    // 查询周练列表
    [getWeeklyPapers]({ state, commit, getters }) {
      state.queryPaperList.teacherId = getters.teacherId
      return homeworkService
        .papersetLists(state.queryPaperList).then(res => {
          state.paperList = state.paperList.concat(res.data.items)
          return res
        })
    },

    // 获取学生列表
    [queryWeelyStu]({ dispatch, state, commit, getters }) {
      return homeworkService
        .groupClasses({ teacherId: getters.teacherId }).then(res => {
          state.stuData = reChecked(res.data.classes)
          state.groupData = reCheckGroup(res.data.groups)
          return res
        })
    },

    // 布置周练
    [assignWeeklyExercise]({ state, commit, getters }) {
      state.assignWeekly.teacherId = getters.teacherId
      state.assignWeekly.teacherName = getters.teacherName
      return homeworkService
        .assignPaper(state.assignWeekly)
        .then(res => {
          return Promise.resolve(res.data)
        })
    },

    [getPaperDetail]({ state, commit }, { paperId }) {
      if (!paperId) return Promise.reject()
      homeworkService
        .filtPaper({ paperSetId: paperId }).then(res => {
          state.assignWeekly.questions = res.data
        })
    }
  }
}

function reChecked(arry) {
  let tempArry = []
  if (arry && arry[0]) {
    arry.forEach(v => {
      if (v.classType === 1) {
        v.checked = false
        tempArry.push(v)
      }
    })
  }
  return tempArry
}

function reCheckGroup(arry = []) {
  if (arry && arry.length) {
    arry.forEach((item) => {
      item.checked = false
    })
  }
  return arry
}

function querySelectStu(group = [], student = []) {
  const res = []
  group.forEach(v => {
    if (v.checked) {
      v.students.forEach(s => {
        res.push({
          studentId: s.studentId,
          classId: s.classId,
          className: s.className,
          studentName: s.studentName,
          schoolId: s.schoolId
        })
      })
    }
  })

  student.forEach(v => {
    if (v.checked) {
      v.students.forEach(s => {
        res.push({
          studentId: s.studentId,
          classId: v.classId,
          className: v.className,
          studentName: s.reallyName,
          schoolId: v.schoolId
        })
      })
    }
  })
  return res
}

// 一人多班检测
function testSameStu(stuArry = []) {
  if (stuArry && !stuArry.length) return stuArry
  let tempArry = []
  let sameStuArry = []
  stuArry.forEach(v => {
    if (!tempArry[v.studentId]) {
      tempArry[v.studentId] = true
    } else {
      sameStuArry.push(v)
    }
  })
  return sameStuArry
}
