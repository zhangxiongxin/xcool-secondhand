import { up, questionId, activeIndex, examId, classId, examType, headName, detailName, detailAnswer, initStatus } from '../types'
// import homeworkService from '@/services/homework'

export default {
  state: {
    activeIndex: -1,
    wrongStuList: [],
    rightStuList: [],
    stuListParams: {},
    questionId: '',
    headName: false,
    detailName: true,
    detailAnswer: false,
    examId: '',
    classId: '',
    examType: '',
    up: false
  },
  mutations: {
    [up](state) {
      state.up = !state.up
    },
    [questionId](state, payload) {
      state.questionId = payload
    },
    [examId](state, payload) {
      state.examId = payload
    },
    [classId](state, payload) {
      state.classId = payload
    },
    [examType](state, payload) {
      state.examType = payload
    },
    [activeIndex](state, payload) {
      state.activeIndex = payload
    },
    [headName](state) {
      state.headName = !state.headName
    },
    [detailName](state) {
      state.detailName = !state.detailName
    },
    [detailAnswer](state) {
      state.detailAnswer = !state.detailAnswer
    },
    [initStatus](state) {
      state.headName = false
      state.detailName = true
      state.detailAnswer = false
    }
  },
  actions: {
    // homeworkService
  }
}
