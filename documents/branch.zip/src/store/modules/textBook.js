import { getTextbooks, getSectionItems, textbookTreeClick, bindQuesInSection, replaceInBook, updateBookValue, initTextbook, queryBookStu, checkBookInfo, assignTextbook } from '../types'
import resourceService from '@/services/resource'
import homeworkService from '@/services/homework'

export default {
  state: {
    queryTextbook: { bookType: 'MATERIAL', areaCode: '', name: '', version: '', semester: '', gradeName: '', pageNum: 1, pageSize: 50 },
    textBook: [],
    queryQuestion: { bookId: '', sectionId: '', pageNum: 1, pageSize: 200 },
    questions: [],
    stuData: [],
    groupData: [],
    assignTextbook: { teacherId: '', teacherName: '', examName: '', startTime: '', endTime: '', paperSetId: '', sourceType: 'book', gradeId: '', semester: '', students: [], questions: [], uploadType: null, saveGroup: true },
    hasError: '',
    textBookMap: {}
  },
  mutations: {
    [replaceInBook](state, payload) {
      state[payload.name] = payload.value
    },

    [updateBookValue](state, payload) {
      state[payload.key][payload.name] = payload.value
    },

    // 绑定题目到章节
    [bindQuesInSection](state, payload) {
      findMatchSection(state.textBook, payload, 'add')
    },

    // 初始化数据
    [initTextbook](state) {
      state.queryTextbook = { bookType: 'MATERIAL', areaCode: '', name: '', version: '', semester: '', gradeName: '', pageNum: 1, pageSize: 50 }
      state.textBook = []
      state.queryQuestion = { bookId: '', sectionId: '', pageNum: 1, pageSize: 200 }
      state.questions = []
      state.stuData = []
      state.groupData = []
      state.assignTextbook = { teacherId: '', teacherName: '', examName: '', startTime: '', endTime: '', paperSetId: '', sourceType: 'book', gradeId: '', semester: '', students: [], questions: [], uploadType: null, saveGroup: true }
    },

    // 布置教辅检查
    [checkBookInfo](state, payload) {
      // todo 检查自组合
      state.assignTextbook.students = querySelectStu(state.groupData, state.stuData)
      const oneHour = 60 * 60 * 1000

      if (!state.assignTextbook.examName.trim()) { // 作业名称为空
        state.hasError = 'examName'
      } else if (state.assignTextbook.uploadType === null) { // 没有选择上传方式
        state.hasError = 'noMethod'
      } else if (state.assignTextbook.students.length <= 0) { // 没有选择学生
        state.hasError = 'class'
      } else if (testSameStu(state.assignTextbook.students).length) { // 一人多班
        state.hasError = 'sameStu'
      } else if (state.assignTextbook.endTime - state.assignTextbook.startTime < oneHour) { // 结束时间如果早于开始时间后1小时
        state.hasError = 'endTime'
      } else if (state.assignTextbook.endTime - state.assignTextbook.startTime > 604800000) {
        state.hasError = 'weekLimit'
      } else {
        state.hasError = ''
      }
      if (payload) {
        state.hasError = ''
      }
    }
  },
  actions: {
    // 获取教辅树
    [getTextbooks]({ state }, payload) {
      return resourceService
        .querySectionV2(state.queryTextbook)
        .then(res => {
          // 构造教辅map，用于判断是否为假期作业教辅
          state.textBookMap = buildTextBookMap(res.data.items)

          // 两次教辅进行比较，判断是否有更新，有则全部替换
          let newBooks = deDuplicateBook(state.textBook, res.data.items)
          if (newBooks) state.textBook = resetTextbook(res.data.items)
          return res
        })
    },

    // 获取章节下面题目信息
    [getSectionItems]({ state, commit }, payload) {
      if (!payload.sectionId || !payload.bookId) return
      state.queryQuestion.bookId = payload.bookId
      state.queryQuestion.sectionId = payload.sectionId

      return homeworkService
        .getTextbookQuestions(state.queryQuestion)
        .then(res => {
          // 重构的题目信息，用于布置作业
          let resetQuesArry = resetQuestion(res.data.items, payload)

          // 数据去重，暂未找到偶先数据重复的原因-_-
          let deDupArry = deDuplication(state.questions, resetQuesArry)
          state.questions = state.questions.concat(deDupArry)

          // 过滤的题目信息，用于教辅树题目显示 (同时给 state.questions 上面的题目数据添加 indexInSection 字段用于标识在教辅树中的位置)
          let filtQuesArry = filtQuestion(res.data.items, payload)
          let param = { bookId: payload.bookId, sectionId: payload.sectionId, arry: filtQuesArry, oriQuestions: state.questions }
          commit(bindQuesInSection, param)

          // 根据添加的 indexInSection 排序
          state.questions.sort(function(a, b) {
            return a.indexInSection - b.indexInSection
          })

          return res
        })
    },

    // 教辅树点击事件（改变checked属性）
    [textbookTreeClick]({ state }, payload) {
      // 判定是否跨教辅布置作业
      let judgeResult = judgeCrossAssign(payload, state.questions)
      if (judgeResult) return Promise.reject()

      findMatchSection(state.textBook, payload, 'change')
      state.questions.forEach(v => {
        if (payload.singleClick && v.questionId === payload.questionId && v.sectionId === payload.sectionId) {
          v.selected = payload.checked
        } else if (!payload.singleClick && v.sectionId === payload.sectionId) {
          v.selected = payload.checked
        }
      })
    },

    // 获取老师所教学生
    [queryBookStu]({ dispatch, state, getters }) {
      return homeworkService
        .groupClasses({ teacherId: getters.teacherId }).then(res => {
          state.stuData = reChecked(res.data.classes)
          state.groupData = reCheckGroup(res.data.groups)
          return res
        })
    },

    // 教辅布置作业
    [assignTextbook]({ state, commit, getters }) {
      state.assignTextbook.teacherId = getters.teacherId
      state.assignTextbook.teacherName = getters.teacherName
      return homeworkService
        .assignPaper(state.assignTextbook)
        .then(res => {
          return res
        })
    }
  }
}

// 教辅列表判断是否有更新
function deDuplicateBook(oriBook = [], newBook = []) {
  let tempArry1 = []
  let tempArry2 = []
  for (let i = 0; i < oriBook.length; i++) {
    tempArry1.push(oriBook[i].bookId)
  }
  for (let i = 0; i < newBook.length; i++) {
    tempArry2.push(newBook[i].bookId)
  }
  if (tempArry1.length !== tempArry2.length) return true
  else if (tempArry1.sort().join() !== tempArry2.sort().join()) return true
  else return false
}

// 重构教辅树
function resetTextbook(arry = []) {
  var stack = [].concat([].concat(arry).reverse())
  var current
  var i = 0
  while (stack.length) {
    current = stack.pop()
    current.index = i
    i++
    if (!current.sections) current.sections = []
    if (current.bookName) current.sectionName = current.bookName

    if (current.sections.length) {
      current.sections.forEach(item => {
        item.parent = [current.sectionName].concat(current.parent || [])
      })
      stack = stack.concat([].concat(current.sections).reverse())
    } else {
      current.position = 'sectionLeaf'
      current.canClick = true
      current.checked = false
    }
  }
  return arry
}

// 重构题目数据
function resetQuestion(arry = [], obj) {
  if (arry && arry.length !== 0) {
    arry.forEach(v => {
      // 由于同一节下面出现了同一道题，前端布置时去重后端不知道前端取消的哪一道，特加 index 字段标志（教辅的作者问题，谁叫他同一节出现相同的题）
      v.index = v.indexInPaper

      v.sectionId = obj.sectionId
      v.bookId = obj.bookId

      // 后端接口需要。不能删除
      v.sectionIndex = obj.sectionIndex

      v.sectionArry = [].concat([].concat(obj.parent).reverse()).concat(obj.sectionName)
      v.selected = false
      v.showDetail = false
    })
  }
  return arry
}

// 题目信息数组去重
function deDuplication(oriArry = [], newArry = []) {
  let tempArry1 = []
  let tempArry2 = []
  for (let i = 0; i < oriArry.length; i++) {
    tempArry1[oriArry[i].questionId + oriArry[i].sectionId] = true
  }
  for (let i = 0; i < newArry.length; i++) {
    if (!tempArry1[newArry[i].questionId + newArry[i].sectionId]) {
      tempArry2.push(newArry[i])
    }
  }
  return tempArry2
}

// 过滤题目部分信息用于绑定教辅树
function filtQuestion(arry = [], obj) {
  const quesArry = []
  if (arry && arry.length !== 0) {
    arry.forEach(v => {
      quesArry.push({
        sectionId: obj.sectionId,
        bookId: obj.bookId,
        questionId: v.questionId,
        sectionName: v.numInPaper,
        checked: false,
        canClick: true
      })
    })
  }
  return quesArry
}

// 查找匹配章节并添加题目数据
function findMatchSection(arry, obj, sign) {
  let sta = [].concat([].concat(arry).reverse())
  let cur
  while (sta.length) {
    cur = sta.pop()
    if (cur.sections.length && cur.position !== 'sectionLeaf') {
      sta = sta.concat([].concat(cur.sections).reverse())
    }
    if (cur.sectionId === obj.sectionId && cur.bookId === obj.bookId) {
      // 添加数据用
      if (sign === 'add') {
        cur.sections = obj.arry

        // 给原始数据添加 indexInSection 字段用于标识该题在教辅树中的位置
        cur.sections.forEach((item, i) => {
          if (!obj.oriQuestions.length) return

          obj.oriQuestions.forEach(v => {
            if (item.bookId === v.bookId && item.sectionId === v.sectionId && item.questionId === v.questionId && item.sectionName === v.numInPaper) v.indexInSection = cur.index * 10000 + i
          })
        })
      }

      // 改变状态用
      if (sign === 'change') {
        if (obj.singleClick) {
          cur.sections.forEach(v => {
            if (v.questionId === obj.questionId) v.checked = !obj.checked
          })
          if (!notCheckAll(cur.sections)) cur.checked = true
          else cur.checked = false
        } else {
          cur.checked = !obj.checked
          cur.sections.forEach(v => {
            v.checked = cur.checked
          })
        }
      }
      break
    }
  }
}

// 判断数组是否全部选中
function notCheckAll(arry) {
  return arry.some(v => !v.checked)
}

function reChecked(arry) {
  let tempArry = []
  if (arry && arry[0]) {
    arry.forEach(v => {
      if (v.classType === 1) {
        v.checked = false
        tempArry.push(v)
      }
    })
  }
  return tempArry
}

function reCheckGroup(arry = []) {
  if (arry && arry.length) {
    arry.forEach((item) => {
      item.checked = false
    })
  }
  return arry
}

function querySelectStu(group = [], student = []) {
  const res = []
  group.forEach(v => {
    if (v.checked) {
      v.students.forEach(s => {
        res.push({
          studentId: s.studentId,
          classId: s.classId,
          className: s.className,
          studentName: s.studentName,
          schoolId: s.schoolId
        })
      })
    }
  })

  student.forEach(v => {
    if (v.checked) {
      v.students.forEach(s => {
        res.push({
          studentId: s.studentId,
          classId: v.classId,
          className: v.className,
          studentName: s.reallyName,
          schoolId: v.schoolId
        })
      })
    }
  })
  return res
}

// 一人多班检测
function testSameStu(stuArry = []) {
  if (stuArry && !stuArry.length) return stuArry
  let tempArry = []
  let sameStuArry = []
  stuArry.forEach(v => {
    if (!tempArry[v.studentId]) {
      tempArry[v.studentId] = true
    } else {
      sameStuArry.push(v)
    }
  })
  return sameStuArry
}

// 判定是否跨教辅点击（根据bookId）
function judgeCrossAssign(obj, arry = []) {
  let selectQues = arry.filter(item => {
    return item.selected === true
  })
  if (selectQues && selectQues.length && obj.bookId !== selectQues[0].bookId) return true
  else return false
}

// 构造教辅树map（bookId --> privilegeId）
function buildTextBookMap(arry = []) {
  if (!arry.length) return {}
  else {
    let tempMap = {}
    arry.forEach(item => {
      tempMap[item.bookId] = item.privilegeId
    })
    return tempMap
  }
}
