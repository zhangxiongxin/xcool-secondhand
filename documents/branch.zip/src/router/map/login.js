// 登录路由
const login = r => require.ensure([], () => r(require('@/views/login')), 'login')

export default {
  name: 'login',
  path: '/login',
  component: login,
  meta: {
    requiresAuth: false
  }
}
