const mindMap = r => require.ensure([], () => r(require('@/views/mindMap')), 'mindMap')
console.log(mindMap)
export default {
  name: 'mindMap',
  path: '/mindMap',
  component: mindMap
}
