const survey = r => require.ensure([], () => r(require('@/views/survey')), 'survey')
const qualitySurvey = r => require.ensure([], () => r(require('@/views/survey/qualitySurvey')), 'survey')

export default {
  name: 'survey',
  path: '/survey',
  component: survey,
  meta: {
    requiresAuth: false
  },
  children: [{
    path: 'quality/:classId/:studentId/:status',
    component: qualitySurvey,
    meta: {
      requiresAuth: false
    }
  }]
}
