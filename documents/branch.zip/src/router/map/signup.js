// 登录路由
const signup = r => require.ensure([], () => r(require('@/views/signup/index')), 'signup')
const reg = r => require.ensure([], () => r(require('@/views/signup/reg')), 'signup')
const submit = r => require.ensure([], () => r(require('@/views/signup/submit')), 'signup')

export default {
  name: 'reg',
  path: '/reg',
  component: signup,
  meta: {
    requiresAuth: false
  },
  children: [{
    name: 'reg',
    path: '',
    component: reg,
    meta: {
      background: '#F0F4F5',
      requiresAuth: false
    }
  }, {
    name: 'submit',
    path: 'submit',
    component: submit,
    meta: {
      background: '#29B8FF',
      requiresAuth: false
    }
  }]
}
