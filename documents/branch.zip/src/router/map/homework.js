const homework = r => require.ensure([], () => r(require('@/views/homework')), 'homework')
  // 校内作业
const assignment = r => require.ensure([], () => r(require('@/views/homework/assignment')), 'assignment')
  // 报告
const workpaper = r => require.ensure([], () => r(require('@/views/homework/workpaper')), 'workpaper')
  // 学生答案
const distribution = r => require.ensure([], () => r(require('@/views/homework/distribution')), 'distribution')
  // 布置作业首页
const arrangement = r => require.ensure([], () => r(require('@/views/homework/arrangement')), 'homework')
const arrangeHome = r => require.ensure([], () => r(require('@/views/homework/arrangement/home')), 'homework')
  // 布置周练
const weeklyHome = r => require.ensure([], () => r(require('@/views/homework/arrangement/weeklyExercise')), 'homework')
const weeklyStep1 = r => require.ensure([], () => r(require('@/views/homework/arrangement/weeklyExercise/step1')), 'homework')
const weeklyStep2 = r => require.ensure([], () => r(require('@/views/homework/arrangement/weeklyExercise/step2')), 'homework')
  // 布置套题
const paperSetHome = r => require.ensure([], () => r(require('@/views/homework/arrangement/paperSet')), 'homework')
const paperSetStep1 = r => require.ensure([], () => r(require('@/views/homework/arrangement/paperSet/step1')), 'homework')
const paperSetStep2 = r => require.ensure([], () => r(require('@/views/homework/arrangement/paperSet/step2')), 'homework')
  // 布置教辅
const textBookHome = r => require.ensure([], () => r(require('@/views/homework/arrangement/textBook')), 'homework')
const textBookStep1 = r => require.ensure([], () => r(require('@/views/homework/arrangement/textBook/step1')), 'homework')
const textBookStep2 = r => require.ensure([], () => r(require('@/views/homework/arrangement/textBook/step2')), 'homework')

// 套题/试卷 详情
const questionsDetail = r => require.ensure([], () => r(require('@/views/homework/arrangement/questionsDetail')), 'homework')

export default {
  name: 'homework',
  path: '/homework',
  redirect: '/homework/assignment',
  component: homework,
  children: [{
    name: 'workpaper',
    path: 'workpaper/:examId/:reportType/:examName',
    component: workpaper
  }, {
    name: 'assignment',
    path: 'assignment',
    component: assignment
  }, {
    name: 'distribution',
    path: 'distribution/:classId/:examId/:questionId/:index/:examType/:subQuestionId',
    component: distribution
  }, {
    path: 'arrangement',
    component: arrangement,
    redirect: '/homework/arrangement/arrangeHome',
    children: [{
      path: 'arrangeHome',
      component: arrangeHome
    }, {
      name: 'questionsDetail',
      path: 'questionsDetail',
      component: questionsDetail
    }, {
      path: 'weeklyExercise',
      component: weeklyHome,
      redirect: '/homework/arrangement/weeklyExercise/step1',
      children: [{
        path: 'step1',
        component: weeklyStep1
      }, {
        path: 'step2/:id',
        component: weeklyStep2
      }]
    }, {
      path: 'paperSet',
      component: paperSetHome,
      redirect: '/homework/arrangement/paperSet/step1',
      children: [{
        path: 'step1',
        component: paperSetStep1
      }, {
        path: 'step2/:id',
        component: paperSetStep2
      }]
    }, {
      path: 'textBook',
      component: textBookHome,
      redirect: '/homework/arrangement/textBook/step1',
      children: [{
        path: 'step1',
        component: textBookStep1
      }, {
        path: 'step2/:type?',
        component: textBookStep2
      }]
    }]
  }]
}
