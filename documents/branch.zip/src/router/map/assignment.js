const assignment = r => require.ensure([], () => r(require('@/views/homework/assignment')), 'assignment')

export default {
  name: 'assignment',
  path: '/homework/assignment',
  component: assignment
}
