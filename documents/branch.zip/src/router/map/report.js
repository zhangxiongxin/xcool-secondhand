const report = r => require.ensure([], () => r(require('@/views/report')), 'report')
const examReport = r => require.ensure([], () => r(require('@/views/report/examReport')), 'report')
const homeworkReport = r => require.ensure([], () => r(require('@/views/report/homeworkReport')), 'report')
const weekReport = r => require.ensure([], () => r(require('@/views/report/weekReport')), 'report')
const qualityReport = r => require.ensure([], () => r(require('@/views/report/qualityReport')), 'report')
const knowledgeReport = r => require.ensure([], () => r(require('@/views/report/knowledgeReport')), 'report')

// 综合能力报告
const comprehensiveRead = r => require.ensure([], () => r(require('@/views/report/comprehensive')), 'report')
// 错题订正报告
const errorCorrectReport = r => require.ensure([], () => r(require('@/views/report/errorCorrectReport')), 'report')
// 错题周提炼报告
const cycleRefinement = r => require.ensure([], () => r(require('@/views/report/cycleRefinement')), 'report')
// 学豆使用详情
const detailReport = r => require.ensure([], () => r(require('@/views/report/detailReport')), 'report')
// 充值记录
const rechargeReport = r => require.ensure([], () => r(require('@/views/report/rechargeReport')), 'report')
// 兑换记录
const exchangeReport = r => require.ensure([], () => r(require('@/views/report/exchangeReport')), 'report')
// 知识点图谱
const knowledgeMap = r => require.ensure([], () => r(require('@/views/report/knowledgeMap')), 'report')
// 微信知识点图谱
const wxKnowledgeMap = r => require.ensure([], () => r(require('@/views/report/wxKnowledgeMap')), 'report')
export default {
  name: 'report',
  path: '/report',
  component: report,
  meta: {
    requiresAuth: false
  },
  children: [{
    path: 'homework/:studentId/:examId/:classId',
    component: homeworkReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'exam/:studentId/:examId/:classId',
    component: examReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'quality/:studentId',
    component: qualityReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'knowledge/:id',
    component: knowledgeReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'knowledgeMap/:id',
    component: knowledgeMap,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'wxKnowledgeMap/:id',
    component: wxKnowledgeMap,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'comprehensive/:reportId',
    component: comprehensiveRead,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'homework/personalReport/weekly/:studentId/:examId/:classId',
    component: weekReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'errorCorrectReport/:studentId/:classId?',
    component: errorCorrectReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'cycleRefinement/:studentId/:examId/:classId?',
    component: cycleRefinement,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'mgt/recharge/:studentId',
    component: rechargeReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'mgt/detail/:studentId',
    component: detailReport,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'mgt/exchange/:studentId',
    component: exchangeReport,
    meta: {
      requiresAuth: false
    }
  }]
}
