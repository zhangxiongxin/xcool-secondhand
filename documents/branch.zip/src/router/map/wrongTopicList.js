const wrongTopicList = r => require.ensure([], () => r(require('@/views/wrongTopicList')), 'wrongTopicList')
const knowledgeList = r => require.ensure([], () => r(require('@/views/wrongTopicList/knowledgeList')), 'wrongTopicList')
const wrongDetail = r => require.ensure([], () => r(require('@/views/wrongTopicList/wrongDetail')), 'wrongTopicList')

export default {
  name: 'wrongTopicList',
  path: '/wrongTopicList',
  component: wrongTopicList,
  meta: {
    requiresAuth: false
  },
  children: [{
    path: 'knowledgeList/:date',
    component: knowledgeList,
    meta: {
      requiresAuth: false
    }
  }, {
    path: 'wrongDetail',
    component: wrongDetail,
    meta: {
      requiresAuth: false
    }
  }]
}
