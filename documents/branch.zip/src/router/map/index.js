
import survey from './survey'

import report from './report'
import errorquestion from './errorquestion'

import signup from './signup'
import loginRoutes from './login'
import homework from './homework'
import homepage from './homepage'
import mindMap from './mindMap'
import wrongTopicList from './wrongTopicList'
let homeRoute = {
  name: 'home',
  path: '/',
  redirect: '/login'
}

let notFoundRoute = {
  name: 'NotFound',
  path: '*',
  meta: {
    requiresAuth: false
  },
  component: require('@/views/404')
}

export default [
  signup,
  homeRoute,
  loginRoutes,
  survey,
  report,
  homework,
  homepage,
  mindMap,
  errorquestion,
  notFoundRoute,
  wrongTopicList
]
