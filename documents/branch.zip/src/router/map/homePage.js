const homepage = r => require.ensure([], () => r(require('@/views/homepage')), 'homepage')

export default {
  name: 'homepage',
  path: '/homepage',
  component: homepage
}
