const errorQuestion = r => require.ensure([], () => r(require('@/views/errorquestion')), 'errorquestion')

export default {
  name: 'errorquestion',
  path: '/errorquestion',
  component: errorQuestion,
  meta: {
    requiresAuth: false
  }
}
