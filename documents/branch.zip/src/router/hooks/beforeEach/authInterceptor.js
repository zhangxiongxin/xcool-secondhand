import store from '@/store'

// 权限拦截
export default function(router) {
  return (to, from, next) => {
    const userData = store.state.user.data

    // 这儿稍微有点trick, undefined 是 app 还没初始化好, 路由先行了，所以再来一次
    if (userData === undefined) return setTimeout(() => next(to.fullPath), 250)

    const accessToken = userData && userData.accessToken

    // requiresAuth: 需要登录后访问; forbidAuthed: 禁止登录后访问
    let { requiresAuth, forbidAuthed } = to.meta
    // 强匹配模式，默认全部都需要登陆的授权，除非传一个布尔的false
    if (typeof requiresAuth !== 'boolean') requiresAuth = true
    if (requiresAuth && !accessToken) {
      return next({
        path: '/login',
        query: { referrer: to.fullPath },
        force: true // 禁用追加模式
      })
    }
    if (forbidAuthed && accessToken) {
      return next(false)
    }
    next()
    document.body.scrollTop = 0
    document.body.style.background = to.meta.background || '#fff'
  }
}
