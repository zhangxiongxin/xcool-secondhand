var context = require.context('./icon', true, /\.(svg)$/)
var files = {}

function getName(name) {
  var slash = name.lastIndexOf('/')
  return name.substring(slash + 1, name.length - 4)
}
// 遍历目录引入Icon内容
context.keys().forEach((filename) => {
  var key = getName(filename)
  files[key] = context(filename).default
})

export default files
