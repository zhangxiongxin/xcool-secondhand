import { fileServer } from 'config/app'
import storage from '@/services/storage'
const reg = /^http(s?):\/\/(.+)\.(.+)/

export default function remoteFile(str, isHeadImg) {
  str = (str || '').trim()

  // 默认头像
  if (!str) return ''
  if (!reg.test(str)) str = fileServer + str
  let userData = storage.get('userData') || {}
  let accessToken = userData.accessToken || getQueryParams().access_token
  if (accessToken) accessToken = 'access_token=' + window.encodeURIComponent(accessToken)
  if (!accessToken) return str

  return str + (str.indexOf('?') !== -1 ? '&' : '?') + accessToken
}
// 获取查询参数解析器，例如：传 "?page=12&list=20" 返回对象 {page:'12',list:'20'}
function getQueryParams(url) {
  url = url || window.location.href
  let search = url.substring(url.lastIndexOf('?') + 1)
  let res = {}
  search.replace(/([^?&=]+)=([^?&=]*)/g, function(rs, $1, $2) {
    res[decodeURIComponent($1)] = String(decodeURIComponent($2))
    return rs
  })
  return res
}
