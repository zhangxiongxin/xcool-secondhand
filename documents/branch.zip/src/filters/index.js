import remoteFile from './remoteFile'
import date from './date'
import { rechargeStatus, rechargeType, toFixedOne, bigQuestionQid, questionType, localNum, countItemNum, rateFilter } from './doudou'

const filters = {
  remoteFile,
  date,
  questionType,
  localNum,
  countItemNum,
  rateFilter,
  bigQuestionQid,
  toFixedOne,
  rechargeType,
  rechargeStatus
}

import Vue from 'vue'
Object.keys(filters).forEach(k => Vue.filter(k, filters[k]))
