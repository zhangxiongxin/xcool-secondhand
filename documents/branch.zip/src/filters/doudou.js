const questionTypeMap = {
  choice: '单选题',
  mutichoice: '多选题',
  judge: '判断题',
  fillin: '填空题',
  solution: '解答题',
  calculation: '计算题'
}
// 充值方式
const rechargeTypeMap = ['支付宝', '支付宝代付', '微信', '微信代付', '线下']
// 充值状态
const rechargeStatusMap = ['待付款', '充值中', '充值成功', '充值失败', '充值超时']
export function rechargeType(str) {
  let num = Number(str)
  return rechargeTypeMap[num - 1]
}
export function rechargeStatus(str) {
  let num = Number(str)
  return rechargeStatusMap[num - 1]
}
export function questionType(str, onlyStr) {
  str = str.toString().toLowerCase().trim().replace(/_(.+)/g, (a, b, c) => {
    return b
  })
  if (onlyStr) return str
  return questionTypeMap[str] || str
}

export function localNum(num) {
  // UC兼容性判断
  if (window.navigator.userAgent.indexOf('UCBrowser')) {
    const qsTitle = ['一', '二', '三']
    return qsTitle[num - 1]
  } else return num.toLocaleString('zh-Hans-CN-u-nu-hanidec')
}

export function countItemNum(arry) {
  return arry.length
}

export function rateFilter(num) {
  if (typeof num === 'number') {
    num = Math.abs(num)
    const str = (num * 100) + ''
    return Math.round(str) + '%'
  } else return num
}

export function difficulty(num) {
  if (num >= 0.01 && num < 0.185) return 1
  else if (num >= 0.185 && num < 0.361) return 2
  else if (num >= 0.361 && num < 0.536) return 3
  else if (num >= 0.536 && num < 0.773) return 4
  else if (num >= 0.773 && num <= 1) return 5
  else if (num > 1) return 1
  else return 0
}
// 大题题号处理
export function bigQuestionQid(typeArr, questionType) {
  const bigQuestionNum = ['一', '二', '三']
  typeArr = Array.from(new Set(typeArr)).sort()
  for (let j in typeArr) {
    if (questionType === typeArr[j]) {
      return bigQuestionNum[j]
    }
  }
}
// 带圈的数字
export function ringNumber(index, text) {
  // const number = ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩', '⑪', '⑫', '⑬', '⑭', '⑮', '⑯', '⑰', '⑱', '⑲', '⑳']
  // return number[index] + ' ' + text
  return (index + 1) + '、' + text + ' \t'
}
export function dateCompatible(str) {
  return str.split('-').join('/')
}
// 个人教辅去掉#%#
export function deleteSpaceMark(data) {
  if (typeof data !== 'string') return data
  let arr = data.split('#%#')
  let result = arr.join(' ')
  return result
}
// toFixedOne
// 不是整数保留一位小数。否则返回整数
export function toFixedOne(num) {
  if (typeof num !== 'number') num = num * 1
  if (num % 1 === 0) return num
  else return num.toFixed(1)
}
