/**
 * 滚动到底部加载更多
 */
export default function scroll(callBack1, callBack2) {
  let timer
  window.addEventListener('scroll', () => {
    callBack1()
    let scrollHeight = document.documentElement.scrollHeight
    if (window.pageYOffset + window.innerHeight >= scrollHeight) {
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => {
        callBack2()
      }, 500)
    }
  }, false)
}
