/**
 * 报告数据以不同的颜色来区分正确率或得分等最后3名
 * val ==> 需要区分的数据，field区分字段, con1,2 条件限制
 */
export default function colorDistinguish(val, field, con1, con2) {
  let arr = []
  val.forEach((item) => {
    if (con1) {
      if (typeof item[field] === 'number') {
        arr.push(item[field])
      }
    } else arr.push(item[field])
  })
  arr = Array.from(new Set(arr)).sort((a, b) => {
    return a - b
  })
  val.forEach((item) => {
    if (con1) {
      if (item[con1] === con2) handleData(arr, item, field)
    } else handleData(arr, item, field)
  })
}
function handleData(item, data, field) {
  switch (data[field]) {
    case item[0]:
      data.accuracyClass = 'rank-level-less'
      break
    case item[1]:
      data.accuracyClass = 'rank-level'
      break
    case item[2]:
      data.accuracyClass = 'rank-level-more'
      break
  }
}
