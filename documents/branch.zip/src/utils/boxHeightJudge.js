/**
 * 容器高度稳定性判断：判断盒子稳定(高度不再改变)后执行回调函数
 * 适用于容器中图片加载时导致容器高度不稳定的场景
 * 参数：内容DOM, 回调函数, 回调函数的参数(多个使用数组)
*/
let timer = null

export default function boxHeightJudge(contentDom, callBack, params) {
  let nowHeight, lastHeight
  if (timer) clearInterval(timer)
  timer = setInterval(() => {
    nowHeight = contentDom.clientHeight
    if (nowHeight === lastHeight) {
      clearInterval(timer)
      if (Array.isArray(params)) callBack(...params)
      else callBack(params)
    } else {
      lastHeight = contentDom.clientHeight
    }
  }, 300)
}
