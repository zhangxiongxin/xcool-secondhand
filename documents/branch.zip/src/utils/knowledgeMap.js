// 知识点图谱正确率对应的颜色
const color = ['#FFC83E', '#FFBC3B', '#FFB237', '#FFA833', '#FF9E31', '#FF942E', '#FF8B2A', '#FF8129', '#FF7624', '#FF6D22', '#FF611F', '#FF561B', '#FF4D19', '#FF4316', '#FF3811', '#FF2E0E', '#FF250A', '#FF1A08', '#FF1006', '#FF0602']
const colorMap = ['#FFDF40', '#FFD13E', '#FFCB39', '#FFC033', '#FFC033', '#FFBB33', '#FFC32E', '#FFBE2E', '#FFBC27', '#FFB624', '#FFAA22', '#FF9E1D', '#FF971A', '#FF9017', '#FF8212', '#FF7C10', '#FF730B', '#FF6E0B', '#FF6008', '#FF5F06']
// 知识点图谱的知识点等级对应额度大小
const size = [90, 60, 30]
// 图例距离容器顶部的距离
const toTop = 300
// 设置数据点
function setNode(data) {
  return data.map((item) => {
    let level = item.level || 3
    let colorLevel = Math.floor(Math.round(item.accuracy * 100) / 5)
    if (colorLevel === 20) colorLevel--
    return {
      id: item.knowledgePointId,
      accuracy: item.accuracy,
      lastAccuracy: item.lastAccuracy,
      parentId: item.parentId,
      newLearn: item.newLearn,
      name: item.knowledgePointName,
      value: Math.round(item.accuracy * 100),
      symbolSize: size[level - 1],
      level: level,
      label: {
        normal: {
          show: level === 1,
          textBorderColor: '#ffffff',
          textBorderWidth: 0,
          fontSize: 15
        }
      },
      itemStyle: {
        normal: {
          color: {
            type: 'radial',
            x: 0.3,
            y: 0.4,
            colorStops: [{
              offset: 0,
              color: colorMap[colorLevel] || colorMap[19]
            }, {
              offset: 1,
              color: color[colorLevel] || colorMap[19]
            }]
          }
        }
      }
    }
  })
}
/**
 * 设置图例的样式
 * @method   setSeries
 * @author   liulei
 * @dateTime 2018-01-19T17:09:27+0800
 * @param    {[type]}                 item  [数据]
 * @param    {[type]}                 index [单个series表示知识点等级，多个series表示索引]
 * @param    {[type]}                 type  [类型， 1单个，否则多个]
 */
function setSeries(item, index, type) {
  if (type === 1) {
    let arr = [3, 2, 1]
    let level = index || 3
    return {
      // 一个series
      type: 'graph',
      layout: 'force',
      roam: true,
      force: {
        repulsion: 80 * arr[level - 1],
        edgeLength: 60 * arr[level - 1]
      },
      lineStyle: {
        normal: {
          color: '#999',
          width: 2
        }
      },
      hoverAnimation: true,
      focusNodeAdjacency: true,
      draggable: true,
      data: [],
      links: [],
      width: '100%',
      height: '100%'
    }
  } else {
    // 多个series
    let top = index * toTop
    return {
      type: 'graph',
      layout: 'force',
      roam: true,
      force: {
        repulsion: 100,
        edgeLength: 100
      },
      lineStyle: {
        normal: {
          color: '#999',
          width: 3
        }
      },
      hoverAnimation: true,
      focusNodeAdjacency: true,
      draggable: true,
      data: [],
      links: [],
      width: '100%',
      height: toTop,
      top: top
    }
  }
}
export default {
  setNode: setNode,
  setSeries: setSeries
}
