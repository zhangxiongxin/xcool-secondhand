import xhr from '@/services/xhr'
import ajax from '@/services/ajax'

class ReportService {
  // 老师端知识分析报告查询
  knowAnalyDetail(body, fn, error) {
    return ajax('studying/dd/v1/reports/knowledge/analysis/detail/:studentId/:examId', { method: 'GET', body }, fn, error, 'get')
  }

  // 素质分析报告查询
  qualityReport(body, fn) {
    return ajax('studying/dd/v1/reports/quality/:studentId', { method: 'GET', body }, fn, null, 'get')
  }

  // 查看综合能力报告
  comprehensiveDetail(body, fn) {
    return ajax('/studying/dd/reports/v1/comment/detail/:reportId', { method: 'GET', body }, fn, null, 'get')
  }

  // 查看个人错题订正报告
  errorCorrectReport(body) {
    return xhr('teaching/dd/v1/report/revise/class/student', { method: 'GET', body })
  }

  // 个人错题订正报告-排名信息
  getTopTen(body) {
    return xhr('teaching/dd/v1/report/revise/class/more', { method: 'GET', body })
  }
  // 获取四级知识点
  getKnowledgeFour(body) {
    return xhr('studying/dd/student/knowledge/search/:studentId', { method: 'GET', body })
  }
  // 根据学段查询二级知识点列表
  getKnowledgeTwo(body) {
    return xhr('studying/dd/student/knowledge/second/list/:learnPeriod', { method: 'GET', body })
  }
  // 获取易错题列表
  getWrongLists(body) {
    return xhr('studying/dd/fallible/question/list/:knowledgeIds', { method: 'GET', body })
  }
  // 查询易错题详情
  getWrongDetail(body) {
    return xhr('studying/dd/fallible/question/detail/:recordId', { method: 'GET', body })
  }
  // 记录易错题下载人数
  recordCount(body) {
    return xhr('studying/dd/fallible/question/download/:recordId', { method: 'GET', body })
  }
}

export default new ReportService()
