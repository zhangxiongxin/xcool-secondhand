import xhr from '@/services/xhr'

class HomeworkService {

  // 作业-工单详情查询
  getTaskDetail(body) {
    return xhr('job/check/exercise/v1/tasks/:taskId', { method: 'GET', body })
  }

  // 布置作业套题列表查询
  queryPaperList(body) {
    return xhr('teaching/dd/v1/papersets/:teacherId/list', { method: 'GET', body })
  }

  // 布置作业套题详情查询
  queryPaperDetail(body) {
    return xhr('teaching/dd/v1/papersets/:paperSetId', { method: 'GET', body })
  }

  // 查询老师所教班级学生和学生作业情况
  queryStuList(body) {
    return xhr('teaching/homework/v1/classes/students/:teacherId', { method: 'GET', body })
  }

  // 查询老师所教班级学生v2(布置作业专用，与上面接口返回信息一致)
  queryStuListV2(body) {
    return xhr('teaching/homework/v1/teachers/:teacherId', { method: 'GET', body })
  }

  // 自组合学生和班级学生查询
  groupClasses(body) {
    return xhr('teaching/homework/v1/groups-classes', { method: 'GET', body })
  }

  // 学生作业列表查询
  getHWList(body) {
    return xhr('teaching/homework/v2/:studentId/list', { method: 'GET', body })
  }

  // 套题中题目查询过滤
  filtPaper(body) {
    return xhr('teaching/dd/v1/papersets/question/:paperSetId', { method: 'GET', body })
  }

  // 作业布置
  assignPaper(body) {
    return xhr('teaching/dd/v1/homework/save', { method: 'POST', body }, { noAlert: true })
  }

  // PDF下载
  downloadPdf(body) {
    return xhr('teaching/dd/v1/homework/download/:examId', { method: 'GET', body })
  }

  // 作业-开始批阅
  beginCheck(body) {
    return xhr('job/check/exercise/v1/tasks/check/begin', { method: 'GET', body })
  }

  // 作业-按题提交批阅
  submitQuestion(body) {
    return xhr('job/check/exercise/v1/question/submit', { method: 'POST', body })
  }

  // 查询单个学生和作业信息
  QueryStuExam(body) {
    return xhr('teaching/homework/v2/student/questions/detail', { method: 'GET', body })
  }

  // 作业名称判重
  renameHomework(body) {
    return xhr('teaching/dd/v1/homework/re-name?name=:name', { method: 'GET', body })
  }

  // 撤回作业
  revokeHomework(body) {
    return xhr('teaching/dd/v1/homework/revoke', { method: 'POST', body })
  }

  // 布置历史-作业详情(多个学生)
  historyDetail(body) {
    return xhr('teaching/homework/v3/exerhome/history/detail', { method: 'GET', body })
  }

  // pdf重新生成
  rebuildPDF(body) {
    return xhr('teaching/dd/v1/homework/pdf/rebuild/:examId', { method: 'POST', body })
  }

  // 布置历史列表查询
  historyList(body) {
    return xhr('teaching/dd/v1/homework/assign-history/list/:teacherId', { method: 'GET', body })
  }
    // 作业列表查询
  homeworkList(body) {
    return xhr('teaching/dd/v1/homework/list', { method: 'GET', body })
  }
  homeworkListExtra(body) {
    return xhr('teaching/dd/v1/homework/list/extra', { method: 'GET', body })
  }
    // 布置历史-查看学生名单
  historyListStu(body) {
    return xhr('teaching/dd/v1/homework/assign-history/:parentExamId/students', { method: 'GET', body })
  }

  // 套题列表
  papersetLists(body) {
    return xhr('teaching/dd/v2/papersets/:teacherId/list', { method: 'GET', body })
  }

  // 班级作业报告
  classHomeworkReport(body) {
    return xhr('teaching/dd/v2/reports/homework/:examId/:classId/:source', { method: 'GET', body })
  }

  // 作业个人报告
  personalHomeworkReport(body) {
    return xhr('teaching/dd/v2/reports/homework/:studentId/:examId/:classId/:source', { method: 'GET', body })
  }

  // 作业班级列表查询
  homeworkClassList(body) {
    return xhr('teaching/dd/v1/exam/homework/classlist/:examId', { method: 'GET', body })
  }

  // 作业题目（教辅）
  teachingBookHomeworkLists(body) {
    return xhr('teaching/teaching-book/v1/exerhome/question', { method: 'GET', body })
  }

  // 作业提交/批阅情况查询
  queryHkStatus(body) {
    return xhr('teaching/dd/v1/homework/queryHkStatus/:examId/:classId/:type', { method: 'GET', body })
  }

  // 作业提交/批阅情况查询
  queryThDownLoadStatus(body) {
    return xhr('teaching/dd/v1/homework/isTopicLoadedByTeacher/:examId/:classId', { method: 'GET', body })
  }

  // 题单下载情况查询
  queryTopicLoadStatus(body) {
    return xhr('teaching/dd/v1/homework/queryTopicLoadStatus/:examId/:classId', { method: 'GET', body })
  }

  // 学生错误详情
  stuWrongDetail(body) {
    return xhr('teaching/dd/v1/exam/wrong/detail', { method: 'GET', body })
  }

  // 学生作业报告详情
  getPersonalHomeworkReportDetail(body) {
    return xhr('teaching/teaching-book/v1/exerhome/detail', { method: 'GET', body })
  }

  //  学生班级列表
  getAllClassStuList(body) {
    return xhr('teaching/dd/v1/reports/getAllClassStuList/:examId', { method: 'GET', body })
  }

  // 7.0 - 查询机构批阅学生列表(已批阅学生列表)
  queryCheckedStudentList(body) {
    return xhr('job/check/exercise/v1/check-students', { method: 'GET', body })
  }

  // 7.0 - 编辑小问(保存答案与小问之间的关联关系)
  editSubQuestions(body) {
    return xhr('teaching/dd/v1/subquestion/edit/save', { method: 'POST', body })
  }

  // 教辅章节的题目查询
  getTextbookQuestions(body) {
    return xhr('teaching/dd/v2/resource/book/:bookId/questions', { method: 'GET', body })
  }

  // 班级成绩单查询
  getScoresheetList(body) {
    return xhr('teaching/dd/v2/reports/homework/scoresheet/:classId/:examId/:source', { method: 'GET', body })
  }

  // 班级周练成绩单查询
  getWeekScoresheetList(body) {
    return xhr('teaching/dd/v1/reports/week/:classId/:examId/scoresheet', { method: 'GET', body })
  }

  // 班级错题分布
  getErrorSpread(body) {
    return xhr('teaching/dd/v2/reports/homework/questions/:classId/:examId/:source', { method: 'GET', body })
  }

  // 班级周练错题分布
  getWeekErrorSpread(body) {
    return xhr('teaching/dd/v1/reports/week/:classId/:examId/questions', { method: 'GET', body })
  }

  // 班级周练成绩分布
  getScoreSpread(body) {
    return xhr('teaching/dd/v1/reports/week/:classId/:examId/scoredistribute', { method: 'GET', body })
  }

  // 班级知识点分布
  getLoreIcon(body) {
    return xhr('teaching/dd/v1/reports/knowledges/homework/:classId/:examId/:source', { method: 'GET', body })
  }

  // 班级周练知识点分布
  getWeekLoreIcon(body) {
    return xhr('teaching/dd/v1/reports/knowledges/:classId/:examId/:type', { method: 'GET', body })
  }

  //  需要关注
  needAttention(body) {
    return xhr('teaching/dd/v2/reports/attention/list/:classId', { method: 'GET', body })
  }

  // 提升潜力榜
  potentialList(body) {
    return xhr('teaching/dd/common/v8/score/improving/rank', { method: 'GET', body })
  }

  // 自组合查询
  groupQuery(body) {
    return xhr('teaching/homework/v1/group', { method: 'GET', body })
  }
}

export default new HomeworkService()
