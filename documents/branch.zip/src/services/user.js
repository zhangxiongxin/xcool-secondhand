import xhr from '@/services/xhr'
import store from '@/store'
import { updateUserData } from '@/store/types'
import LocalStorageService from '@/services/storage'
// import CommonService from '@/services/common'
// import StorageService from '@/services/storage'

class UserService {
  login(body) {
    return xhr('teaching/v1/users/login', { method: 'POST', body, headers: { 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded' } }, { noAlert: true })
  }
  getUserData(cb) {
    if (typeof cb === 'function') return cb(store.state.user.data)
    return store.state.user.data
  }
  setUserData(data) {
    store.commit(updateUserData, data)
  }
  logout({ resetAutoLogin, noRedirect, noFetch } = { resetAutoLogin: 1 }) {
    if (noFetch && !noRedirect) return (window.location.hash = '/login')
    return xhr('teaching/v1/users/logout', { method: 'POST' }, { noAlert: true })
      .then(res => {
        LocalStorageService.remove('userData')
      })
      .catch(res => {
        LocalStorageService.remove('userData')
        window.location.hash = '/login'
      })
  }
}
export default new UserService()
