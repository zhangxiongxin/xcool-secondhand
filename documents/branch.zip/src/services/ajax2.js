// 原生ajax，未做任何封装，不要修改
export default function ajax(opt) {
  opt = opt || {}
  opt.method = opt.method.toUpperCase() || 'POST'
  opt.url = opt.url || ''
  opt.async = opt.async || true
  opt.data = opt.data || null
  opt.success = opt.success || function() {}
  var xmlHttp = null
  if (XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest()
  } else {
    xmlHttp = new window.ActiveXObject('Microsoft.XMLHTTP')
  }
  var params = []
  for (var key in opt.data) {
    params.push(key + '=' + opt.data[key])
  }
  var postData = params.join('&')
  if (opt.method.toUpperCase() === 'POST') {
    xmlHttp.open(opt.method, opt.url, opt.async)
    xmlHttp.setRequestHeader('Accept', 'application/json, text/plain, */*')
    xmlHttp.setRequestHeader('Content-Type', 'application/json; charset=UTF-8')
    xmlHttp.send(postData)
  } else if (opt.method.toUpperCase() === 'GET') {
    xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async)
    xmlHttp.send(null)
  }
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4) {
      if (xmlHttp.status === 200) {
        opt.success(xmlHttp.responseText)
      } else {
        opt.error(xmlHttp.responseText)
      }
    }
  }
}
