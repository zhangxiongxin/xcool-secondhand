/* 封装ajax函数
 * @param {string}opt.method http连接的方式，包括POST和GET两种方式
 * @param {string}opt.url 发送请求的url
 * @param {boolean}opt.async 是否为异步请求，true为异步的，false为同步的
 * @param {object}opt.data 发送的参数，格式为对象类型
 * @param {function}opt.success ajax发送并接收成功调用的回调函数
 * ajax({
    method: 'POST',
    url: 'test.php',
    data: {
        name1: 'value1',
        name2: 'value2'
    },
    success: function (response) {
       console.log(response)；
    }
})
 */
import { serverHost } from 'config/app'
export default function ajax(requestUrl, config, success, failure, method) {
  let opt = {}
  opt.url = (serverHost || '') + formatUri(requestUrl, config) || ''
  opt.method = method || 'POST'
  opt.success = success || function() {}
  opt.failure = failure || function() {}
  let queryParam = getQueryParams()
  let xmlHttp = null
  // if (XMLHttpRequest) {
  xmlHttp = new XMLHttpRequest()
  // } else {
  //   xmlHttp = new ActiveXObject('Microsoft.XMLHTTP')
  // }
  // let params = []
  // for (var key in opt.data) {
  //   params.push(key + '=' + opt.data[key])
  // }
  // let postData = params.join('&')
  if (opt.method.toUpperCase() === 'POST') {
    console.log(opt.method)
    xmlHttp.open('POST', opt.url)
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencodedcharset=utf-8')
    xmlHttp.setRequestHeader('access_token', queryParam.access_token)
    xmlHttp.send(JSON.stringify(config.body))
  } else if (opt.method.toUpperCase() === 'GET') {
    xmlHttp.open('GET', opt.url)
    xmlHttp.setRequestHeader('access_token', queryParam.access_token)
    xmlHttp.send(null)
  }
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
      opt.success(JSON.parse(xmlHttp.responseText))
    } else {
      opt.failure(xmlHttp.status)
    }
  }
}
// 获取查询参数解析器，例如：传 "?page=12&list=20" 返回对象 {page:'12',list:'20'}
function getQueryParams(url) {
  url = url || window.location.href
  let search = url.substring(url.lastIndexOf('?') + 1)
  let res = {}
  search.replace(/([^?&=]+)=([^?&=]*)/g, function(rs, $1, $2) {
    res[decodeURIComponent($1)] = String(decodeURIComponent($2))
    return rs
  })
  return res
}
function formatUri(uri, config) {
  let str = (uri + ' ').replace(/:(.*?)(\/|\?| )/g, function(a, b, c) {
    let tmp = config.body[b]

    // It's a trick
    delete config.body[b]
      // if (c === '?') return !tmp && tmp !== 0 ? '?' : tmp
    return tmp + c
  }).trim()

  if (!config.body) return str
  if (config.method.toUpperCase() === 'GET') {
    let paramBody = param(config.body)
    if (paramBody) return str + (str.indexOf('?') >= 0 ? '&' : '?') + paramBody
  } else if (config.body) {
    config.body = config.headers['Content-Type'].toUpperCase().indexOf('JSON') >= 0 ? JSON.stringify(config.body) : param(config.body)
  }

  return str
}
function param(obj) {
  let name, value, fullSubName, subName, innerObj, i
  let query = ''

  if (!obj) return query

  for (name in obj) {
    value = obj[name]
    if (value instanceof Array) {
      for (i = 0; i < value.length; ++i) run(i, value[i])
    } else if (value instanceof Object) {
      for (subName in value) run(subName, value[subName])
    } else if (value !== undefined && value !== null) {
      query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&'
    }
  }

  return query.length ? query.substr(0, query.length - 1) : query

  function run(key, val) {
    fullSubName = name + '[' + key + ']'
    innerObj = {}
    innerObj[fullSubName] = val
    query += param(innerObj) + '&'
  }
}
