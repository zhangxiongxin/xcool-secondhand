import xhr from '@/services/xhr'

import appConfig from 'config/app'
import userService from './user'

class CommonService {
  report(body) {
    return xhr('/hello', { method: 'get' })
  }

  // 保存点击流

  // schoolId  是 string  学校Id
  // teacherId 是 string  老师Id
  // operationType 是 string  操作类型: 创建作业/周练/考试 (“create”),查看班级报告 (“lookClassReport”),查看学生个人报告 (“lookStuReport”),查看纠错报告 (“lookCorrectionReport”), 查看学生错题 (“lookStuError”),查看趋势报告 (“lookTrendReport”),;
  // detailTime  是 long  操作时间
  // examId  是 string  作业/考试Id
  // studentId 是 string  学生Id
  // eventName 是 string  事件名称: EVENT_OPERATION_RECORD
  saveEvent(config) {
    getClasses((data) => {
      config.schoolId = data[config.classId]
      saveLog(config)
    })
  }
  resetEvent() {
    classes = {}
  }
}
var classes = {}
function getClasses(cb) {
  var teacherId = userService.getUserData().userInfos[0].accountId
  return new Promise((resolve, reject) => {
    if (classes.done) {
      return cb(classes)
    }
    xhr('teaching/homework/v1/classes/students/' + teacherId).then((resp) => {
      resp.data.forEach((item) => {
        classes[item.classId] = item.schoolId
      })
      classes.done = true
      cb(classes)
    })
  })
}

function saveLog(config) {
  var teacherId = userService.getUserData().userInfos[0].accountId
  var defaultConfig = Object.assign({
    eventName: 'EVENT_OPERATION_RECORD',
    teacherId: teacherId,
    detailTime: new Date().getTime()
  })
  return xhr('rest/log/clickFlow/operation', {
    method: 'post',
    server: appConfig.logServer,
    body: Object.assign(defaultConfig, config)
  })
}

export default new CommonService()
