import xhr from '@/services/xhr'

class SingupService {
  // 获取验证码
  getUsedCount(body) {
    return xhr('studying/v1/student/usestatistics', { method: 'GET', body })
  }
  getMsgcode(body) {
    return xhr('studying/register/code', { method: 'GET', body })
  }
  signup(body) {
    return xhr('studying/dd/register', { method: 'POST', body, headers: { 'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/x-www-form-urlencoded' } })
  }
}

export default new SingupService()
