import xhr from '@/services/xhr'

class ResourceService {
  // 教辅树查询2.0
  querySectionV2(body) {
    return xhr('teaching/dd/v2/resource/book/list', { method: 'POST', body })
  }
}

export default new ResourceService()
