import xhr from '@/services/xhr'
import ajax from '@/services/ajax'
class EmbeddedPageService {
  // 素质问卷
  saveQualitySurvey(body) {
    return xhr('studying/v1/quality', { method: 'POST', body })
  }

  // 作业个人报告
  homeworkReport(body, success, error) {
    return ajax('studying/dd/v3/reports/homework/:classId/:examId/:studentId', { method: 'GET', body: body }, success, error, 'get')
  }

  // 考试个人报告
  examReport(body, success, error) {
    return ajax('studying/dd/v1/reports/exam/:studentId/:examId/:classId', { method: 'GET', body }, success, error, 'get')
  }
  // 周练个人报告
  weekReport(body, success, error) {
    return ajax('studying/dd/v2/reports/week/:classId/:examId/:studentId/questions', { method: 'GET', body }, success, error, 'get')
  }
  // 错题周题练个人报告
  weekWrongsReport(body, success, error) {
    return ajax('studying/dd/v3/reports/exercise/:classId/:examId/:studentId', { method: 'GET', body }, success, error, 'get')
  }
  // 个人知识点考试周练报告
  personalExamKnowledge(body, success, error) {
    return ajax('studying/dd/v2/reports/knowledge/:classId/:examId/:studentId/:type', { method: 'GET', body }, success, error, 'get')
  }
  // 学生端学生个人报告作业知识点查询
  personalHomeworkKnowledge(body, success, error) {
    return ajax('studying/dd/v2/reports/knowledge/homework/:classId/:examId/:studentId/:source', { method: 'GET', body }, success, error, 'get')
  }
  // 素质分析查询
  queryQualitySurvey(body, success) {
    return ajax('studying/v1/quality/:studentId', { method: 'GET', body: body }, success, null, 'get')
  }
  // 错题本
  errorQuestion(body, success, error) {
    return ajax('studying/dd/v2/student/questions/wrong/:studentId', { method: 'GET', body }, success, error, 'get')
  }
  // 个人关注榜查询
  personalAttention(body, success, error) {
    return ajax('studying/dd/v2/reports/attention/:studentId/', { method: 'GET', body }, success, error, 'get')
  }
  // 提分榜
  improvingLists(body, success, error) {
    return ajax('studying/dd/common/v8/score/improving/rank', { method: 'GET', body }, success, error, 'get')
  }
  // 个人报告难题答对
  wrongRight(body, success, error) {
    return ajax('studying/dd/reports/difficult/questions/:classId/:examId/:studentId/:type', { method: 'GET', body }, success, error, 'get')
  }
  // 充值记录
  rechargeRecord(body) {
    return xhr('studying/recharge/list/:studentId/:pageNum/:pageSize', { method: 'GET', body })
  }
  // 兑换记录
  exchangeRecord(body) {
    return xhr('studying/dd/v2/student/exchange/code/queryHistory/:pageNum/:pageSize', { method: 'GET', body })
  }
  // vip兑换记录
  vipExchangeRecord(body) {
    return xhr('studying/dd/v2/student/exchange/code/queryHistory/:pageNum/:pageSize', { method: 'GET', body })
  }
  // 学豆使用详情-学生详情
  consumeStudentDetail(body) {
    return xhr('studying/v2/product/consume/detail', { method: 'GET', body })
  }
  // 学豆使用详情-商品使用详情
  consumeGoodsDetail(body) {
    return xhr('studying/v2/product/consume/detail/more', { method: 'GET', body })
  }
  // 学豆使用详情-商品列表
  consumeGoodsList(body) {
    return xhr('studying/v2/product/consume/detail/page', { method: 'GET', body })
  }
}

export default new EmbeddedPageService()
