// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import { AlertPlugin, LoadingPlugin, ConfirmPlugin } from 'vux'

// for vuex
import store from './store'

// one way for all component
// we can import components we actually need, making the project smaller than otherwise.
// http://element.eleme.io/#/zh-CN/component/quickstart
import ElementUI from 'element-ui'
// npm run theme:build
import 'assets/css/common.css'
import 'element-theme-default/doudou-ui/index.css'

// import 'element-ui/lib/theme-default/index.css'
Vue.use(ElementUI)
Vue.use(LoadingPlugin)
Vue.use(AlertPlugin)
Vue.use(ConfirmPlugin)
// animate.css
import 'animate.css'
// 自制组件
import './components'

// filters
import './filters'

// 根组件
import App from './App'

// 路由
import router from './router'

import common from '@/services/common'

// mixin Vue

Vue.mixin({
  created() {
    this.$event = common.saveEvent
  }
})

// init app
const app = new Vue({
  router,
  store,
  ...App
})

app.$mount('#app')

export { app, router }

// 阻止直接拖拽一些文件到我们的 app
window.ondragover = preventDefault
window.ondrop = preventDefault

function preventDefault(ev) {
  ev.preventDefault()
  return false
}
