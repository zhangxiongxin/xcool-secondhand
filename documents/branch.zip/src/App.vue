<template lang="pug">
  router-view.full-container
</template>
<script>
  export default {
    name: 'app'
  }
</script>
<style src="./assets/css/style.css"></style>
<style>
  .full-container {
    width: 100%;
    height: 100%;
  }
  /*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
  ::-ms-clear,::-ms-reveal{display:none;}
  ::-webkit-scrollbar {
    width: 3px;
    height: 3px;
    background-color: transparent;
    position: relative;
  }
  /*定义滚动条轨道 内阴影+圆角*/

  ::-webkit-scrollbar-track {
    background-color: transparent;
  }
  /*定义滑块 内阴影+圆角*/

  ::-webkit-scrollbar-thumb {
    border-radius: 20px;
    background-color: #ddd;
  }
  .weui-input::placeholder{
    color:#ccc;
  }
  .hover-scroll {
    overflow: auto;
    &::-webkit-scrollbar-thumb {
      background-color: transparent;
    }
    &:hover {
      &::-webkit-scrollbar-thumb {
        background-color: #ddd;
      }
    }
  }
  .animated {
    animation-duration: 0.3s;
    animation-timing-function: linear;
  }
</style>
