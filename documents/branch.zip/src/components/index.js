import Vue from 'vue'

import commonComponent from './common'
import vuxComponent from './vux'
import doudouComponent from './doudou'

const components = { ...commonComponent, ...vuxComponent, ...doudouComponent }
Object.keys(components).forEach(key => Vue.component(components[key].name, components[key]))

// svg icon
import Icons from '@/assets/icon'
console.dir(Icons)
// import IconConfig from '@/assets/icon'
// try {
//   IconConfig.source.forEach(v => Icon.inject(v, IconConfig.path))
//   Vue.component('icon', Icon)
// } catch (ex) {
//   console.log(ex)
// }

