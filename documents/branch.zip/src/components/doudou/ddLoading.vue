<template lang="pug">
  .loading_contain(v-show="ddLoading")
    .loading_tip_box
      .spinner.page-spinner
      .tip 布置中，请耐心等待...
</template>
<script>
  export default {
    name: 'ddLoading',
    props: ['ddLoading'],
    data() {
      return {}
    },
    methods: {}
  }
</script>
<style scoped>
  .loading_contain {
    position: absolute;
    top: 0px;
    left: 0px;
    z-index: 2000;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .loading_tip_box {
    text-align: center;
    width: 252px;
    height: 95px;
    background: #FFFFFF;
    box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.50);
    border-radius: 4px;
    & .tip {
      font-size: 20px;
      color: #666666;
      margin-top: 11px;
    }
  }
  
  .page-spinner {
    margin-top: 22px;
    height: 22px;
    width: 22px;
    border: 1px solid transparent;
    border-top-color: #3095FF;
    border-left-color: #3095FF;
    border-bottom-color: #3095FF;
    border-radius: 50%;
    animation: mint-spinner-rotate 0.8s infinite linear;
  }
  
  @keyframes mint-spinner-rotate {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
</style>
