<template lang="pug">
  div
    section(v-if="type === 'compare'")
      .item(:class="ddClass")
        p
          span 成绩为的
          span.color-light-red {{level}}
          span 学生占 {{data.percent}}
        p
          span.big {{data.num}}
          span 人
      .text(v-if="data.numChange>0 && !data.firstFlag", :class="ddClass.split('-')[1]")
        p 比上次{{text || '考试'}}
        p
          img(src="~assets/imgs/fa-arrow-up.png", draggable="false")
          span.color-up &nbsp;{{Math.abs(data.numChange)}}人
      .text(v-if="data.numChange===0 && !data.firstFlag", :class="ddClass.split('-')[1]")
        p 与上次{{text || '考试'}}持平
        //- p
        //-   span.pull-right
        //-     img(height="20",src="~assets/imgs/cheer1.png", draggable="false")
        //-     span.color-font 继续努力
      .text(v-if="data.numChange<0 && !data.firstFlag", :class="ddClass.split('-')[1]")
        p 比上次{{text || '考试'}}
        p
          span
            img(src="~assets/imgs/ico_decline.png", draggable="false")
            span.text-red &nbsp;{{Math.abs(data.numChange)}}人
          //- span.pull-right
          //-   img(height="20",src="~assets/imgs/cheer2.png", draggable="false")
          //-   span.color-font 加油
    section(v-if="type === 'rank'")
      .item.average
        span 班级名次
        p
          span.big {{data.scoreRank}}
          span 名
      .text.good(v-if="data.lastIncreaseRank>0&&!data.firstFlag")
        p 比上次考试
        p
          span
            img(src="~assets/imgs/fa-arrow-up.png", draggable="false")
            span.color-up &nbsp;{{Math.abs(data.lastIncreaseRank)}}名
          span.pull-right.cheer1 不错哟
      .text.good(v-if="data.lastIncreaseRank===0&&!data.firstFlag")
        p 与上次考试持平
        p
          span.pull-right.cheer1 继续努力
      .text.good(v-if="data.lastIncreaseRank<0&&!data.firstFlag")
        p 比上次考试
        p
          span
            img(src="~assets/imgs/ico_decline.png", draggable="false")
            span.text-red &nbsp;{{Math.abs(data.lastIncreaseRank)}}名
          span.pull-right.cheer2 加油
    section(v-if="type === 'weeklyRank'")
      .item.level-fine
        span 班级名次
        p
          span.big {{data.scoreRank}}
          span 名
      .text.good(v-if="data.lastIncreaseRank>0&&!data.firstFlag")
        p 比上次考试
        p
          span
            img(src="~assets/imgs/fa-arrow-up.png", draggable="false")
            span.color-up &nbsp;{{Math.abs(data.lastIncreaseRank)}}名
          span.pull-right.cheer1 不错哟
      .text.good(v-if="data.lastIncreaseRank===0&&!data.firstFlag")
        p 与上次考试持平
        p
          span.pull-right.cheer1 继续努力
      .text(v-if="data.lastIncreaseRank<0&&!data.firstFlag")
        p 比上次考试
        p
          span
            img(src="~assets/imgs/ico_decline.png", draggable="false")
            span.text-red &nbsp;{{Math.abs(data.lastIncreaseRank)}}名
          span.pull-right.cheer2 加油
    section(v-if="type === 'score'")
      .item(:class="ddClass")
        span 总分{{data.totalScore}}分，得分
        p
          span.big {{data.score}}
          span 分
      .text(v-if="data.score > data.avgScore")
        p 比班级平均分 ({{data.avgScore | toFixedOne}}分)
        p
          span.color-font(style="font-size:16px") 高{{(data.score - data.avgScore) | toFixedOne}}分
          span.pull-right.cheer1 真棒
      .text(v-if="data.score === data.avgScore")
        p 达到班级平均水平
        p
          span.pull-right.cheer1 不错哟
      .text(v-if="data.score < data.avgScore")
        p 比班级平均分({{data.avgScore | toFixedOne}}分)低
        p
          span.pull-right.cheer2 加油
    section(v-if="type === 'weeklyScore'")
      .item.level-good
        span 我的分数（总分{{data.totalScore}}分）
        p
          span.big {{data.score}}
          span 分
      .text.fine(style="font-size:16px",v-if="data.score > data.avgScore")
        p 比班级平均分 ({{data.avgScore | toFixedOne}}分)
        p
          span.color-font(style="font-size:16px") 高{{(data.score - data.avgScore) | toFixedOne}}分
          span.pull-right.cheer1 真棒
      .text(v-if="data.score === data.avgScore")
        p 达到班级平均水平
        p
          span.pull-right.cheer1 不错哟
      .text(v-if="data.score < data.avgScore")
        p 比班级平均分 ({{data.avgScore | toFixedOne}}分) 低
        p
          span.pull-right.cheer2 加油
    section(v-if="type === 'accuray'")
      .item.level-fine
        span 正确率（精确到题目小问）
        p
          span.big {{data.accuracy | rateFilter}}
      .text.good(v-if="Math.round(data.increaseAccuracy * 100) / 100 > 0 && !data.firstFlag")
        p 比上次作业
        p
          span
            img(src="~assets/imgs/fa-arrow-up.png", draggable="false")
            span.color-up &nbsp;{{data.increaseAccuracy | rateFilter}}
          span.pull-right.cheer1 真棒
      .text.good(v-if="Math.round(data.increaseAccuracy * 100) / 100 === 0 && !data.firstFlag")
        p 与上次作业持平
        p
          span.pull-right.cheer1 继续努力
      .text.good(v-if="Math.round(data.increaseAccuracy * 100) / 100 < 0 && !data.firstFlag")
        p 比上次作业
        p
          span
            img(src="~assets/imgs/ico_decline.png", draggable="false")
            span.text-red &nbsp;{{data.increaseAccuracy | rateFilter}}
          span.pull-right.cheer2 加油
    section(v-if="type === 'question'")
      .item.level-good
        span 总共 {{data.totalQuestions}} 题 
        p
          //- rightTotalQuestions
          span  答对
          span.big  {{data.rightCount}}
          span  题
      .text(v-if="data.rankPercentage>0.1")
        p 击败了
          span.color-font  {{data.rankPercentage | rateFilter}}
          span  的同学
        p
          span.pull-right.cheer1 真棒
      .text(v-if="data.rankPercentage<=0.1&&data.rankPercentage>-1")
        p 发挥失常？下次加油哦
        //- p
        //-   span.pull-right.cheer2 加油
    section(v-if="type === 'submit'")
      .item.submit-style
        p
          span  第
          span.big {{data.submitRank}}
          span 个
        span 提交{{text || '作业'}}
      .text.middle(v-if="data.totalStudentNumber > data.submitRank")
        p 超越全班
            span.color-font {{data.totalStudentNumber - data.submitRank}}
            span 个同学
        p
          span.pull-right.cheer1 真棒
      .text.middle(v-if="data.totalStudentNumber === data.submitRank")
        p 越努力越幸运
        p
          span.pull-right.cheer1 你是最棒的

</template>
<script>
  export default {
    name: 'reportItem',
    props: [ 'type', 'data', 'level', 'ddClass', 'text' ],
    methods: {
    }
  }
</script>
<style scoped>
  .cheer2 {
    padding-left:22px;
    background: url(~assets/imgs/cheer2.png) no-repeat 0 2px;
    background-size: auto 20px;
    color: #FF9937;
  }
  .cheer1 {
    padding-left:22px;
    background: url(~assets/imgs/cheer1.png) no-repeat 0 2px;
    background-size: auto 20px;
    color: #FF9937;
  }
  section {
    margin-right: 15px;
    margin-bottom: 10px;
  }
  .text-red {
    color: #E53F3F;
  }
  .item {
    /*padding: 23px 0 14px;*/
    width: 216px;
    height: 110px;
    border-radius: 12px;
    font-size: 16px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    margin-bottom: 7px;
  }
  .text {
    width: 216px;
    height: 58px;
    color: #666666;
    background: #FFFCED;
    border: 1px solid #F5E693;
    border-radius: 12px;
    padding: 0px 10px;
    & p {
      height: 28px;
      line-height: 28px;
    }
  }
  .average {
    color: #A779E8;
    background: #EBDBFF;
  }
  .weeklyAverage {
    color: #53BA33;
    background: #D8FFAE;
  }
  .weeklyRank {
    color: #5B81F5;
    background: #D8E2FF;
  }
  .level-fine {
    background: #D9E2FF;
    color:  #5B81F5;
  }
  .fine {
    background: #FFFCED;
    border: 1px solid #F5E693;
    border-radius: 12px;
  }
  .level-good {
    background:  #FFF1A4;
    color:  #C39B41;
  }
  .good {
    background: #F6F8FF;
    border: 1px solid #B7C8FF;
    border-radius: 12px;
  }
  .submit-style {
    background: #F9E4D0;
    color: #D76F21;
  }
  .level-middle {
    background: #FFE5D0;
    color:  #FF8429;
  }
  .middle {
    background: #FFFBF8;
    border: 1px solid #FFCAA2;
    border-radius: 12px;
  }
  .big {
    font-size: 36px;
    line-height: 51px;
  }
  .color-light-red {
    padding: 0 5px;
    font-weight: bold;
    font-size: 24px;
    /*line-height: 24px;*/
  }
  .color-up {
    color: #24CB72;
  }
  .color-down {
    color: #FF5353;
  }
  .color-font {
    color: #FF9937;
    padding:0 5px;
  }
</style>
