<template lang="pug">
  .search
    x-input.search_input(:placeholder="innerPlaceHolder", v-model="search")
      img.search_icon(slot="label" src='~assets/imgs/Search Icon.png')
    button.search_btn(@click="clickSearch") 搜索
</template>
<script>
  export default {
    name: 'search',
    props: ['placeholder'],
    data() {
      return {
        innerPlaceHolder: this.placeholder || '搜索作业/考试名称',
        search: ''
      }
    },
    methods: {
      clickSearch() {
        this.$emit('search', this.search)
      }
    },
    watch: {
      search(n, o) {
        if (!n && o && n !== o) this.$emit('search', this.search)
      }
    }
  }
</script>
<style scoped>
  .search {
    height: 55px;
    width: 100%;
    padding: 0 8px;
    background: #F4F8FF;
    box-shadow: 0 2px 4px 0 rgba(38, 93, 148, 0.23);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  
  .search_input {
    width: calc(100% - 80px);
    height: 28px;
    border-radius: 5px;
    color: #666;
    background: #fff;
    font-size: 14px;
    border: 1px solid #BFD7FF;
  }
  
  .search_icon {
    width: 13px;
    margin-right: 12px;
  }
  
  .search_btn {
    border: none;
    width: 62px;
    height: 28px;
    line-height: 26px;
    background: #3399FF;
    box-shadow: 0 2px 6px 0 rgba(26, 87, 147, 0.23);
    border-radius: 4px;
    color: #fff;
    margin-left: 10px;
  }
</style>
<style>
  .search {
    & .weui-icon-clear:before {
      color: #A5D2FF;
    }
  }
</style>
