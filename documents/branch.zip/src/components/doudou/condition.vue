<template lang="pug">
  div
    .knowledge-condition(ref="moveArea")
      span 知识点范围：
      .bar
        p(data-level="level1",@click="knowledgeClick") 一级知识点
        p(data-level="level2",@click="knowledgeClick") 二级知识点
        p(data-level="level3",@click="knowledgeClick") 三级知识点
        .move-icon(@touchmove="touchmove",@touchend="touchend",draggable="false",ref="moveIcon")
          .transparent-box
      .active-bar(ref="activeBar")
        p(data-level="level1") 一级知识点
        p(data-level="level2") 二级知识点
        p(data-level="level3") 三级知识点
    .accuracy-range
      p {{knowledgeName[knowledgeValue - 1]}}正确率范围
      span.colon ：
      .bar(ref="accuracyMoveArea")
        section.left-move-icon(@touchmove="accuracytouchmove($event, 'lower')",draggable="true", ref="leftMoveIcon",@touchend="trigger")
          .transparent-box
        section.right-move-icon(@touchmove="accuracytouchmove($event, 'higher')",draggable="true",ref="rightMoveIcon",@touchend="trigger")
          .transparent-box
        .left-rate &nbsp;0%
        .right-rate 100%&nbsp;
      .active-bar(ref="leftActiveBar") 
      .active-bar.right(ref="rightActiveBar")
    .input-accuracy
      el-input(v-model="startAccuracy", type="number",@change="lowerChangeValue")
      span.width-50 % ~&nbsp;
      el-input(v-model="endAccuracy",type="number",@change="higherChangeValue")
      span &nbsp;&nbsp;%

</template>
<script>
  // 102 是bar的偏移量92 + moveicon的宽度的一半10
  const offsetX = 102
  // 相对于page的偏移量 102 是bar的偏移量92 + moveicon的宽度的一半10  515是condition-box 的宽度
  const offsetNum = offsetX + 40 + (document.documentElement.clientWidth - 515) / 2
  // 332 是bar的宽度
  const barWidth = 332
  // 325 是bar的宽度 - moveicon的宽度的一半10
  const offsetWidth = 322
  let timer   // 定时器id
  export default {
    name: 'condition',
    data() {
      return {
        knowledgeX: 0,   // 知识点范围移动的x值,
        knowledgeValue: 3, // 知识点值 1，2，3
        knowledgeName: ['一级知识点', '二级知识点', '三级知识点'],
        endValue: 322,   // 正确率开始值
        startValue: -10, // 正确率结束值
        startAccuracy: 0,
        endAccuracy: 100
      }
    },
    created() {},
    methods: {
      // 点击选中知识点范围
      knowledgeClick(e) {
        e.preventDefault()
        let level = e.target.dataset.level
        if (level === 'level1') this.touchend(null, 100 - 1)
        else if (level === 'level2') this.touchend(null, 100 + 1)
        else if (level === 'level3') this.touchend(null, 210 + 1)
      },
      // 输入的正确率改变
      lowerChangeValue() {
        if (timer) clearTimeout(timer)
        timer = setTimeout(() => {
          // startAccuracy 变化
          let startAccuracy = Number(this.startAccuracy)
          let endAccuracy = Number(this.endAccuracy)
          if (startAccuracy < 0) this.startAccuracy = 0
          if (startAccuracy > endAccuracy) this.startAccuracy = endAccuracy
          let toleft = Math.round(this.startAccuracy * (barWidth / 100)) - 10
          this.accuracytouchmove(null, 'lower', toleft)
          this.trigger()
        }, 500)
      },
      higherChangeValue() {
        if (timer) clearTimeout(timer)
        timer = setTimeout(() => {
          // endAccuracy 变化
          let startAccuracy = Number(this.startAccuracy)
          let endAccuracy = Number(this.endAccuracy)
          if (endAccuracy > 100) this.endAccuracy = 100
          if (endAccuracy < startAccuracy) this.endAccuracy = startAccuracy
          let toleft = Math.round(this.endAccuracy * (barWidth / 100)) - 10
          this.accuracytouchmove(null, 'higher', toleft)
          this.trigger()
        }, 500)
      },
      accuracytouchmove(e, type, left) {
        let toLeft
        if (left) {
          toLeft = left
        } else if (e) {
          e.preventDefault()
          toLeft = e.changedTouches[0].pageX - offsetNum
        }
        // 左右可拖动的点
        this.leftIcon = this.$refs.leftMoveIcon
        this.rightIcon = this.$refs.rightMoveIcon
        // 移动点
        if (type === 'lower') {
          // 提高当前的icon的zindex等级，其他的降低
          this.leftIcon.style.zIndex = 3
          if (this.rightIcon) this.rightIcon.style.zIndex = 2
          if (toLeft >= -10 && toLeft <= this.endValue) {
            this.startValue = toLeft
            // 对应的正确率为 (toLeft + 10) / (332 / 100)
            this.startAccuracy = Math.round((toLeft + 10) / (barWidth / 100))
            this.setAccuracy(toLeft, 'leftIcon', 'leftActiveBar')
          }
        } else {
          // 提高当前的icon的zindex等级，其他的降低
          this.rightIcon.style.zIndex = 3
          if (this.leftIcon) this.leftIcon.style.zIndex = 2
          if (toLeft >= this.startValue && toLeft <= offsetWidth) {
            this.endValue = toLeft
            // 对应的正确率为 (toLeft + 10) / (332 / 100)
            this.endAccuracy = Math.round((toLeft + 10) / (barWidth / 100))
            this.setAccuracy(toLeft, 'rightIcon', 'rightActiveBar')
          }
        }
      },
      trigger () {
        this.$emit('selectCondition', {
          knowledgeValue: this.knowledgeValue,
          startAccuracy: this.startAccuracy,
          endAccuracy: this.endAccuracy
        })
      },
      setAccuracy(toLeft, type) {
        this[type].style.left = Math.round(toLeft) + 'px'
        if (type === 'rightIcon') {
          this.$refs.rightActiveBar.style.left = toLeft + offsetX + 1 + 'px'
          this.$refs.rightActiveBar.style.width = offsetWidth - toLeft + 'px'
        } else {
          if (toLeft < 0) toLeft = 0
          this.$refs.leftActiveBar.style.width = toLeft + 'px'
        }
      },
      touchmove(e) {
        e.preventDefault()
        let toLeft = e.changedTouches[0].pageX - offsetNum
        if (toLeft >= -10 && toLeft <= offsetWidth) {
          this.setStyle(toLeft)
        }
      },
      touchend(e, left) {
        let toLeft
        if (left) toLeft = left
        else if (e) {
          e.preventDefault()
          // 99 是bar的偏移量92 + moveicon的宽度的一半
          toLeft = e.changedTouches[0].pageX - offsetNum
        }
        // 分层知识点 103 = 110 - 10   213 = 220 - 10
        if (toLeft > 210) {
          toLeft = offsetWidth
          this.knowledgeValue = 3
        } else if (toLeft > 100) {
          toLeft = 210
          this.knowledgeValue = 2
        } else {
          toLeft = 100
          this.knowledgeValue = 1
        }
        this.setStyle(toLeft)
        this.trigger()
      },
      setStyle(toLeft) {
        this.$refs.moveIcon.style.left = toLeft + 'px'
        this.$refs.activeBar.style.width = toLeft + 'px'
      }
    }
  }
</script>
<style scoped>
  .input-accuracy {
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 25px;
    & .width-50 {
      width: 50px;
      text-align: center;
      display: inline-block;
    }
  }
  .transparent-box {
    width: 40px;
    height: 30px;
    position: absolute;
    left: -13px;
    top: -3px;
  }
  .accuracy-range {
    position: relative;
    margin-top: 30px;
    &>p {
      width: 70px;
    }
    &>.colon {
      position: absolute;
      top: 6px;
      left: 70px;
    }
    & .active-bar {
      width: 0px;
      height: 18px;
      background-color: rgba(255,255,255,0.6);
      position: absolute;
      top: 5px;
      left: 92px;
      &.right {
        left: 424px;
      }
    }
    & .bar {
      width: 332px;
      height: 18px;
      background-image: linear-gradient(-90deg, #FF0000 0%, #FFCC3F 100%);
      position: absolute;
      top: 5px;
      left: 92px;
      font-size: 12px;
      & .right-rate {
        position: absolute;
        top: 3px;
        right: 2px;
        z-index: 1
      }
      & .left-rate {
        position: absolute;
        top: 3px;
        left: 2px;
        z-index: 1
      }
      & .left-move-icon {
        width: 20px;
        height: 30px;
        background: #FFE267;
        border: 3px solid #FFC83E;
        box-shadow: 0 1px 2px 0 rgba(0,0,0,0.50);
        position: absolute;
        position: absolute;
        top: -6px;
        left: -10px;
        z-index: 2
      }
      & .right-move-icon {
        width: 20px;
        height: 30px;
        background: #FF8347;
        border: 3px solid #FF0000;
        box-shadow: 0 1px 2px 0 rgba(0,0,0,0.50);
        position: absolute;
        top: -6px;
        left: 322px;
        cursor: pointer;
        z-index: 2
      }
    }
  }
  .knowledge-condition {
    display: flex;
    position: relative;
    & .active-bar {
      background: #EEE1FF!important;
      color: #A779E8;
      overflow: hidden;
      font-weight: 500;
    }
    & .bar,& .active-bar {
      width: 332px;
      height: 18px;
      background: #EEEEEE;
      display: flex;
      position: absolute;
      flex-wrap: nowrap;
      left: 92px;
      top: -2px;
      & .move-icon {
        width: 20px;
        height: 30px;
        background: #EEE1FF;
        border: 3px solid #A779E8;
        box-shadow: 0 1px 2px 0 rgba(0,0,0,0.50);
        position: absolute;
        top: -6px;
        left: 322px;
        z-index: 10
      }
      &>p {
        width: 110px;
        font-size: 12px;
        text-align: center;
        line-height: 18px;
        flex-shrink: 0;
        background-color: transparent;
        &:nth-child(2) {
          border-left: 1px solid #CCCCCC;
          border-right: 1px solid #CCCCCC;
        }
      }
    }
  }
</style>
<style>
.input-accuracy {
  & .el-input,& .el-input__inner {
    width: 76px;
    border-color: #CDE7EF;
    height: 29px;
    border-radius: 0px;
    text-align: center;
  }
}
</style>
