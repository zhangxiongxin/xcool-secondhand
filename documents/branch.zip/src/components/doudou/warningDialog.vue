<template lang="pug">
  transition(name="fade")
    .bg_contain
      .warning_contain
        slot(name="body")
        .return_btn(@click="goback") 知道了
</template>
<script>
  export default {
    name: 'warningDialog',
    data() {
      return {}
    },
    methods: {
      goback() {
        this.$emit('goback')
      }
    }
  }
</script>
<style scoped>
  .fade-enter-active,
  .fade-leave-active {
    transition: all .2s linear;
    transform: translate3D(0, 0, 0);
  }
  
  .fade-enter,
  .fade-leave-active {
    transform: translate3D(100%, 100%, 100%);
  }
  
  .bg_contain {
    position: fixed;
    top: 0px;
    left: 0px;
    z-index: 2000;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
  }
  
  .warning_contain {
    line-height: 28px;
    font-size: 20px;
    background: #FFFFFF;
    border-radius: 6px;
    width: 67%;
    height: 225px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    padding: 20px 25px 0px 25px;
    & .return_btn {
      cursor: pointer;
      text-align: center;
      font-size: 16px;
      color: #fff;
      width: 150px;
      height: 42px;
      line-height: 42px;
      background: #3399FF;
      border-radius: 78px;
      box-shadow: 0 2px 6px 0 rgba(27,78,129,0.43);
      margin: 20px auto 30px auto;
      &:hover {
        background: #FFCC66;
      }
    }
  }
</style>
