<template lang="pug">
  .sort_box
    .sort_item
      span(@click="sortClick('createTime')") 创建时间
        .timeimg(v-show="sortBy === 'createTime'", :class="{descClass:sort, ascClass:!sort}")
    .sort_item.border
      span(@click="sortClick('useTimes')") 使用次数
        .timeimg(v-show="sortBy === 'useTimes'", :class="{descClass:sort, ascClass:!sort}")
    .sort_item
      span(@click="sortClick('collectorNum')") 收藏人数
        .timeimg(v-show="sortBy === 'collectorNum'", :class="{descClass:sort, ascClass:!sort}")
</template>
<script>
  export default {
    name: 'sort',
    data() {
      return {
        createTime: true,
        useTimes: true,
        collectorNum: true,
        sortBy: 'createTime'
      }
    },
    methods: {
      sortClick(name) {
        this[name] = this.sortBy === name ? !this[name] : true
        this.sortBy = name
        let sortValue = this.sortBy + ',' + (this[name] ? 'desc' : 'asc')
        this.$emit('sortClick', sortValue)
      }
    },
    computed: {
      sort() {
        return this[this.sortBy]
      }
    }
  }
</script>
<style scoped>
  .sort_box {
    height: 50px;
    background: #F4F8FF;
    display: flex;
    align-items: center;
    font-size: 16px;
    color: #3399FF;
    border-bottom: 1px solid #99CCFF;
    & .sort_item {
      line-height: 20px;
      width: 33.3%;
      text-align: center;
      & span {
        position: relative;
      }
    }
  }
  
  .border {
    border-left: 1px solid #C4E1FF;
    border-right: 1px solid #C4E1FF;
  }
  
  .timeimg {
    background-size: 14px 14px;
    display: inline-block;
    width: 14px;
    height: 14px;
    top: 5px;
    position: absolute;
    left: 68px;
  }
  
  .descClass {
    background-image: url('~assets/imgs/ico_list@3x.png')
  }
  
  .ascClass {
    background-image: url('~assets/imgs/ico-uplist@3x.png')
  }
</style>
