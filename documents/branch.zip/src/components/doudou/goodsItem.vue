<template lang="pug">
  section.goods-items
    .right-status
      img(src="~assets/imgs/ic_countermand.png", v-if="items.rightStatus==2")
      img(src="~assets/imgs/ic_ineffective.png", v-if="items.rightStatus==3")
      img(src="~assets/imgs/ic_invalid.png", v-if="items.rightStatus==4")
    .display-flex
      .goods-name {{items.name}}
      .remaining(v-if="items.grantType==1 && !items.productOrSuite == 'suite'")
        span(v-if="goodsTypesB!=0") 可使用次数：{{ items.totalUseTimes == -1 ? '不限' : (items.totalUseTimes || 0)}}次
      .remaining(v-if="items.grantType==2 && !items.productOrSuite == 'suite'")
        span(v-if="goodsTypesB==2 || items.productOrSuite == 'suite'") 可使用次数：{{ items.totalUseTimes == -1 ? '不限' : (items.totalUseTimes || 0)}}次
      .btn(@click="open",v-if="items.productOrSuite == 'suite'") {{openState?'收起':'展开'}}详情
      .hidden(v-else)

    section
      table.item
        tr
          td(v-if="items.grantType==2") 消耗学豆：{{items.costTotalDdAmt}}学豆（充值学豆{{items.costRechargeDdAmt}}个
            span(v-if="items.costReturnDdAmt || items.costRewardDdAmt") +赠送学豆{{items.costReturnDdAmt + items.costRewardDdAmt}}个）&nbsp;
            span(v-if="!items.costReturnDdAmt && !items.costRewardDdAmt") ）&nbsp;
          td(v-else) 消耗学豆：发放使用权&nbsp;
          td(style="display: flex")
            span(style="width:75px") 兑换时间 : 
            span {{items.createTime | date('yyyy.MM.dd HH:mm:ss')}}
        tr
          td(style="display: flex")
            span(style="width:75px") 使用期限：
            span {{items.useStartTime | date('yyyy.MM.dd HH:mm:ss')}}-{{items.useEndTime | date('yyyy.MM.dd HH:mm:ss')}}&nbsp;
          td(v-if="items.privilegeId !== 'vacationwork'")
            span(v-if="items.grantType==1 || items.grantType==2 && goodsTypesB==2") 剩余次数：{{items.useTimes == -1 ? '不限' : items.useTimes}}次
          td(v-if="items.privilegeId === 'vacationwork'") 剩余天数：{{items.remainUseDayCount &lt; 0?0:items.remainUseDayCount}}天
      .list(v-if="openState")
        slot(name="productList")
</template>
<script>
  // 展开详情情况
  const goodsTypesA = {
    vacationwork: 'content',
    periodreview: 'content',
    questiondayclear: 'count',
    questionweekpractice: 'content',
    schoolsetwork: 'count',
    schoolassistantwork: 'count',
    leakfilling: 'content',
    wrongtopractice: 'content',
    ddcheckhomework: 'count',
    videocourse: 'count',
    schoolscanservice: 'count',
    wechatsmallprogram: 'count'

  }
  // 所有类型  vacationwork:假期作业,periodreview:阶段复习宝,questiondayclear:错题日日清,questionweekpractice:错题周题练,schoolsetwork:校内套题作业,schoolassistantwork:校内教辅作业,leakfilling 考前查漏补缺,wrongtopractice 考前错题再练, videocourse 同步课程, schoolscanservice 校园扫描, wechatsmallprogram 微信小程序
  // grantType 1-系统发放 2-用户兑换
  // 阶段复习宝、错题周提炼、同部微课、考前错题再练、考前查漏补缺。如果学生自己花学豆单独购买这5个商品，则不显示“可使用次数”、“剩余次数”、也不用查看详情
  // 可使用次数情况
  // 0 不显示   1 用户兑换不显示，2用户兑换显示
  const goodsTypesB = {
    vacationwork: 0,
    periodreview: 1,
    questiondayclear: 2,
    questionweekpractice: 1,
    schoolsetwork: 2,
    schoolassistantwork: 2,
    leakfilling: 1,
    wrongtopractice: 1,
    ddcheckhomework: 2,
    videocourse: 1,
    schoolscanservice: 2,
    wechatsmallprogram: 2
  }
  import embeddedPageService from '@/services/embeddedPage'
  export default {
    name: 'goodsItem',
    data() {
      return {
        openState: false,
        goodsDetail: [],
        goodsTypesA: goodsTypesA[this.items.privilegeId],
        goodsTypesB: goodsTypesB[this.items.privilegeId],
        studentId: this.$route.params.studentId
      }
    },
    props: ['items'],
    methods: {
      open() {
        if (this.openState) this.openState = false
        else {
          if (!this.goodsDetail.length) this.getData()
          this.openState = true
        }
      },
      getData() {
        embeddedPageService.consumeGoodsDetail({rightId: this.items.rightId, studentId: this.studentId}).then((res) => {
          this.goodsDetail = res.data
        })
      }
    }
  }
</script>
<style scoped>
.goods-items {
  margin-top: 15px;
  position: relative;
  & .goods-name {
    font-weight: 600;
    padding-bottom: 5px;

  }
  & .right-status {
    position: absolute;
    top:12px;
    left: calc(50% - 55px);
  }
  & .item {
    & td {
      vertical-align: top;
      padding: 5px 0px;
    }
  }
  & .display-flex {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  & .remaining {
    font-size: 14px;
  }
  & .btn {
    width: 90px;
    height: 36px;
    line-height: 34px;
    background: #E0F3FF;
    border-radius: 20px;
    font-size: 14px;
    color: #48B5FC;
    text-align: center;
    float: right;
    align-self: flex-end;

  }
  &  .list .goods-items {
    margin-top: 0px;
    &:nth-child(1) {
      margin-top: 5px;
      border-top:dashed 1px #EE7905;
    }
    &>section {
      border-bottom: dashed 1px #EE7905;
      padding-bottom: 10px;
      font-size: 12px;
      &:last-of-child {
        border-bottom: none;
      }
    }
  }
}
</style>
