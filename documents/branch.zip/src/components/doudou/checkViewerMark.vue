<template lang="pug">
  .checkmark(:style="styleObj", :class="statusClassName", @mousedown="moveMark", @click="setSelect")
    img.checkImg(src="~assets/imgs/ico_right_big.png", draggable="false", v-if="this.markInfo.status === 1")
    img.checkImg(src="~assets/imgs/ico_wrong_big.png", draggable="false", v-if="this.markInfo.status === 3")
    img.checkImg(src="~assets/imgs/ico_half_right.png", draggable="false", v-if="this.markInfo.status === 5")
    img.checkImg(src="~assets/imgs/ico_query_big.png", draggable="false", v-if="this.markInfo.status === 7")
    button.close-btn(type="button", @click="closeMark")
    .scale-btn.top.left.nw-resize(@mousedown="scaleMark($event, -1, -1)")
    .scale-btn.bottom.left.ne-resize(@mousedown="scaleMark($event, -1, 1)")
    .scale-btn.bottom.right.nw-resize(@mousedown="scaleMark($event, 1, 1)")
    p.question-index(v-show="questionIndex !== undefined") {{ questionIndex !== undefined ? questionIndex + 1 : ''}}
    //- 错误原因
    p.comment-content(v-if="markInfo.commentContent", ref="comment") {{markInfo.commentContent}}
</template>
<script>
  // 8.0时代  1=>正确， 3=>错误， 5=>半对， 7=>问号
  // 事件 close
  import { moveInDoc } from '@/utils/common'
  export default {
    name: 'checkMark',
    props: ['markInfo', 'index', 'limitSize', 'scaleRate', 'disabled', 'questionIndex'],
    computed: {
      actualPos() {
        return {
          x: this.markInfo.pos.x * this.limitSize.width,
          y: this.markInfo.pos.y * this.limitSize.height
        }
      },
      actualSize() {
        return {
          width: this.markInfo.size.width * this.limitSize.width,
          height: this.markInfo.size.height * this.limitSize.height
        }
      },
      styleObj() {
        return {
          // 适应图片高度太矮情况下勾叉超过图片问题
          top: this.markInfo.pos.y * 100 >= 0 ? this.markInfo.pos.y * 100 + '%' : '2%',
          left: this.markInfo.pos.x * 100 + '%',
          width: this.markInfo.size.width * 100 + '%',
          height: this.markInfo.size.height * 100 < 100 ? this.markInfo.size.height * 100 + '%' : '80%'
        }
      },
      statusClassName() {
        return this.disabled ? ' disabled-check' : ''
          // return ['', 'right-status', 'half-right-status', 'wrong-status'][this.markInfo.status] + (this.disabled ? ' disabled-check' : '')
      }
    },
    methods: {
      setSelect(ev) {
        ev.stopPropagation()
      },
      closeMark(ev) {
        if (this.disabled) return
        ev.stopPropagation()

        this.$emit('close', this.index)
      },
      moveMark(ev) {
        this.$emit('selected')
        if (this.disabled) return

        // Prevent default dragging of selected content
        ev.preventDefault()
        ev.stopPropagation()

        moveInDoc(event => {
          this.actualPos.x += event.movementX * this.scaleRate.width
          this.actualPos.y += event.movementY * this.scaleRate.height
          this.limitsByPos()
        })
      },
      scaleMark(ev, ex, ey) {
        if (this.disabled) return

        // Prevent default dragging of selected content
        ev.preventDefault()
        ev.stopPropagation()

        let actualSize = this.actualSize
        let size = this.markInfo.size

        let maxSize = Math.min(Math.min(this.limitSize.width, this.limitSize.height) * 0.8, 600)

        moveInDoc(event => {
          let x = event.movementX
          let y = event.movementY
          if (x === 0 && y === 0) return

          // 默认右下角
          let xIsMax = Math.abs(x) - Math.abs(y)
          let max = xIsMax ? x : y

          // 拖动的是左上角
          if (ex < 0 && ey < 0) {
            max *= -1
            this.actualPos.x -= max
            this.actualPos.y -= max
          }

          // 拖动的是左下角
          if (ex < 0 && ey > 0) {
            max *= -1
            this.actualPos.x -= max
          }

          this.limitsByPos()

          // 限制缩放的边界
          let tmpWidth = actualSize.width + max
          const min = Math.min(Math.min(this.limitSize.width, this.limitSize.height) * 0.8, 45)
          if (tmpWidth < min) {
            actualSize.height = actualSize.width = min
          } else if (tmpWidth > maxSize) {
            actualSize.height = actualSize.width = maxSize
          } else {
            actualSize.width = tmpWidth
            actualSize.height += max
          }

          // 转化尺寸的比例
          size.width = actualSize.width / this.limitSize.width
          size.height = actualSize.height / this.limitSize.height
        })
      },
      limitsByPos() {
        let actualPos = this.actualPos
        let borderLimit = {
          width: 10 * this.scaleRate.width,
          height: 10 * this.scaleRate.height
        }

        let maxX = this.limitSize.width - this.actualSize.width - borderLimit.width
        let maxY = this.limitSize.height - this.actualSize.height - borderLimit.height

        if (actualPos.x < borderLimit.width) actualPos.x = borderLimit.width
        if (actualPos.x > maxX) actualPos.x = maxX
        if (actualPos.y < borderLimit.height) actualPos.y = borderLimit.height
        if (actualPos.y > maxY) actualPos.y = maxY

        // 转化坐标的比例
        this.markInfo.pos.x = actualPos.x / this.limitSize.width
        this.markInfo.pos.y = actualPos.y / this.limitSize.height
      },
      // 计算错误原因的margin
      computedCommentMargin() {
        if (this.markInfo.commentContent) {
          this.$nextTick(() => {
            let commentHeight = this.$refs.comment.clientHeight
            this.$refs.comment.style.marginTop = `-${commentHeight / 2}px`
          })
        }
      }
    },
    watch: {
      markInfo(n) {
        if (n.commentContent) {
          // 错误原因
          this.computedCommentMargin()
        }
      }
    },
    mounted() {
      this.computedCommentMargin()
    }
  }
</script>
<style scoped>
  .checkmark {
    position: absolute;
    border: 1px dashed #fff;
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
    cursor: move;
    transform: translateZ(0);
  }
  
  .checkImg {
    max-width: 100%;
    max-height: 100%;
  }
  
  .disabled-check {
    border-color: transparent;
    cursor: auto;
  }
  
  .disabled-check .close-btn,
  .disabled-check .scale-btn {
    display: none;
  }
  
  .close-btn {
    position: absolute;
    width: 20px;
    height: 20px;
    top: -10px;
    right: -10px;
    text-align: center;
    background-color: #fa454b;
    border-radius: 50%;
    border: none;
    outline: none;
    font-size: 12px;
    color: #fff;
    cursor: pointer;
    background-image: url('~assets/imgs/ico_close_b.png');
    background-size: cover;
  }
  
  .scale-btn {
    position: absolute;
    width: 10px;
    height: 10px;
    outline: none;
    border: none;
    background-color: #fff;
  }
  
  .top {
    top: -5px;
  }
  
  .right {
    right: -5px;
  }
  
  .bottom {
    bottom: -5px;
  }
  
  .left {
    left: -5px;
  }
  
  .nw-resize {
    cursor: nw-resize;
  }
  
  .ne-resize {
    cursor: ne-resize;
  }
  
  .right-status {
    background-image: url('~assets/imgs/ico_right_big.png')
  }
  
  .half-right-status {
    background-image: url('~assets/imgs/ico_half_right.png')
  }
  
  .wrong-status {
    background-image: url('~assets/imgs/ico_wrong_big.png')
  }
  
  .question-index {
    width: 18px;
    height: 18px;
    line-height: 18px;
    text-align: center;
    background-color: #F27E7E;
    position: absolute;
    right: -18px;
    bottom: 0;
    color: #fff;
    border-radius: 50%;
  }

  .comment-content {
    position: absolute;
    left: calc(100% + 10px);
    top: 50%;
    color: #F27E7E;
    font-weight: 500;
    width: 100px;
    text-align: left;
    word-break: break-all;
    font-size: 12px;
    -webkit-transform : scale(0.84,0.84);
    *font-size: 10px;
  }
</style>
