<template lang="pug">
  div
    //- 个人关注榜
    .tables(v-if="attentionLists.top10List && attentionLists.top10List.length")
      div(style="width:400px")
        .item.shape 上榜啦！真棒
      div
        table(style="width:100%;background:#ffffff")
          tbody
            tr
            tr
              td.text-left(style="width:172px;")
                section
                  img(src="~assets/imgs/top.png", draggable="false")
                  span(style="color:#333333;font-weight:400") {{source?'正确率前十名':'得分前十名'}}
              td.text-left
                section(v-if="attentionLists.top10List && attentionLists.top10List.length")
                  span(v-for="item in attentionLists.top10List",:class="{'active':studentId == item.studentId}") {{item.studentName}}
                    span(v-if="!source") ({{item.score+'分'}})
                    span(v-else) ({{item.currAccuracy | rateFilter}})
            tr(v-if="attentionLists.biggestProgress && attentionLists.biggestProgress.length")
              td.text-left
                section
                  img(src="~assets/imgs/move_up.png")
                  span(style="color:#333333;font-weight:400") 进步较大
              td.text-left
                section
                  div(v-for="item in attentionLists.biggestProgress",:class="{'active':studentId == item.studentId}")
                    p {{item.studentName}} 
                    .rise-icon
                    p.color-green {{Math.abs(item.currRank - item.lastRank)}}
    //- 难题做对列表
    .tables(v-if="problemRightData&&problemRightData.length")
      div
        .item.right-666 这你都能做对，666！
      div
        table(style="width:100%;background:#ffffff")
          thead
            tr
              th(v-if="source == 1 || source == 2") 教辅章节
              th(style="width:80px") 题型
              th(style="width:80px") 题号
              th(style="width:100px") 题目{{source?'正确':'得分'}}率
              th 答对的学生
          tbody
            tr(v-for="item in problemRightData")
              td(v-if="source == 1 || source == 2") {{deleteSpaceMark(item.sectionName)}}
              td {{item.questionType | questionType}}
              td(@click="toQuestion(item)",:class="{'click-color': reportType !== 'exam'}") {{item.numInPaperText}}
              td {{item.accuracy | rateFilter}}
              td.textleft
                span(v-for="subItem, index in item.studentInfoList",:class="{'active':studentId == subItem.studentId}") {{index === (item.studentInfoList.length-1)?subItem.studentName:(subItem.studentName+'、')}}
    //- 个人潜力榜
    .tables(v-if="improvingLists && improvingLists.length")
      div
        .item.score-rase 在这些题目上还有很大的{{source?'提升':'提分'}}潜力，加油
      div
        table(style="width:100%;background:#ffffff")
          thead
            //- th(style="width:104px") 姓名
            th(style="width:104px") {{source?'提升潜力':'提分潜力'}}
            th(style="width:104px") {{source?'本次正确率':'本次得分'}}
            th(style="width:104px") {{source?'理想正确率':'理想得分'}}
            th {{source?'正确率有提升潜力的题目':'有提分潜力的题目'}}
          tbody
            tr(v-for="item in improvingLists")
              //- td {{item.studentName}}
              td(v-if="!source") {{item.idealIndex - item.actualIndex}}
              td(v-if="source") {{(Math.round(item.idealIndex * 100) / 100 - Math.round(item.actualIndex * 100) / 100) | rateFilter}}
              td(v-if="!source") {{item.actualIndex}}
              td(v-if="source") {{item.actualIndex | rateFilter}}
              td(v-if="!source") {{item.idealIndex}}
              td(v-if="source") {{item.idealIndex | rateFilter}}
              td.textleft
                p(v-html="item.questionNumText") 
</template>
<script>
  import store from '@/store'
  import { deleteSpaceMark } from '@/filters/doudou'
  import '@/libs/TGJSBridge/index.js'
  export default {
    name: 'personalExtraTable',
    props: ['source', 'studentId', 'reportType'],
    data() {
      return {
        examId: this.$route.params.examId
      }
    },
    methods: {
      deleteSpaceMark(text) {
        return deleteSpaceMark(text)
      },
      toQuestion(data) {
        // 考试不做跳转
        if (this.reportType !== 'exam') {
          this.phoneCallback({examId: this.examId, questionId: data.questionId})
        }
      },
      // 手机端回调函数
      phoneCallback(data) {
        if (window.androidSDK && window.androidSDK.getQuestionParaData) {
          window.androidSDK.getQuestionParaData(data.examId, data.questionId)
        } else if (window.jsBridge) {
          window.jsBridge.postNotification('getQuestionParaData', {
            data: data
          })
        }
      }
    },
    computed: {
      improvingLists() {
        return store.state.report.improvingListsData
      },
      attentionLists() {
        return store.state.report.attentionListsData
      },
      problemRightData() {
        return store.state.report.problemRightData
      }
    }
  }
</script>
<style scoped>
.click-color {
  color: #48B8FF;
}
.textleft{
  text-align: left;
  padding-left: 18px;
}
.text-left {
    text-align: left;
    padding-left: 28px;
    &>section {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      &>span {
        padding-left: 10px;
      }
      &>div {
        padding-left: 10px;
        display: flex;
        align-items: center;
      }
    }
  }
  .color-green {
    color: #24CB72;
  }
  .rise-icon {
    width: 14px;
    height: 16px;
    margin:0 5px;
    background: url(~assets/imgs/fa-arrow-up.png) no-repeat center center;
  }
  .item {
    height: 36px;
    line-height: 36px;
    margin: 16px 0;
    font-size: 20px;
    color: #333333;
    font-weight: 400;
    padding-left: 46px;
  }
  .score-rase {
    background: url(~assets/imgs/score-rase.png) no-repeat 0 0;
    background-size: 36px;
  }
  .right-666 {
    background: url(~assets/imgs/ic_666.png) no-repeat 0 0;
    background-size: 36px;
  }
  .shape {
    background: url(~assets/imgs/shape.png) no-repeat 0 0;
    background-size: 36px;
  }
  .active {
    color: #FF9937;
  }
</style>
