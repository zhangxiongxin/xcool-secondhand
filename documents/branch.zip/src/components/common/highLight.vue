<template lang="pug">
  div.high-light
    span(v-for="item in items", :class="item.cls") {{item.str}}
    slot
</template>
<script>
  const cls = 'text-red'
  export default {
    name: 'zHighLight',
    props: ['text', 'target'],
    computed: {
      items() {
        const arr = []
        if (!this.text) return arr
        let tempArry = this.text.toString().replace(new RegExp(this.target, 'ig'), function(a, b, c) {
          return '/' + a + '/'
        }).split('/')

        tempArry.forEach(str => {
          if (str === this.target) {
            arr.push({ str: this.target, cls })
          } else if (str === this.target.toUpperCase()) {
            arr.push({ str: this.target.toUpperCase(), cls })
          } else if (str === this.target.toLowerCase()) {
            arr.push({ str: this.target.toLowerCase(), cls })
          } else {
            arr.push({ str })
          }
        })
        return arr
      }
    }
  }
</script>
<style>
  .high-light .text-red {
    color: #EC4989;
    background: #FFE8E8;
  }
</style>
