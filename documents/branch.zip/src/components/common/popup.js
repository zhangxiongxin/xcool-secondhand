import Vue from 'vue'

export default function popup(component, config, cb) {
  var top
  var PopupComp = Vue.extend({
    template: '<div style="position:fixed;left:0;top:0;right:0;bottom:0;z-index: 9999;background:#fff"><inner @close="remove()" :config="config"></inner></div>',
    components: {inner: component},
    data() {
      return {config: config}
    },
    methods: {
      remove() {
        document.body.children[0].style.display = 'block'
        window.scrollTo(0, top)
        this.$el.remove()
        this.$destroy()
        cb.apply(arguments)
      }
    }
  })
  top = document.documentElement.scrollTop || window.scrollY
  document.body.children[0].style.display = 'none'
  document.body.appendChild(new PopupComp().$mount().$el)
}
