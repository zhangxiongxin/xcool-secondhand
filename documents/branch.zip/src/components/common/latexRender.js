import remoteFile from '@/filters/remoteFile'

// LatexGraph  是 <latex> 这个标记的图片
// Graph 是 <img> 这个标记的图片
export default function latexRender(ele, latex, latexImgs, imgs, target, errHandle, highlight) {
  if (!ele) return
  latex = latex || ''

  if (typeof latexImgs === 'string') latexImgs = latexImgs.split('#%#')
  if (typeof imgs === 'string') imgs = imgs.split('#%#')
  latexImgs = latexImgs || []
  imgs = imgs || []

  imgs = imgs.filter(v => v.trim())

  ele.innerHTML = getHtmlByLatex(latex, latexImgs, imgs, target, highlight) + getHtmlStr(imgs)
  let eleImgs = ele.querySelectorAll('img')
  for (let i = 0; i < eleImgs.length; i++) {
    eleImgs[i].addEventListener('error', function() {
      eleImgs[i].className += ' specialError'
      if (errHandle) errHandle()
    })
  }
}

function getHtmlByLatex(str, latexImgs, imgs, target, highlight) {
  str = (str || '') + ''
  if (!str.trim()) return str

  latexImgs = latexImgs || []
  imgs = imgs || []

  // target用于匹配搜索内容是否是<latex> <img> #%#关键字，highlight用于高亮
  if (highlight && highlight[0] && target) {
    if (new RegExp(target.toString().toLowerCase()).test('<latex>') || new RegExp(target.toString().toUpperCase()).test('<latex>')) {
      str = highLight(str, '<latex>', highlight)
    } else if (new RegExp(target.toString().toLowerCase()).test('<img>') || new RegExp(target.toString().toUpperCase()).test('<img>')) {
      str = highLight(str, '<img>', highlight)
    } else if (new RegExp(target.toString().toLowerCase()).test('#%#') || new RegExp(target.toString().toUpperCase()).test('#%#')) {
      str = highLight(str, '#%#', highlight)
    } else {
      highlight.sort(function(a, b) {
        return b.length - a.length
      })
      for (let j = 0; j < highlight.length; j++) {
        str = str.toString().replace(new RegExp(highlight[j].toString().toLowerCase(), 'g'), (a, b) => '魑' + highlight[j].toString().toLowerCase() + '魉')
        str = str.toString().replace(new RegExp(highlight[j].toString().toUpperCase(), 'g'), (a, b) => '魑' + highlight[j].toString().toUpperCase() + '魉')
      }
    }
  }
  return str
    .replace(/魑/g, (a, b) => '<span style="color:#EC4989">')
    .replace(/魉/g, (a, b) => '</span>')
    .replace(/#%#/g, (a, b) => '<div class="latex-break"></div>')
    .replace(/<latex>/g, () => getImgEleStr(latexImgs.shift(), 'latex-img'))
    .replace(/<img>/g, () => getImgEleStr(imgs.shift(), 'stem-graph'))
}

function getHtmlStr(imgs) {
  if (!imgs.length) return ''
  return imgs.map(v => getImgEleStr(v, 'stem-graph')).join('') || ''
}

window.resetWidth = function(evt) {
  if (evt.target.className.indexOf('latex-img') === -1) return
  evt.target.style.width = evt.target.naturalWidth * 0.3333333 + 'px'
}

function getImgEleStr(src, className) {
  src = (src || '') + ''
  if (!src.trim()) return src

  className = className || 'stem-graph'
  return `<img src="${remoteFile(src)}" class="${className}" draggable="false" onload='resetWidth(event)'>`
}

function highLight(str, sign, lightArry) {
  lightArry.sort(function(a, b) {
    return b.length - a.length
  })
  let tempStr = []
  tempStr = str.split(sign)
  for (let i = 0; i < tempStr.length; i++) {
    for (let j = 0; j < lightArry.length; j++) {
      tempStr[i] = tempStr[i].toString().replace(new RegExp(lightArry[j].toString().toLowerCase(), 'g'), (a, b) => '魑' + lightArry[j].toString().toLowerCase() + '魉')
      tempStr[i] = tempStr[i].toString().replace(new RegExp(lightArry[j].toString().toUpperCase(), 'g'), (a, b) => '魑' + lightArry[j].toString().toUpperCase() + '魉')
    }
    if (i < tempStr.length - 1) tempStr[i] += sign
  }
  return tempStr.join('')
}
