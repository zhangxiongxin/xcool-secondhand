import ddTable from './ddTable'
import zHighLight from './highLight'
import latex from './latex'
import scroll from './scroll'

export default {
  ddTable,
  zHighLight,
  latex,
  scroll
}
