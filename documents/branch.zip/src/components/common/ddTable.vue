<template lang="pug">
  div(v-if="structuredData")
    .tables(v-for="item in structuredData.tables",v-if="item.tableData && item.tableData.length && source === '1'")
          div(style="width:400px")
            .sub-item(v-if="item.itemTitle",:class="{'sub-item1':item.itemTitle ==='题目对错一览'}") {{item.itemTitle}}
              .l-triangle
          div(v-if="item.tableData && item.tableData.length !== 0" v-for="subTable in item.tableData")
            p.label(v-if="item.itemTitle ==='题目对错一览'") {{subTable.teachingBook}}      
            table(style="width:100%;background:#ffffff" v-if="subTable.distribute")
              thead
                tr
                  th(v-for="titleItem in item.tableFields") {{titleItem.label}}
              tbody
                tr(v-for="titleItem in subTable.distribute")
                  td(v-for="subItem in item.tableFields",:class="{'textleft':(subItem.prop === 'knowledgePoint' || subItem.prop === 'questionNumText'),'padding-0':subItem.prop === 'accuracy','click-color':subItem.prop === 'numInPaper'}",@click="toQuestion(subItem.prop, titleItem)")
                    span(v-if="subItem.prop !== 'correct' && subItem.prop !== 'questionType' && subItem.prop !== 'questionNumText' && subItem.prop !== 'accuracy'") {{subItem.prop === 'accuracy'? (rateFilter(titleItem[subItem.prop], titleItem.status)) : dataFilter(titleItem[subItem.prop], titleItem.status)}}
                    span(v-if="subItem.prop === 'questionType'") {{titleItem.questionType | questionType}}
                    span(v-if="subItem.prop === 'correct'")
                      .icon.icon-right(v-if="titleItem[subItem.prop]")
                      .icon.icon-wrong(v-else)
                    p(v-if="subItem.prop === 'questionNumText'",v-html="deleteSpaceMark(titleItem.questionNumText)")   
                    p(v-if="subItem.prop === 'accuracy'",:class="titleItem.accuracyClass",style="height:100%;width:100%;display:flex;align-items:center;justify-content:center") {{titleItem.accuracy | rateFilter}}      
    .tables(v-for="item in structuredData.tables",v-if="item.tableData && item.tableData.length && source !=='1'")
      div(style="width:400px")
        .sub-item(v-if="item.itemTitle") {{item.itemTitle}}     
          .l-triangle       
      table(style="width:100%;background:#ffffff")
        thead
          tr
            th(v-for="titleItem in item.tableFields") {{titleItem.label}}
        tbody(v-if="item.tableData && item.tableData.length !== 0")
          tr(v-for="titleItem in item.tableData")
            td(v-for="subItem in item.tableFields",:class="{textleft:(subItem.prop === 'knowledgePoint' || subItem.prop === 'questionNumText'),'padding-0':subItem.prop === 'accuracy','click-color': subItem.prop === 'numInPaper' && reportType !== 'exam'}",@click="toQuestion(subItem.prop, titleItem)") 
              span(v-if="subItem.prop !== 'correct' && subItem.prop !== 'questionType' && subItem.prop !== 'accuracy'") {{subItem.prop === 'accuracy'? (rateFilter(titleItem[subItem.prop], titleItem.status)) : dataFilter(titleItem[subItem.prop], titleItem.status)}}
              span(v-if="subItem.prop === 'questionType'") {{titleItem.questionType | questionType}}
              span(v-if="subItem.prop === 'correct'")
                .icon.icon-right(v-if="titleItem[subItem.prop]")
                .icon.icon-wrong(v-else)
              p(v-if="subItem.prop === 'accuracy'",:class="titleItem.accuracyClass",style="height:100%;width:100%;display:flex;align-items:center;justify-content:center") {{titleItem.accuracy | rateFilter}}

</template>
<script>
  import { rateFilter } from '@/filters/doudou'
  import '@/libs/TGJSBridge/index.js'
  export default {
    name: 'ddTable',
    props: [ 'structuredData', 'source', 'reportType' ],
    data() {
      return {
        examId: this.$route.params.examId
      }
    },
    methods: {
      rateFilter(item, status) {
        return (status === '未上传' || status === '已上传 | 批阅中' || status === '已上传 | 待批阅') ? '-' : rateFilter(item)
      },
      dataFilter(item, status) {
        return ((status === '未上传' || status === '已上传 | 批阅中' || status === '已上传 | 待批阅') && !item) ? '-' : item
      },
      deleteSpaceMark(text) {
        return text.replace(/#%#/g, ' ')
      },
      toQuestion(type, data) {
        // 考试不做跳转
        if (type === 'numInPaper' && this.reportType !== 'exam') {
          this.phoneCallback({examId: this.examId, questionId: data.questionId})
        }
      },
      // 手机端回调函数
      phoneCallback(data) {
        if (window.androidSDK && window.androidSDK.getQuestionParaData) {
          window.androidSDK.getQuestionParaData(data.examId, data.questionId)
        } else if (window.jsBridge) {
          window.jsBridge.postNotification('getQuestionParaData', {
            data: data
          })
        }
      }
    }
  }
</script>
<style scoped>
  .click-color {
    color: #48B8FF;
  }
  .padding-0 {
    padding: 0;
  }
  .textleft{
    text-align: left;
    padding-left: 18px;
  }
  .sub-item1 {
    height: 24px;
    line-height: 24px;
    color: #ffffff;
    padding-left: 10px;
    padding-right: 36px;
    background-color:#A779E8;
    position: relative;
    margin-bottom: 0px;
    margin-top: 30px;
    display: inline-block;
  }
  .icon {
    display: inline-block;
    vertical-align: middle;
    width: 20px;
    height: 20px;
    margin-left: 10px;
    margin-right: 10px;
    background-size: cover;
    background-position: center;
  }
  .icon-right {
    background-image: url('~assets/imgs/ico_right.png');
  }
  
  .icon-wrong {
    background-image: url('~assets/imgs/ico_wrong.png');
  }
  .label {
    display: inline-block;
    min-height: 28px;
    line-height: 28px;
    background: #F6F2FF;
    border: 1px solid #A779E8;
    border-radius: 12px;
    font-size: 14px;
    color: #A779E8;
    margin: 10px 0px;
    padding: 0px 10px;
  }
</style>
