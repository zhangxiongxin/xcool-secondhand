<template lang="pug">
  .latex-warp
    slot
    span(ref="latexWarp")
</template>
<script>
  import latexRender from './latexRender'

  export default {
    name: 'latex',
    props: ['text', 'latexImgs', 'imgs', 'target', 'highlight'],
    data() {
      return {
        latexTimer: null
      }
    },
    methods: {
      errorHandle() {
        this.$emit('errorImg', true)
      },
      render() {
        if (this.latexTimer) clearTimeout(this.latexTimer)
        this.latexTimer = setTimeout(this.renderHandle, 16, this.$refs.latexWarp, this.text, this.latexImgs, this.imgs, this.target, this.errorHandle, this.highlight)
      },
      renderHandle(...arg) {
        latexRender(...arg)
        setTimeout(this.emitAfterRender, 16)
      },
      emitAfterRender() {
        this.$emit('after-render')
      }
    },
    watch: {
      text: function(n, o) {
        this.$nextTick(this.render)
      },
      latexImgs: function(n, o) {
        this.$nextTick(this.render)
      },
      imgs: function(n, o) {
        this.$nextTick(this.render)
      },
      target: function(n, o) {
        this.$nextTick(this.render)
      }
    },
    mounted() {
      this.$nextTick(this.render)
    }
  }
</script>
<style scoped>
  .latex-warp {
    display: inline-block;
    white-space: pre-wrap;
  }
</style>
<style type="text/css">
  .sub-stem-choice .latex-break {
    display: inline-block;
    margin-right: 4em;
  }
  
  .latex-warp .latex-img {
    /*zoom: 0.33;*/
    display: inline-block;
    vertical-align: middle;
  }
  
  .latex-warp .stem-graph {
    display: block;
  }
</style>
