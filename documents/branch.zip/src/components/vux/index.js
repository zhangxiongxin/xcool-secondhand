// Vux 组件库
import { Confirm, Toast, XHeader, Tab, XInput, XButton, Group, XSwitch, ButtonTab, ButtonTabItem, Popup, Cell, Loading, InlineLoading, Rater, Datetime, LoadMore, Alert } from 'vux'

export default {
  Confirm,
  Toast,
  XHeader,
  Tab,
  XInput,
  XButton,
  Group,
  XSwitch,
  ButtonTab,
  ButtonTabItem,
  Popup,
  Cell,
  Loading,
  InlineLoading,
  Rater,
  Datetime,
  LoadMore,
  Alert
}
