<template lang="pug">
  svg(:viewBox="viewBox" :width='width' :height='height')
    use(:xlink:href="'#'+id")
</template>

<script>
  import icons from '@/assets/icon'
  export default {
    name: 'icon',
    props: {
      name: {required: true},
      width: {default: 30},
      height: {default: 30}
    },
    data() {
      return {
        content: '',
        id: '',
        viewBox: '0 0 0 0'
      }
    },
    mounted() {
      var icon = icons[this.name]
      if (icon) {
        this.content = icon.node.innerHTML
        this.id = icon.id
        this.viewBox = icon.viewBox
      }
    },
    components: {},
    methods: {}
  }
</script>
<style scoped>
  svg {
    fill: #000;
  }
</style>
